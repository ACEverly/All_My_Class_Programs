# CSE-4308-Project-4-Ghostbusters

## Tasks To Do

- [x] **Question 1 Fully Passed**
- [x] **Question 2 Fully Passed**
- [x] **Question 3 Fully Passed**
- [x] **Question 4 Fully Passed**
- [x] **Question 5 Fully Passed**
- [x] **Question 6 Fully Passed**
- [x] **Question 7 Fully Passed**
- [x] **Question 8 Fully Passed**
- [x] **Question 9 Fully Passed**
- [x] **Question 10 Fully Passed**
- [x] **Question 11 Fully Passed**

Welcome!

This Project 4 repository is based on CS 188 FA25 Project 4: Bayes Nets and HMMs, or alternatively named Ghostbusters.

## Synopsis

Pacman uses probabilistic inference on Bayes Nets and the forward algorithm and particle sampling in a Hidden Markov Model to find ghosts given noisy readings of distances to them.

| Files You Will Edit | |
| :--- | :--- |
| `bustersAgents.py` | Agents for playing the Ghostbusters variant of Pacman. |
| `inference.py` | Code for tracking ghosts over time using their sounds. |
| `factorOperations.py` | Operations to compute new joint or magrinalized probability tables. |

| Files You Might Want To Look At | |
| :--- | :--- |
| `bayesNet.py` | The BayesNet and Factor classes. |

## Files to Edit and Submit

You will fill in portions of `bustersAgents.py`, `inference.py`, and `factorOperations.py` during the assignment. Once you have completed the assignment, you will submit these files to Gradescope (for instance, you can upload all `.py` files in the folder). Please do not change the other files in this distribution.

## Evaluation

Your code will be autograded for technical correctness. Please do not change the names of any provided functions or classes within the code, or you will wreak havoc on the autograder. However, the correctness of your implementation – not the autograder’s judgments – will be the final judge of your score. If necessary, we will review and grade assignments individually to ensure that you receive due credit for your work.

## Academic Dishonesty

We will be checking your code against other submissions in the class for logical redundancy. If you copy someone else’s code and submit it with minor changes, we will know. These cheat detectors are quite hard to fool, so please don’t try. We trust you all to submit your own work only; please don’t let us down. If you do, we will pursue the strongest consequences available to us.

## Topics Needed For This Project

Probability: [Video 12](https://www.youtube.com/watch?v=sMNbLXsvRig), [Note 6.1-6.2](https://inst.eecs.berkeley.edu/~cs188/textbook/bayes-nets/probability.html)
Bayes Nets Representation: [Video 13](https://www.youtube.com/watch?v=T4l6ltMMcec), [Note 6.3-6.4](https://inst.eecs.berkeley.edu/~cs188/textbook/bayes-nets/representation.html)
Bayes Nets Inference: [Video 15](https://www.youtube.com/watch?v=A1hYXGAUdmU), [Note 6.6](https://inst.eecs.berkeley.edu/~cs188/textbook/bayes-nets/elimination.html)
HMMs: [Video 19](https://www.youtube.com/watch?v=eCZLhZu_U1I), [Note 8.1-8.3](https://inst.eecs.berkeley.edu/~cs188/textbook/hmms/markov.html)
Particle Filtering: [Video 20](https://www.youtube.com/watch?v=pNam9hbwg4g), [Note 8.4-8.5](https://inst.eecs.berkeley.edu/~cs188/textbook/hmms/particle-filtering.html)

## Run All Autograders In One Go

```console

python autograder.py -q q1

python autograder.py -q q2

python autograder.py -q q3

python autograder.py -q q4

python autograder.py -q q5

python autograder.py -q q6

python autograder.py -q q6 --no-graphics

python autograder.py -q q7

python autograder.py -q q7 --no-graphics

python autograder.py -q q8

python autograder.py -q q8 --no-graphics

python autograder.py -q q9

python autograder.py -q q10

python autograder.py -q q10 --no-graphics

python autograder.py -q q11

python autograder.py -q q11 --no-graphics

```
