# Name: Adalynn Cadence Everly   ID#: 1001852753     NetID: MXT2753
# Name: Chime Nguyen             ID#: 1001991344     NetID: JXN1344

# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent
import collections

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100):
        """
          Your value iteration agent should take an mdp on
          construction, run the indicated number of iterations
          and then act according to the resulting policy.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state, action, nextState)
              mdp.isTerminal(state)
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0
        self.runValueIteration()

    def runValueIteration(self):
        # Write value iteration code here
        "*** YOUR CODE HERE ***"
        #Val Batch iterat:V_{k+1}(s) is computed from a frozen V_k (self.values),
        #Then we replace self.values after the full sweep.
        for _ in range(self.iterations):
            newValues=util.Counter() #holds/does V_{k+1}
            for state in self.mdp.getStates():
                #This is the Terminal state-val=0 by def in this project,no actions
                if self.mdp.isTerminal(state):
                    newValues[state]=0
                    continue
                #The Bellman backup:V_{k+1}(s)=max_a Q_k(s,a)
                best=-float('inf')
                for action in self.mdp.getPossibleActions(state):
                    q=self.computeQValueFromValues(state, action)
                    if q>best:
                        best=q
                newValues[state]=best #Commit batch update AFTER all states = processed
            self.values=newValues
    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]
    def computeQValueFromValues(self,state,action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "*** YOUR CODE HERE ***"
        #THE FORMULA:Q(s,a)=sum_{s'}T(s,a,s')*(R(s,a,s')+gamma*V(s'))
        q=0.0
        for nextState,prob in self.mdp.getTransitionStatesAndProbs(state,action):
            reward=self.mdp.getReward(state,action,nextState)
            q+=prob*(reward+self.discount*self.values[nextState])
        return q
        #util.raiseNotDefined()
    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        "*** YOUR CODE HERE ***"
        #There is no action to take, If this is a term.
        if self.mdp.isTerminal(state):
            return None
        actions=self.mdp.getPossibleActions(state)
        if not actions:
            return None
        best_action=None #^^Policy extraction from the val's:pi(s)=argmax_a Q(s,a)^^
        best_value=-float('inf')
        for action in actions:
            q=self.computeQValueFromValues(state,action)
            if q>best_value:
                best_value=q
                best_action=action
        return best_action
        #util.raiseNotDefined()
    def getPolicy(self,state):
        return self.computeActionFromValues(state)
    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)
    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)
# Question 4 - Considered as extra credit
class PrioritizedSweepingValueIterationAgent(ValueIterationAgent):
    """
        *Please read learningAgents.py before reading this.*
        
        learningAgents.py Notes:
        * getLegalActions: returns the available actions that the state can go through
        * observeTransition: when a transition has been taken, it will be considered as observed and will update the
            episode reward with the delta reward and update itself, with it explicitly mentioned to not override this function
        * startEpisode: reset the last state, list of actions, and any accumulated rewards from the previous episode
        * stopEpisode: obtains any training/testing reward from an episode and continually reset its training
            (as the epsilon and alpha would otherwise accumulate and would be used in the next episode)
        * isInTraining: checks the number of episodes against a specified number that should be trained
        * isInTesting: checks if isInTraining returns false
        

        A PrioritizedSweepingValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs prioritized sweeping value iteration
        for a given number of iterations using the supplied parameters.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100, theta = 1e-5):
        """
          Your prioritized sweeping value iteration agent should take an mdp on
          construction, run the indicated number of iterations,
          and then act according to the resulting policy.
        """
        self.theta = theta
        ValueIterationAgent.__init__(self, mdp, discount, iterations)

    def runValueIteration(self):
        "*** YOUR CODE HERE ***"
        # 1 Compute predecessors of all states
        predecessors = dict()
        states = self.mdp.getStates()
        
        for s in states:
            # Each predecessor is a set
            predecessors[s] = set()
        
        for s in states:
            # Skip any terminal states
            if self.mdp.isTerminal(s):
                continue
            
            # Get the possible actions, find the transition states and probabilities, and add it to the dictionary of predecessors
            for action in self.mdp.getPossibleActions(s):
                for nextState, prob in self.mdp.getTransitionStatesAndProbs(s, action):
                    if prob > 0:
                        predecessors[nextState].add(s)
        
        # 2 Initialize an empty priority queue
        priorityQueue = util.PriorityQueue()
        
        # 3 For each non-terminal state s, do:
        for s in states:
            if self.mdp.isTerminal(s):
                continue
            # 3.1 Find the absolute value of the difference between the current value of s in self.values and the highest Q-value across all possible actions from s
            actions = self.mdp.getPossibleActions(s)
            # Skip this state if there is no actions associated with said state
            if not actions:
                continue
            # Determine max Q-Value within said state based on possible actions
            maxQValue = max(self.computeQValueFromValues(s, action) for action in actions)
            
            # 3.2 Push s into the priority queue with priority -diff
            diff = abs(self.values[s] - maxQValue)
            priorityQueue.update(s, -diff)
            
        # 4 For iteration in 0, 1, 2, ..., self.iterations - 1, do:
        for _ in range(self.iterations):
            # 4.1 If the priority queue is empty, then terminate
            if priorityQueue.isEmpty():
                return
            
            # 4.2 Pop a state s off the priority queue
            s = priorityQueue.pop()
            
            # 4.3 Update the value of s (if it is not a terminal state) in self.values
            if not self.mdp.isTerminal(s):
                actions = self.mdp.getPossibleActions(s)
                if actions:
                    self.values[s] = max(self.computeQValueFromValues(s, action) for action in actions)
                    
            # 4.4 For each predecessor p of s, do:
            for p in predecessors[s]:
                if self.mdp.isTerminal(p):
                    continue
                
                # Obtain the actions that are necessary to calculate the max Q-Values
                actions = self.mdp.getPossibleActions(p)
                if not actions:
                    continue
                
                # 4.4.1 Find the absolute value of the difference between the current value of p in self.values and the highest Q-value across all possible actions from p
                maxQValue = max(self.computeQValueFromValues(p, action) for action in actions)
                diff = abs(self.values[p] - maxQValue)
                
                # 4.4.2 If diff > theta, push p into the priority queue with priority -diff (note that this is negative), as long as it does not already exist in the priority queue with equal or lower priority
                if diff > self.theta:
                    priorityQueue.update(p, -diff)
        
        # Chime Nguyen

