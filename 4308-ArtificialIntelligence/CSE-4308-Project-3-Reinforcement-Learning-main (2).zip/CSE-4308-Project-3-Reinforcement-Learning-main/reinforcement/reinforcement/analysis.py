# Name: Adalynn Cadence Everly   ID#: 1001852753     NetID: MXT2753
# Name: Chime Nguyen             ID#: 1001991344     NetID: JXN1344

# analysis.py
# -----------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


######################
# ANALYSIS QUESTIONS #
######################

# Set the given parameters to obtain the specified policies through
# value iteration.

def question2():
    # Chime Nguyen
    answerDiscount = 0.9
    # The only value that was changed from the default values was the noise, from 0.2 to 0.01.
    # A very large noise value makes the agent want to fall off the cliff more often,
    # a noise between 0.01 and 0.3-ish makes the agent want to go back to the start position, which is an exit state,
    # and a noise between 0 and 0.01 makes the agent walk towards the reward on the other side of the bridge.
    # Any value under 0 causes an error to happen as it causes the total transition probability to be greater than 1.
    answerNoise = 0.01
    return answerDiscount, answerNoise

def question3a():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is possible to achieve this policy.
    # For this question, it is ideal to have a high negative living reward and high discount factor as to
    # not incentivize the agent to go towards the further exit as the further it goes, the more negative reward
    # it gets, and to incentivize the agent to go towards the closer exit. This also means that the agent is more
    # willing to risk the cliff if it means getting towards the closer exit faster.
    answerDiscount = 0.9
    answerNoise = 0.1
    answerLivingReward = -5
    return answerDiscount, answerNoise, answerLivingReward
    # If not possible, return 'NOT POSSIBLE'

def question3b():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is possible to achieve this policy.
    # For this question, having an extremely low discount factor as well as some small amount of noise is just
    # enough to make the agent stray away from the cliff. having some small positive living reward is also needed
    # to make the agent get closer to the closer exit
    answerDiscount = 0.01
    answerNoise = 0.01
    answerLivingReward = 0.1
    return answerDiscount, answerNoise, answerLivingReward
    # If not possible, return 'NOT POSSIBLE'

def question3c():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is possible to achieve this policy.
    # For this question, it is ideal to have some moderate discount and a very low amount of noise as to make
    # it stray away from the cliff. The living reward has to be set to some value, not greater than the immediate
    # reward of the closer exit as it would make the agent go towards the further exit, and not less than the
    # immediate reward of the cliff as it would make the agent go fall of the cliff instead.
    answerDiscount = 0.5
    answerNoise = 0.01
    answerLivingReward = 1
    return answerDiscount, answerNoise, answerLivingReward
    # If not possible, return 'NOT POSSIBLE'

def question3d():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is possible to achieve this policy.
    # For this question, it is set to a lower discount factor and lower positive living reward along with some
    # small amount of noise. It knows that the further exit has a much better immediate reward than the closer
    # exit, so combining that with the the stuff mentioned earlier makes the agent want to go towards the further
    # exit in the safest path possible away from the cliff.
    answerDiscount = 0.4
    answerNoise = 0.03
    answerLivingReward = 0.05
    return answerDiscount, answerNoise, answerLivingReward
    # If not possible, return 'NOT POSSIBLE'

def question3e():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is possible to achieve this policy.
    # For this question, as long as there is a high enough noise and a high enough living reward that outweighs
    # the reward of the further exit after it has travels away from the cliff, the agent will get stuck trying
    # to go upwards away from the cliff and never reach either exit, regardless of the discount factor.
    answerDiscount = 0
    answerNoise = 0.5
    answerLivingReward = 11
    return answerDiscount, answerNoise, answerLivingReward
    # If not possible, return 'NOT POSSIBLE'

def question7():
    # Chime Nguyen
    # As a sanity check, I returned 'NOT POSSIBLE' initially, turns out it is NOT possible to achieve this policy.
    # As a side note, in the command below, k is the number of episodes, n is the noise, and e is the epsilon.
    # python gridworld.py -a q -k 50 -n 0 -g BridgeGrid -e 1
    # To properly answer the following question: "Is there an epsilon and a learning rate for which it is highly
    # likely (greater than 99%) that the optimal policy will be learned after 50 iterations?", the optimal policy is
    # dependent on the map layout (via rotation) and not enforced by some tie-breaker that could solve this issue.
    # Additionally, an epsilon of 0 means that the agent will never explore, thus never reaching the other side of the bridge,
    # and an epsilon of 1 means that the agent will always explore, thus never learning the optimal policy effectively.
    # Any epsilon value between 0 and 1 would try to balance between exploration and exploitation, but due to the limited
    # number of episodes, it may not be able to always learn the optimal policy. As for the learning rate, the agent might
    # learn to not fall off the cliff somewhere along the bridge, but it also will prevent the agent from wanting to pursue
    # the path it took to get there, instead opting for a closer, different path or exit.
    answerEpsilon = 0
    answerLearningRate = None
    return 'NOT POSSIBLE'
    # If not possible, return 'NOT POSSIBLE'

if __name__ == '__main__':
    print('Answers to analysis questions:')
    import analysis
    for q in [q for q in dir(analysis) if q.startswith('question')]:
        response = getattr(analysis, q)()
        print('  Question %s:\t%s' % (q, str(response)))
