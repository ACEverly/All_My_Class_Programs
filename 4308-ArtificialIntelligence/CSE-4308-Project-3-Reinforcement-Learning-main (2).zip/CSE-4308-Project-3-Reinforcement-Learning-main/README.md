# CSE-4308-Project-3-Reinforcement-Learning

## Tasks To Do

- [x] **Question 1 Fully Passed**
- [x] **Question 2 Fully Passed**
- [x] **Question 3 Fully Passed**
- [x] **Question 4 Fully Passed**
- [x] **Question 5 Fully Passed**
- [x] **Question 6 Fully Passed**
- [x] **Question 7 Fully Passed**
- [x] **Question 8 Fully Passed**
- [x] **Question 9 Fully Passed**

Welcome!

This Project 3 repository is based on CS 188 FA25 Project 3: Reinforcement Learning.

## Synopsis

Students implement Value Function, Q learning, and Approximate Q learning to help pacman and crawler agents learn rational policies.

| Files You Will Edit | |
| :--- | :--- |
| `valueIterationAgents.py` | A value iteration agent for solving known MDPs. |
| `qlearningAgents.py` | Q-learning agents for Gridworld, Crawler and Pacman. |
| `analysis.py` | A file to put your answers to questions given in the project. |

| Files You Might Want To Look At | |
| :--- | :--- |
| `mdp.py` | Defines methods on general MDPs. |
| `learningAgents.py` | Defines the base classes `ValueEstimationAgent` and `QLearningAgent`, which your agents will extend. |
| `util.py` | Utilities, including `util.Counter`, which is particularly useful for Q-learners. |
| `gridworld.py` | The Gridworld implementation. |
| `featureExtractors.py` | Classes for extracting features on (state, action) pairs. Used for the approximate Q-learning agent (in `qlearningAgents.py`). |

## Files to Edit and Submit

You will fill in portions of `valueIterationAgents.py`, `qlearningAgents.py`, and `analysis.py` during the assignment. Once you have completed the assignment, you will submit these files to Gradescope (for instance, you can upload all `.py` files in the folder). Please do not change the other files in this distribution.

## Evaluation

Your code will be autograded for technical correctness. Please do not change the names of any provided functions or classes within the code, or you will wreak havoc on the autograder. However, the correctness of your implementation – not the autograder’s judgments – will be the final judge of your score. If necessary, we will review and grade assignments individually to ensure that you receive due credit for your work.

## Academic Dishonesty

We will be checking your code against other submissions in the class for logical redundancy. If you copy someone else’s code and submit it with minor changes, we will know. These cheat detectors are quite hard to fool, so please don’t try. We trust you all to submit your own work only; please don’t let us down. If you do, we will pursue the strongest consequences available to us.

## Topics Needed For This Project

MDPs I: [Video 8](https://www.youtube.com/watch?v=4LW3H_Jinr4), [Note 4.1-4.2](https://inst.eecs.berkeley.edu/~cs188/textbook/mdp/markov-decision-processes.html)
MDPs II: [Video 9](https://www.youtube.com/watch?v=ZToWj64rxvQ), [Note 4.3-4.5](https://inst.eecs.berkeley.edu/~cs188/textbook/mdp/value-iteration.html)
RL I: [Video 10](https://www.youtube.com/watch?v=TiXS7vROBEg), [Note 5.1-5.3](https://inst.eecs.berkeley.edu/~cs188/textbook/rl/rl.html)
RL II: [Video 11](https://www.youtube.com/watch?v=XafrqwHfBKE), [Note 5.4-5.5](https://inst.eecs.berkeley.edu/~cs188/textbook/rl/eae.html)

## Run All Autograders In One Go

```console
python autograder.py -q q1

python autograder.py -q q2

python autograder.py -q q3

python autograder.py -q q4

python autograder.py -q q5

python autograder.py -q q6

python autograder.py -q q7

python autograder.py -q q8

python autograder.py -q q9

```
