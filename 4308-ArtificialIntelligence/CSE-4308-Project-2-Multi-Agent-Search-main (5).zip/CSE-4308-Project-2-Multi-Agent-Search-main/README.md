# CSE-4308-Project-2-Multi-Agent-Search

Welcome!

This Project 2 repository is based on CS 188 FA25 Project 2: Multi-Agent Search.

## Synopsis

Classic Pacman is modeled as both an adversarial and a stochastic search problem. Students implement multiagent minimax and expectimax algorithms, as well as designing evaluation functions.

| Files You Will Edit | |
| :--- | :--- |
| `multiAgents.py` | Where all of your multi-agent search agents will reside. |

| Files You Might Want To Look At | |
| :--- | :--- |
| `pacman.py` | The main file that runs Pacman games. This file also describes a Pacman GameState type, which you will use extensively in this project. |
| `game.py` | The logic behind how the Pacman world works. This file describes several supporting types like AgentState, Agent, Direction, and Grid. |
| `util.py` | Useful data structures for implementing search algorithms. You don't need to use these for this project, but may find other functions defined here to be useful. |

## Files to Edit and Submit

You will fill in portions of `multiAgents.py` during the assignment. Once you have completed the assignment, you will submit these files to Gradescope (for instance, you can upload all .py files in the folder). Please do not change the other files in this distribution.

## Evaluation

Your code will be autograded for technical correctness. Please do not change the names of any provided functions or classes within the code, or you will wreak havoc on the autograder. However, the correctness of your implementation – not the autograder’s judgements – will be the final judge of your score. If necessary, we will review and grade assignments individually to ensure that you receive due credit for your work.

## Academic Dishonesty

We will be checking your code against other submissions in the class for logical redundancy. If you copy someone else’s code and submit it with minor changes, we will know. These cheat detectors are quite hard to fool, so please don’t try. We trust you all to submit your own work only; please don’t let us down. If you do, we will pursue the strongest consequences available to us.

## Topics Needed For This Project

Game Trees I: [Video 6](https://www.youtube.com/watch?v=v6RgZBjc8og), [Note 3.1-3.2](https://inst.eecs.berkeley.edu/~cs188/textbook/games/games.html)
Game Trees II: [Video 7](https://www.youtube.com/playlist?list=PLp8QV47qJEg6LsW3Ye46-3_SEodVEFWXc), [Note 3.3-3.6](https://inst.eecs.berkeley.edu/~cs188/textbook/games/expectimax.html)

## Run All Commands In One Go

```console
python pacman.py -p ReflexAgent -l testClassic

python pacman.py --frameTime 0 -p ReflexAgent -k 1

python pacman.py --frameTime 0 -p ReflexAgent -k 2

python autograder.py -q q1

python autograder.py -q q2

python pacman.py -p MinimaxAgent -l minimaxClassic -a depth=4

python pacman.py -p MinimaxAgent -l trappedClassic -a depth=3

python pacman.py -p AlphaBetaAgent -a depth=3 -l smallClassic

python autograder.py -q q3

python autograder.py -q q4

python pacman.py -p ExpectimaxAgent -l minimaxClassic -a depth=3

python pacman.py -p AlphaBetaAgent -l trappedClassic -a depth=3 -q -n 10

python pacman.py -p ExpectimaxAgent -l trappedClassic -a depth=3 -q -n 10

python autograder.py -q q5

```
