#Name: Adalynn Cadence Everly   ID#: 1001852753     NetID: MXT2753
#Name: Chime Nguyen             ID#: 1001991344     NetID: JXN1344
# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

#region ReflexAgent
class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.
    
    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """
    
    #region getAction
    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.
        
        getAction chooses among the best options according to the evaluation function.
        
        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()
        
        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best
        
        "Add more of your code here if you want to"
        
        return legalMoves[chosenIndex]
    #endregion
    
    #region evaluationFunction
    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.
        
        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.
        
        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.
        
        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
        "*** YOUR CODE HERE ***"
        #FEATURE ENGINEERING FOR REFLEX AGENT- AKA STATE-ACTION SCORE
        #The reflex agent doesn't plan ahead; it only ranks the *immediate*
        #successor state that would happen if we take `action` now.
        #So our job is to combine a few "obvious" signals:
        #1) Food: move toward the closest dot (and generally reduce dots left)
        #2) Ghosts: avoid active ghosts that are too close
        #3) Scared ghosts: if they're scared, it's safe to chase them
        #4) Small preference against STOP (wastes time, costs points)
        
        #Start from the built-in game score for the successor.
        #includes things like eating food (+10), dying (huge -),
        # and the living penalty.
        score = successorGameState.getScore()
        
        #FOOD FEAT'S
        food_list = newFood.asList()  #note: Grid -> list of (x,y)
        #If there is food left, encourage moving toward the closest one.
        #Using 1/(d+1) makes "closer is much better" without exploding at d=0.
        if food_list:
            closest_food_dist = min(util.manhattanDistance(newPos, f) for f in food_list)
            score += 10.0 / (closest_food_dist + 1.0)
            #Also (lightly) prefer states with fewer remaining dots.
            #This helps prevent "thrashing" without making progress.
            score -= 2.0 * len(food_list)
        #GHOST FEAT'S
        #For each ghost:
        #-if it's active (not scared), being very close is dangerous -> big penalty
        #-if it's scared, being close is good -> reward (eat it)
        for ghost_state, scared_time in zip(newGhostStates, newScaredTimes):
            ghost_pos = ghost_state.getPosition()
            d = util.manhattanDistance(newPos, ghost_pos)
            if scared_time == 0:
                #Active ghost: if it's within 1 step, treat as basically losing.
                #(Even if not technically losing *this* frame, it's usually death.)
                if d <= 1:
                    return -float('inf')
                # Otherwise, still penalize being nearby.
                score -= 3.0 / (d + 0.5)
            else:
                # Scared ghost: reward getting closer so we can eat it.
                score += 4.0 / (d + 1.0)
        #ACTION PREFERENCE FEAT
        #STOP is rarely correct: it burns a move and doesn't change the board.
        if action == Directions.STOP:
            score -= 5.0
        return score
        #return successorGameState.getScore()
    #endregion
#endregion

#region scoreEvaluationFunction
def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.
    
    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()
#endregion

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.
    
    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.
    
    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """
    
    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """
    
    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.
        
        Here are some method calls that might be useful when implementing minimax.
        
        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1
        
        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action
        
        gameState.getNumAgents():
        Returns the total number of agents in the game
        
        gameState.isWin():
        Returns whether or not the game state is a winning state
        
        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        
        """
        initial index is 0 (starts with pacman)
        evaluation function is passed in, hence there is no need to reference the scoreEvaluationFunction
        depth is a variable that can be modified that increments when the next turn is pacman's turn
        """
        
        "*** YOUR CODE HERE ***"
        
        # Set the best value and action
        best_value = -float('inf')
        best_action = None
        
        # Obtain the successor states from the first node
        for action in gameState.getLegalActions(self.index):
            successor = gameState.generateSuccessor(self.index, action)
            value = self.value(successor, 1, 0)
            
            # Check if the current value is better than the stored best value
            if value > best_value:
                # Update the best value and action to take
                best_value = value
                best_action = action
                
        return best_action
        util.raiseNotDefined()
    

    """Helper Function - Value Pseudocode
    def value(state):
        if the state is a terminal state: return the state's utility
        if the next agent is MAX: return max-Value(state)
        if the next agent is MIN: return min-value(state)
    """
    def value(self, gameState: GameState, agentIndex, depth):
        # Terminal states is whether the Pacman wins or loses the game or if the tree reached its max depth
        # (or else, it could run forever)
        if gameState.isWin() or gameState.isLose() or depth == self.depth:
            # Due to to us writing a better score evaluation, there should be
            # no calls made to scoreEvaluationFunction
            return self.evaluationFunction(gameState)
        
        # Obtain the agent's index via some other means since it is not obtainable by any of the
        # Pacman functions related to game state
        
        # Check if it is the MAX agent's turn (Pacman)
        if agentIndex == 0:
            return self.maxValue(gameState, agentIndex, depth)
        
        # Check if it is the MIN agent's turn (any of the ghosts)
        if agentIndex != 0:
            return self.minValue(gameState, agentIndex, depth)
        
        util.raiseNotDefined()
        
    """Helper Function - Max-Value Pseudocode
    def max-value(state):
        initialize v = -infinity
        for each successor of state:
            v=max(v, min-value(successor)) if one agent OR v=max(v, value(successor)) if multiple agents
        return v
    """
    def maxValue(self, gameState: GameState, agentIndex, depth):
        # initialize v = -infinity
        v = float('-inf')
        
        # Increment the agent index
        nextAgent = agentIndex + 1
        
        # for each successor of state: (which requires obtaining an action from the agent)
        # Because there is no easy way to obtain the agentIndex as easily
        for action in gameState.getLegalActions(agentIndex):
            # Obtaining a successor requires an agent index and the possible actions
            successor = gameState.generateSuccessor(agentIndex, action)
            
            # v=max(v, value(successor))
            v = max(v, self.value(successor, nextAgent, depth))
        
        return v
    
    """Helper Function - Min-Value Pseudocode
    def min-value(state):
        initialize v = +infinity
        for each successor of state:
            v=min(v, max-value(successor))
        return v
    """
    def minValue(self, gameState: GameState, agentIndex, depth):
        # initialize v = +infinity
        v = float('inf')
        
        # Increment the agent index
        nextAgent = agentIndex + 1
        nextDepth = depth
        
        # Check if the next agent's turn is Pacman's turn
        if nextAgent == gameState.getNumAgents():
            # Set the next agent to Pacman and increase the depth counter
            nextAgent = 0
            nextDepth += 1
        
        # Obtain the successor states
        # for each successor of state:
        for action in gameState.getLegalActions(agentIndex):
            successor = gameState.generateSuccessor(agentIndex, action)
            
            # v=min(v, value(successor))
            v = min(v, self.value(successor, nextAgent, nextDepth))
        
        return v

#region AlphaBetaAgent
class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """
    """
    So this is literally Minimax (Q2) + alpha/beta pruning from the notes (3.2.1).
    Same tree, same values, just fewer nodes that are expanded.
    IMPORTANT autograder rules- from the instruct:
    1. Process children in the exact order getLegalActions returns (no reordering).
    2. Don't prune on equality: use strict > and < (NOT >=, <=).
    """
    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        #Root is always Pacman (agent 0), so root is a MAX node. We'll choose the action whose child has the best minimax value.
        best_value=-float('inf')
        best_action=None
        #Alpha/Beta start as the widest possible bounds.
        #alpha=best value MAX (Pacman) can guarantee so far
        #beta=best value MIN (ghosts) can guarantee so far
        alpha=-float('inf')
        beta=float('inf')
        #Iterate in the given order (autograder expects this exact ordering).
        for action in gameState.getLegalActions(self.index):
            successor = gameState.generateSuccessor(self.index, action)
            #After Pacman moves, the next agent is ghost 1, depth counter starts at 0
            value = self.abValue(successor, 1, 0, alpha, beta)
            #Standard MAX selection at root
            if value > best_value:
                best_value = value
                best_action = action
            # Since root is MAX, we update alpha after we learn a better option.
            alpha = max(alpha, best_value)
        return best_action
    #region abValue
    #ALPHA-BETA HELPER FUNCT
    def abValue(self, gameState: GameState, agentIndex, depth, alpha, beta):
        """
        Same job as Q2's value():
        -The terminal / depth limit=>evaluate, -The Pacman to move => MAX node
        -The ghost to move  => MIN node
        The only difference from Q2 is we also carry alpha and beta.
        """
        #Terminal or cutoff: stop expanding (notes call this "terminal test", & "depth-limited search" where we use evaluationFunction).
        if gameState.isWin() or gameState.isLose() or depth == self.depth:
            return self.evaluationFunction(gameState)
        # Decide which layer type we're on
        if agentIndex == 0:
            return self.abMaxValue(gameState, agentIndex, depth, alpha, beta)
        else:
            return self.abMinValue(gameState, agentIndex, depth, alpha, beta)
    #endregion
    
    #region abMaxValue
    def abMaxValue(self, gameState: GameState, agentIndex, depth, alpha, beta):
        """
        MAX node (Pacman). From the notes:
        
        v = -infinity
        for child in successors:
            v = max(v, value(child))
            if v > beta: prune
            alpha = max(alpha, v)
        return v
        
        We prune when v is strictly > beta (NOT >=) per the autograder.
        """
        v = -float('inf')
        nextAgent = agentIndex + 1   #Pacman (0) -> first ghost (1)
        for action in gameState.getLegalActions(agentIndex):
            successor = gameState.generateSuccessor(agentIndex, action)
            #Compute minimax value of the child
            v = max(v, self.abValue(successor, nextAgent, depth, alpha, beta))
            #Prune: if MAX already found something strictly better than beta,
            #MIN parent will never choose this branch.
            if v > beta:   # strict '>' (no prune on equality)
                return v
            #Update alpha after learning a better MAX option
            alpha = max(alpha, v)
        return v
    #endregion
    
    #region abMinValue
    def abMinValue(self, gameState: GameState, agentIndex, depth, alpha, beta):
        """
        MIN node (ghost). From the notes:
        
        v = +infinity
        for child in successors:
            v = min(v, value(child))
            if v < alpha: prune
            beta = min(beta, v)
        return v
        
        Depth handling matches your partner's Q2:
        - Depth increases only after the LAST ghost moves and we wrap to Pacman.
        """
        v = float('inf')
        nextAgent = agentIndex + 1
        nextDepth = depth
        #If this ghost was the last agent, next turn cycles back to Pacman
        #AND we've completed one full ply (Pacman + all ghosts), so depth += 1.
        if nextAgent == gameState.getNumAgents():
            nextAgent = 0
            nextDepth += 1
        for action in gameState.getLegalActions(agentIndex):
            successor = gameState.generateSuccessor(agentIndex, action)
            # Compute minimax value of the child
            v = min(v, self.abValue(successor, nextAgent, nextDepth, alpha, beta))
            # Prune: if MIN already found something strictly worse than alpha,
            # MAX parent will avoid this branch.
            if v < alpha:  # strict '<' (no prune on equality)
                return v
            # Update beta after learning a better MIN option
            beta = min(beta, v)
        return v
        #util.raiseNotDefined()
    #endregion
#endregion

#region ExpectimaxAgent
class ExpectimaxAgent(MultiAgentSearchAgent):
    """
    Your expectimax agent (question 4)
    """
    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction
        
        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        #Expectimax is minimax where ghosts are not assumed to be optimal.
        #Instead, each ghost is modeled as choosing *uniformly at random* from its legal actions.
        #Pacman is still a maximizer, but ghosts become "chance" nodes
        #that return an *expected value* (average of child values).
        num_agents=gameState.getNumAgents()
        def next_agent_and_depth(agent_index, depth_left):
            next_index = (agent_index + 1) % num_agents
            if next_index == 0:
                return next_index, depth_left - 1
            return next_index, depth_left
        def exp_value(state, agent_index, depth_left):
            if state.isWin() or state.isLose():
                return self.evaluationFunction(state)
            if depth_left == 0:
                return self.evaluationFunction(state)
            actions = state.getLegalActions(agent_index)
            if not actions:
                return self.evaluationFunction(state)
            if agent_index == 0:
                #Pacman: choose the action with the maximum expected value
                best = -float('inf')
                for a in actions:
                    succ = state.generateSuccessor(agent_index, a)
                    nxt_agent, nxt_depth = next_agent_and_depth(agent_index, depth_left)
                    best = max(best, exp_value(succ, nxt_agent, nxt_depth))
                return best
            else:
                #Ghost: chance node -> average child values (uniform probability)
                total = 0.0
                prob = 1.0 / len(actions)
                for a in actions:
                    succ = state.generateSuccessor(agent_index, a)
                    nxt_agent, nxt_depth = next_agent_and_depth(agent_index, depth_left)
                    total += prob * exp_value(succ, nxt_agent, nxt_depth)
                return total
        best_action = Directions.STOP
        best_value = -float('inf')
        for action in gameState.getLegalActions(0):
            successor = gameState.generateSuccessor(0, action)
            if num_agents == 1:
                v = exp_value(successor, 0, self.depth - 1)
            else:
                v = exp_value(successor, 1, self.depth)
            if v > best_value:
                best_value = v
                best_action = action
        return best_action
        #util.raiseNotDefined()
#endregion

#region betterEvaluationFunction
def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).
    
    DESCRIPTION: <write something here so we know what you did>
    Since we can no longer rely on actions, we have to rely on the states themselves to determine the optimal movement.
    Using the current game state that is passed in, we obtained the possible capsules, and took a moderate approach to
    obtaining the closest food without running into a risk or dying. The score is kept low to avoid as much risk. In the
    case of a ghost, the Pacman will always avoid death, and when the ghost is scared, it would only chase the ghost down
    if it is plausible to get the scared ghost before the timer expires. When the ghost and a capsule is nearby, the
    capsule is used to help scare the ghost away. 
    
    Other Notes:
    - The function should evaluate the state of the game rather than the current actions.
    - Likely based on the evaluation function from the Reflex Agent class.
    - Has a depth of 2.
    - Must win at least 5 times to gain any additional points, and at least once to get 1 point.
    """
    "*** YOUR CODE HERE ***"
    # Obtain useful information extracted from the GameState (pacman.py)
    newPos = currentGameState.getPacmanPosition()
    newFood = currentGameState.getFood()
    newGhostStates = currentGameState.getGhostStates()
    newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
    #vvvvADDEDvvvv-
    capsules = currentGameState.getCapsules()
    #^^^^Added^^^
    # Start from the built-in game score for the successor.
    # includes things like eating food (+10), dying (huge -),
    # and the living penalty.
    score = currentGameState.getScore()
    #vvvvADDEDvvvv
    #MOVE TOWARD FOOD
    food_list=newFood.asList()
    if food_list:
        # Being 1 step closer to food is usually worth *something*,
        # but not worth dying for. That's why this is moderate.
        closest_food=min(manhattanDistance(newPos,f) for f in food_list)
        score+=10.0/(closest_food+1.0)   #uses the project hint: Dist recip
        # Finishing the board matters: fewer dots left is better.
        # Kept small so it doesn't override safety.
        score-=1.5*len(food_list)
    #scared=points, ACTIVE GHOSTS=DANGER-GHOSTS
    active_dists=[]
    scared_info=[]
    for gState,scared_time in zip(newGhostStates,newScaredTimes):
        gpos=gState.getPosition()
        d=manhattanDistance(newPos,gpos)
        if scared_time==0:
            active_dists.append(d)
        else:
            scared_info.append((d, scared_time))
    # If an active ghost is right next to us, this state is basically losing.
    # This matches how humans play: don't step into death.
    if active_dists:
        closest_active=min(active_dists)
        if closest_active <= 1:
            return -float('inf')
        # Penalize being close to danger.
        # I keep the constant small-ish because the *real* death penalty is already in score.
        score -= 4.0 / (closest_active + 0.5)
    #Scared ghosts: only chase if we can actually reach before the timer ends.
    #This prevents "chase forever" behavior.
    for d,scared_time in scared_info:
        if d<=scared_time:
            score+=20.0/(d+1.0) #Eating ghost is worth a lot (+200), so this reward can be stronger.
    #EMRGENCY TOOLS CAPSULES
    if capsules:
        closest_cap=min(manhattanDistance(newPos, c) for c in capsules)
        # Capsules are most useful when an active ghost is near.
        if active_dists and min(active_dists) <= 4:
            score += 15.0/(closest_cap + 1.0)
        else:
            #Still a slight preference to not ignore them completely.
            score+=2.0/(closest_cap+1.0)
    return score
    #util.raiseNotDefined()
#endregion

# Abbreviation
better = betterEvaluationFunction
