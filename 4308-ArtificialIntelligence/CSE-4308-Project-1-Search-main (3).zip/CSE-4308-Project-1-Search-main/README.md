# CSE 4308 - Project 1 Search

Welcome!

This Project 1 repository is based on [CS 188 FA25 Project 1: Search](https://inst.eecs.berkeley.edu/~cs188/fa25/projects/proj1/).

## Synopsis

Students implement (generalized) depth-first, breadth-first, uniform cost, and A* search algorithms. These algorithms are used to solve navigation and traveling salesman problems in the Pacman world.

| Files You Will Edit | |
| :--- | :--- |
| `search.py` | Where all of your search algorithms will reside. |
| `searchAgents.py` | Where all of your search-based agents will reside. |

| Files You Might Want To Look At | |
| :--- | :--- |
| `pacman.py` | The main file that runs Pacman games. This file describes a Pacman GameState type, which you use in this project. |
| `game.py` | The logic behind how the Pacman world works. This file describes several supporting types like AgentState, Agent, Direction, and Grid. |
| `util.py` | Useful data structures for implementing search algorithms. |

## Files to Edit and Submit

You will fill in portions of `search.py` and `searchAgents.py` during the assignment. Once you have completed the assignment, you will submit these files to Gradescope (for instance, you can upload all .py files in the folder). Please do not change the other files in this distribution.

## Evaluation

Your code will be autograded for technical correctness. Please do not change the names of any provided functions or classes within the code, or you will wreak havoc on the autograder. However, the correctness of your implementation – not the autograder’s judgements – will be the final judge of your score. If necessary, we will review and grade assignments individually to ensure that you receive due credit for your work.

## Academic Dishonesty

We will be checking your code against other submissions in the class for logical redundancy. If you copy someone else’s code and submit it with minor changes, we will know. These cheat detectors are quite hard to fool, so please don’t try. We trust you all to submit your own work only; please don’t let us down. If you do, we will pursue the strongest consequences available to us.

## Topics Needed For This Project

Uninformed Search: [Video 2](https://www.youtube.com/watch?v=-Xx0QSFYfIQ), [Note 1.2-1.3](https://inst.eecs.berkeley.edu/~cs188/textbook/search/state.html)
A* Search and Heuristics: [Video 3](https://www.youtube.com/watch?v=Mlwrx7hbKPs), [Note 1.4-1.5](https://inst.eecs.berkeley.edu/~cs188/textbook/search/informed.html)
