# Chime Nguyen  ID#: 1001991344  NetID: JXN1344
# Adalynn Cadence Everly  ID#: 1001852753  NetID: MXT2753

# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
        state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem: SearchProblem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """

    """
    NOTES - Chime Nguyen
    - On the Search slide deck, slide 36: "Implementation: Fringe is a LIFO stack"
    - In the util.py: Stack has the following functions:
        - __init__(self)
        - push(self, item): Appends the item to the end
        - pop(self)
        - isEmpty(self)
    """

    """
    GRAPH SEARCH PSEUDO-CODE
    function Graph-Search(problem, fringe) return a solution, or failure
        closed <- an empty set
        fringe <- Insert(Make-Node(Initial-State[problem]), fringe)
        loop do
            if fringe is empty then return failure
            node <- Remove-Front(fringe)
            if Goal-Test(problem, State[node]) then return node
            if State[node] is not in closed then
                add State[node] to closed
                for child-node in Expand(State[node], problem) do
                    fringe <- Insert(child-node, fringe)
                end
        end
    """

    "*** YOUR CODE HERE ***"
    start = problem.getStartState()
    if problem.isGoalState(start):
        return []

    frontier = util.Stack()
    frontier.push((start, []))   # (state, actions_to_reach_state)

    visited = set()              # states we have expanded already

    while not frontier.isEmpty():
        state, actions = frontier.pop()

        # If we already expanded this state via some other path, skip it.
        # This is what prevents infinite loops while still allowing duplicates on the fringe.
        if state in visited:
            continue
        visited.add(state)

        # Goal test after pop/expand selection (matches project tests)
        if problem.isGoalState(state):
            return actions

        # Push successors in the order returned.
        # Since this is a stack, the LAST successor returned is explored FIRST.
        for succ, action, _cost in problem.getSuccessors(state):
            if succ not in visited:
                frontier.push((succ, actions + [action]))

    return []


    # print("Start:", problem.getStartState())
    #util.raiseNotDefined()

def breadthFirstSearch(problem: SearchProblem):
    """Search the shallowest nodes in the search tree first."""

    """
    NOTES - Chime Nguyen
    - On the Search slide deck, slide 41: "Implementation: Fringe is a FIFO queue"
    - In the util.py: Queue has the following functions:
        - __init__(self)
        - push(self, item): Inserts the item at the beginning
        - pop(self)
        - isEmpty(self)
    """

    """
    PSEUDOCODE Based On Past Lecture Video
    Start with S, pick next shallowlest
    pick based on alphabetical?
    """

    "*** YOUR CODE HERE ***"
    # closed <- an empty set
    closed = set()
    
    # fringe <- INSERT(MAKE-NODE(INITIAL-STATE[problem]), fringe)
    fringe = util.Queue()
    initialState = problem.getStartState()
    # print("Initial:", initialState)
    fringe.push((initialState, [])) # push the initial state and path onto the FIFO queue
    
    # (Print) initial print statements
    # print("Start:", problem.getStartState())
    # print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    # disable the below statement as this is what is causing the states to expand
    # print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    
    # print("//////////////////////////////////////////////////////////////////////////////")
    # if fringe is empty then return failure
    while not fringe.isEmpty():
        # node <- REMOVE-FRONT(fringe)
        currentState, currentPath = fringe.pop()
        
        # if GOAL-TEST(problem, STATE[node]) then return node
        if problem.isGoalState(currentState):
            # print("Reached Goal Node!", "| Final Path: ", currentPath)
            print()
            return currentPath
        
        # add STATE[node] to closed, if it is not already added
        if currentState not in closed:
            closed.add(currentState)
        
            # print(currentState, "____________________________________________________________")
            for successor, action, stepCost in problem.getSuccessors(currentState):
                # if STATE[node] is not in closed then
                if successor not in closed:
                    # add the successor's action into the current action path for said successor
                    successorPath = currentPath + [action]
                    
                    # fringe <- INSERT(child-node, fringe)
                    fringe.push((successor, successorPath))
            # end
    # end
    return []
    util.raiseNotDefined()

def uniformCostSearch(problem: SearchProblem):
    """Search the node of least total cost first."""

    """
    NOTES - Chime Nguyen
    - On the Search slide deck, slide 50: "Fringe is a priority queue"
    - In the util.py: Queue has the following functions:
        - __init__(self)
        - push(self, item, priority)
        - pop(self)
        - isEmpty(self)
        - update(self, item, priority)
    - In the video lecture, it is based on the cost you have encountered on this path.
    - The assignment mentions that it should be implemented with graph search algorithm.
    """

    """
    PSEUDOCODE Based On Past Lecture Video
    Given search problem...
    Expand from S to get nodes in fringe
    Pick based on lowest cost, check again
    Pick next lowest, check again
    Even if goal node is available, pick nest lowest cost and check again
    """

    "*** YOUR CODE HERE ***"

    """Make sure to comment out the print statements before testing with CTRL + / (or CMD + /)"""
    # closed <- an empty set
    closed = set()

    # fringe <- INSERT(MAKE-NODE(INITIAL-STATE[problem]), fringe)
    fringe = util.PriorityQueue()
    initialState = problem.getStartState()
    # print("Initial:", initialState)
    fringe.push(initialState, fringe)

    # (UCS Strategy) Add and set cost components that tracks the final cost
    currentCost = {}
    currentCost[initialState] = 0
    # print("Current Cost Nodes:", currentCost, "| Current Cost:", currentCost[initialState])

    # Add and set past actions components that tracks the final path
    pastActions = {}
    pastActions[initialState] = []
    # print("Past Actions Path:", pastActions, "| Past Actions:", pastActions[initialState])
    
    # (Print) initial print statements
    # print("Start:", problem.getStartState())
    # print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    # disable the below statement as this is what is causing the states to expand
    # print("Start's successors:", problem.getSuccessors(problem.getStartState()))

    # print("//////////////////////////////////////////////////////////////////////////////")
    # if fringe is empty then return failure
    while not fringe.isEmpty():
        # node <- REMOVE-FRONT(fringe)
        currentState = fringe.pop()
        # print("Current:", currentState)
        
        # if GOAL-TEST(problem, STATE[node]) then return node
        if problem.isGoalState(currentState):
            # print("Reached Goal Node!", "| Final Cost:", currentCost[currentState], "| Final Path: ", pastActions[currentState])
            return pastActions[currentState]
        
        # if STATE[node] is not in closed then
        if currentState not in closed:
            # add STATE[node] to closed
            closed.add(currentState)
            
            # for child-node in EXPAND(STATE[node], problem) do
            # print(currentState, "____________________________________________________________")
            for successor, action, stepCost in problem.getSuccessors(currentState):
                # print("Successor:", successor, "| Action:", action, "| stepCost:", stepCost, "| Current Cost:", currentCost[currentState])
                # (Print) obtain as much information about the current state of the game
                
                # (UCS Strategy) add the cost of the current state
                newCost = currentCost[currentState] + stepCost
                
                # (UCS Strategy + Priority Queue) check if the successor has not been visited or if it has a cheaper cost
                if successor not in currentCost or newCost < currentCost[successor]:
                    # update the current cost with the new cost
                    currentCost[successor] = newCost
                    
                    # add the successor's action into the past actions for said successor
                    pastActions[successor] = pastActions[currentState] + [action]
                    
                    # update the fringe with the successor and the new cost afterwards
                    fringe.update(successor, newCost)
            # end
    # end
    return []
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem: SearchProblem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""

    """
    NOTES
    The fringe should use a Priority Queue as UCS relies on a Priority Queue to identify cost
    A* Search orders by the sum: f(n) = g(n) + h(n)
    """
    
    "*** YOUR CODE HERE ***"
    # fringe <- INSERT(MAKE-NODE(INITIAL-STATE[problem]), fringe)
    fringe = util.PriorityQueue()
    initialState = problem.getStartState()
    # push the initial state and path onto the priority queue
    fringe.push((initialState, [], 0), heuristic(initialState, problem))
    
    # (Print) initial print statements
    # print("Start:", initialState)
    # print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    # disable the below statement as this is what is causing the states to expand
    # print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    
    # store the best lowest cost from each state
    visitedStates = {}
    
    while not fringe.isEmpty():
        # node <- REMOVE-FRONT(fringe)
        currentState, currentPath, currentCost = fringe.pop()
        # print("Current State:", currentState, "| Current Path:", currentPath, "| Current Cost:", currentCost)
        
        # if GOAL-TEST(problem, STATE[node]) then return node
        if problem.isGoalState(currentState):
            # print("Reached Goal Node!", "| Final Cost:", currentCost[currentState], "| Final Path: ", currentPath[currentState])
            return currentPath
        
        # check if state was not visited or if an alternative, cheaper path has been found
        if currentState not in visitedStates or currentCost < visitedStates[currentState]:
            
            # set the cost to the visited state
            visitedStates[currentState] = currentCost
            
            # for child-node in EXPAND(STATE[node], problem) do
            # print(currentState, "____________________________________________________________")
            for successor, action, stepCost in problem.getSuccessors(currentState):
                # Set the new cost, path, and priority of the heuristic
                newCost = currentCost + stepCost
                newPath = currentPath + [action]
                priority = newCost + heuristic(successor, problem)
                
                # fringe <- INSERT(child-node, fringe)
                fringe.push((successor, newPath, newCost), priority)
            # end
    # end

    return[]
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
