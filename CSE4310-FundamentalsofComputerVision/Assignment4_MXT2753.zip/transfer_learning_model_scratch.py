#transfer_learning_model_scratch.py
#NOTE: had to put this in the google colab so it can run alot faster. Hence, Why I put the title on top for all of them. 
#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
from pytorch_lightning.callbacks import EarlyStopping
from pytorch_lightning import Trainer
import os
# TransferNet: Trains ResNet18 from scratch (no pretrained weights, no checkpoints)
class TransferNet(pl.LightningModule):
    def __init__(self, RateOfLearn=1e-3):
        super().__init__()
        self.save_hyperparameters()
        self.backbone = models.resnet18(weights=None)  # No pretrained weights
        FeaturesCount = self.backbone.fc.in_features
        self.backbone.fc = nn.Linear(FeaturesCount, 10)  # For CIFAR10 (10 classes)
    def forward(self, Input):
        return self.backbone(Input)
    def training_step(self, batch, batch_idx):
        Input, Output = batch
        Preds = self(Input)
        Loss = F.cross_entropy(Preds, Output)
        self.log("train_loss", Loss)
        return Loss
    def validation_step(self, batch, batch_idx):
        Input, Output = batch
        Preds = self(Input)
        Loss = F.cross_entropy(Preds, Output)
        Accuracy = (Preds.argmax(dim=1) == Output).float().mean()
        self.log("val_loss", Loss, prog_bar=True)
        self.log("val_acc", Accuracy, prog_bar=True)
    def test_step(self, batch, batch_idx):
        Input, Output = batch
        Preds = self(Input)
        Accuracy = (Preds.argmax(dim=1) == Output).float().mean()
        self.log("test_acc", Accuracy)
    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=self.hparams.RateOfLearn)
# CIFAR10 dataloader
class LoadCIFAR10(pl.LightningDataModule):
    def __init__(self, SizeOfBatch=64):
        super().__init__()
        self.SizeOfBatch = SizeOfBatch
        self.Trans = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor()
        ])
    def setup(self, stage=None):
        self.SetTrain = datasets.CIFAR10(root='.', train=True, download=True, transform=self.Trans)
        self.SetOfVal = datasets.CIFAR10(root='.', train=False, download=True, transform=self.Trans)

    def train_dataloader(self):
        return DataLoader(self.SetTrain, batch_size=self.SizeOfBatch, shuffle=True, num_workers=2)

    def val_dataloader(self):
        return DataLoader(self.SetOfVal, batch_size=self.SizeOfBatch, num_workers=2)

    def test_dataloader(self):
        return DataLoader(self.SetOfVal, batch_size=self.SizeOfBatch, num_workers=2)
# Main: train model from scratch
if __name__ == '__main__':
    ModelFromScratch = TransferNet()
    DataModule = LoadCIFAR10()
    trainer = Trainer(
        max_epochs=10,
        callbacks=[EarlyStopping(monitor='val_loss', patience=3)],
        accelerator='gpu',
        devices=1
    )
    trainer.fit(ModelFromScratch, datamodule=DataModule)
    trainer.test(ModelFromScratch, datamodule=DataModule)