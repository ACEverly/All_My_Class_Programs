#basic_cnn_model.py
#NOTE:had to put this in the google colab so it can run alot faster. Hence, Why I put the title on top for all of them. 
#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torchvision import transforms, datasets
from torch.utils.data import random_split, DataLoader
from pytorch_lightning.callbacks import EarlyStopping
from pytorch_lightning.callbacks import ModelCheckpoint
#Saves best model based on validation loss (TrainingOfLoss)
CallNCheckP=ModelCheckpoint(dirpath='.',filename='imagenette_model',save_top_k=1,monitor='val_loss',mode='min')
#Basic CNN model using 2 conv layers and 2 FC layers
class MyCNN(pl.LightningModule):
    def __init__(self,RateOfLearn=1e-3,RateOfDropout=0.3):
        super().__init__()
        self.save_hyperparameters()
        self.ConvolBlock1=nn.Conv2d(3,32,kernel_size=3,padding=1) #Conv layer: input channels=3, output=32
        self.ConvolBlock2=nn.Conv2d(32,64,kernel_size=3,padding=1) #Conv layer: 64 feature maps
        self.DownSamp=nn.MaxPool2d(2,2) #Downsampling using 2x2 max DownSamp
        self.LayerDrop=nn.Dropout(self.hparams.RateOfDropout) #Dropout for regularization
        self.PoolAdapt=nn.AdaptiveAvgPool2d((7,7))  #Ensures fixed-size input to FC layers
        self.FullConnect1=nn.Linear(64*7*7,128) #First fully connected layer
        self.FullConnect2=nn.Linear(128,10) #Output layer for 10 classes
    def forward(self,Inputs):
        Inputs=self.DownSamp(F.relu(self.ConvolBlock1(Inputs))) #Conv1 + ReLU + Pool
        Inputs=self.DownSamp(F.relu(self.ConvolBlock2(Inputs))) #Conv2 + ReLU + Pool
        Inputs=self.PoolAdapt(Inputs) #Spatial flattening
        Inputs=Inputs.view(Inputs.size(0),-1) #Flatten to vector
        Inputs=self.LayerDrop(F.relu(self.FullConnect1(Inputs))) #FC1 + ReLU + Dropout
        return self.FullConnect2(Inputs) #Final Preds
    def training_step(self,batch,batch_idx):
        Inputs,Labels=batch
        Preds=self(Inputs)
        TrainingOfLoss=F.cross_entropy(Preds,Labels) #Standard classification TrainingOfLoss
        self.log('train_loss',TrainingOfLoss,prog_bar=True)
        return TrainingOfLoss
    def validation_step(self,batch,batch_idx):
        Inputs,Labels=batch
        Preds=self(Inputs)
        TrainingOfLoss=F.cross_entropy(Preds,Labels)
        Accuracy=(Preds.argmax(dim=1)==Labels).float().mean() #Compute accuracy
        self.log('val_loss',TrainingOfLoss,prog_bar=True)
        self.log('val_acc',Accuracy,prog_bar=True)
    def test_step(self,batch,batch_idx):
        Inputs,Labels=batch
        Preds=self(Inputs)
        TrainingOfLoss=F.cross_entropy(Preds,Labels)
        Accuracy=(Preds.argmax(dim=1)==Labels).float().mean()
        self.log('test_loss',TrainingOfLoss)
        self.log('test_acc',Accuracy)
    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(),lr=self.hparams.RateOfLearn)
#Data module for loading Imagenette dataset
class ImageDataLoader(pl.LightningDataModule):
    def __init__(self,DirectOfData='imagenette2-160/train',SizeOfBatch=32):
        super().__init__()
        self.DirectOfData=DirectOfData
        self.SizeOfBatch=SizeOfBatch
        self.TransApplied=transforms.Compose([
            transforms.Resize((224,224)), #Standardized input size for Colab + pretrained nets
            transforms.ToTensor(),])
    def setup(self,stage=None):
        dataset=datasets.ImageFolder(self.DirectOfData,transform=self.TransApplied)
        val_len=int(0.2*len(dataset))
        train_len=len(dataset)-val_len
        self.SetTrain,self.SetOfVal=random_split(dataset,[train_len,val_len])
    def train_dataloader(self):
        return DataLoader(self.SetTrain,batch_size=self.SizeOfBatch,shuffle=True,num_workers=2)
    def val_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.SizeOfBatch,num_workers=2)
    def test_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.SizeOfBatch,num_workers=2)
#Train and test using PyTorch Lightning trainer
if __name__ == '__main__':
    from pytorch_lightning import Trainer
    DataModule=ImageDataLoader()
    LayerCNN=MyCNN()
    trainer=Trainer(
        max_epochs=20,
        callbacks=[EarlyStopping(monitor='val_loss', patience=3),CallNCheckP],
        accelerator='gpu', #Colab GPU enabled
        devices=1)
    trainer.fit(LayerCNN,datamodule=DataModule)
    trainer.test(LayerCNN,datamodule=DataModule)