# regularized_cnn_model.py
#NOTE:had to put this in the google colab so it can run alot faster. Hence, Why I put the title on top for all of them. 
#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torchvision import transforms, datasets
from torch.utils.data import random_split, DataLoader
from pytorch_lightning.callbacks import EarlyStopping
#Regularized CNN model with dropout and augmented dataset
class RegularizedCNN(pl.LightningModule):
    def __init__(self,RateOfLearning=1e-3):
        super().__init__()
        self.save_hyperparameters()
        #Feature extractor with dropout between conv layers
        self.Feat=nn.Sequential(
            nn.Conv2d(3,64,3,padding=1),nn.ReLU(),nn.Dropout(0.25),
            nn.Conv2d(64,128,3,padding=1),nn.ReLU(),nn.Dropout(0.25),
            nn.Conv2d(128,128,3,stride=2,padding=1),nn.ReLU(),)
        #Pred head to make predictions
        self.Pred=nn.Sequential(
            nn.AdaptiveAvgPool2d((1,1)),nn.Flatten(),
            nn.Linear(128,64),nn.ReLU(),nn.Dropout(0.5),
            nn.Linear(64,10))
    def forward(self,Input):
        Input=self.Feat(Input)
        return self.Pred(Input)
    def training_step(self,DataOutput,IndxOfBatch):
        Input,Output=DataOutput
        logits=self(Input)
        Loss=F.cross_entropy(logits,Output)
        self.log("train_loss",Loss)
        return Loss
    def validation_step(self, DataOutput, IndxOfBatch):
        Input,Output=DataOutput
        logits=self(Input)
        Loss=F.cross_entropy(logits,Output)
        Accuracy=(logits.argmax(dim=1)==Output).float().mean()
        self.log("val_loss",Loss,prog_bar=True)
        self.log("val_acc",Accuracy,prog_bar=True)
    def test_step(self, DataOutput, IndxOfBatch):
        Input,Output=DataOutput
        logits=self(Input)
        Accuracy=(logits.argmax(dim=1)==Output).float().mean()
        self.log("test_acc",Accuracy)
    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(),lr=self.hparams.RateOfLearning)
#Augmented data module that applies transformations to Imagenette
class AugmentDataLoader(pl.LightningDataModule):
    def __init__(self,DirectOfData='./data',batch_size=64):
        super().__init__()
        self.DirectOfData=DirectOfData
        self.batch_size=batch_size
        #Training transforms: real-time data augmentation
        self.TransfOfTrain=transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
            transforms.ToTensor(),])
        #Eval transforms: just resize to standard input
        self.TransfOfEval=transforms.Compose([
            transforms.Resize((224,224)),
            transforms.ToTensor(),])
    def setup(self,stage=None):
        full_dataset=datasets.ImageFolder(self.DirectOfData)
        ValOfN=int(len(full_dataset)*0.2)
        TrainN=len(full_dataset)-ValOfN
        self.SetTraining,self.SetOfVal=random_split(full_dataset,[TrainN,ValOfN])
        self.SetTraining.dataset.transform=self.TransfOfTrain #Apply augmentations to training set
        self.SetOfVal.dataset.transform=self.TransfOfEval #Keep val set clean
    def train_dataloader(self):
        return DataLoader(self.SetTraining,batch_size=self.batch_size,shuffle=True)
    def val_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.batch_size)
    def test_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.batch_size)
#Entry point to train and test the model
if __name__ == '__main__':
    from pytorch_lightning import Trainer
    DataModule=AugmentDataLoader(DirectOfData='imagenette2-160') #Use full dataset, not subset
    LayerCNN=RegularizedCNN()
    trainer=Trainer(
        max_epochs=30,
        callbacks=[EarlyStopping(monitor='val_loss',patience=5)],
        accelerator='gpu', #Enable GPU in Colab
        devices=1)
    trainer.fit(LayerCNN,datamodule=DataModule)
    trainer.test(LayerCNN,datamodule=DataModule)