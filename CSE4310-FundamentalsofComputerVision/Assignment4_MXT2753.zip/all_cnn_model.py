#all_cnn_model.py
#NOTE:had to put this in the google colab so it can run alot faster. Hence, Why I put the title on top for all of them. 
#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torchvision import transforms, datasets
from torch.utils.data import random_split, DataLoader
from pytorch_lightning.callbacks import EarlyStopping
#This class defines the All Convolutional Network using PyTorch Lightning.
class MyCNN(pl.LightningModule):
    def __init__(self,RateOfLearn=1e-3):
        super().__init__()
        self.save_hyperparameters()
        #This is the core of the network — it's entirely made of conv layers.
        self.LayerCNN=nn.Sequential(
            nn.Conv2d(3,96,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(96,96,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(96,96,kernel_size=3,stride=2,padding=1),
            #Second block: deeper conv layers
            nn.Conv2d(96,192,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(192,192,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(192,192,kernel_size=3,stride=2,padding=1),
            #Final block: 1x1 conv layers act like fully connected layers
            nn.Conv2d(192,192,kernel_size=3,padding=1),
            nn.ReLU(),
            nn.Conv2d(192,192,kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(192,10,kernel_size=1),
            nn.AdaptiveAvgPool2d((1,1)),
            nn.Flatten(),) #convert from (BData, channels, 1, 1) to (BData, channels)
    def forward(self,Input):
        return self.LayerCNN(Input)
    def training_step(self,BData,IDXOfBatch):
        Input,Output=BData
        PredOutput=self(Input)
        LostTraining=F.cross_entropy(PredOutput,Output)
        self.log("LossOfTraining",LostTraining)
        return LostTraining
    def validation_step(self,BData,IDXOfBatch):
        Input,Output=BData
        PredOutput=self(Input)
        LostTraining=F.cross_entropy(PredOutput,Output)
        acc=(PredOutput.argmax(dim=1)==Output).float().mean()
        self.log("LossOfVal",LostTraining,prog_bar=True)
        self.log("ValOfAcc",acc,prog_bar=True)
    def test_step(self,BData,IDXOfBatch):
        Input,Output=BData
        PredOutput=self(Input)
        acc=(PredOutput.argmax(dim=1)==Output).float().mean()
        self.log("AccOfTraining",acc)
    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(),lr=self.hparams.RateOfLearn)

#This handles loading and preprocessing the Imagenette dataset.
class ImageDataLoader(pl.LightningDataModule):
    def __init__(self,DirectOfData='./data',SizeOfBatch=64):
        super().__init__()
        self.DirectOfData=DirectOfData
        self.SizeOfBatch=SizeOfBatch
        self.TransAndAug=transforms.Compose([
            transforms.Resize((224,224)), #Full image size for Colab/GPU
            transforms.ToTensor(),])
    def setup(self,stage=None):
        DataRaw=datasets.ImageFolder(self.DirectOfData,transform=self.TransAndAug)
        #No subset limit anymore—use full dataset on Colab
        val_size=int(0.2*len(DataRaw))
        train_size=len(DataRaw)-val_size
        self.SetOfTrain,self.SetOfVal=random_split(DataRaw,[train_size,val_size])
    def train_dataloader(self):
        return DataLoader(self.SetOfTrain,batch_size=self.SizeOfBatch,shuffle=True)
    def val_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.SizeOfBatch)
    def test_dataloader(self):
        return DataLoader(self.SetOfVal,batch_size=self.SizeOfBatch)
#Run model training + testing
if __name__=='__main__':
    from pytorch_lightning import Trainer
    DataModule=ImageDataLoader(DirectOfData='imagenette2-160') #Load full dataset
    LayerCNN=MyCNN() #Init model
    PlTrain=Trainer(
        max_epochs=30,
        callbacks=[EarlyStopping(monitor="LossOfVal",patience=4)],
        accelerator='gpu', #Use GPU on Colab
        devices=1)
    PlTrain.fit(LayerCNN,datamodule=DataModule) #Train model
    PlTrain.test(LayerCNN,datamodule=DataModule) #Test model