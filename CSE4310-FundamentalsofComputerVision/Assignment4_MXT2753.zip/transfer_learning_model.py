#transfer_learning_model.py
#NOTE:had to put this in the google colab so it can run alot faster. Hence, Why I put the title on top for all of them. 
#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit: https://github.com/ajdillhoff/CSE6363/blob/main/deep_learning/transfer_learning.ipynb
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
from pytorch_lightning.callbacks import EarlyStopping
from pytorch_lightning import Trainer
import os
import glob
#Grab most recent checkpoint from lightning logs
def get_ckpt():
    ckpts = glob.glob("lightning_logs/version_*/checkpoints/*.ckpt")
    return max(ckpts, key=os.path.getctime) if ckpts else None
#TransferNet: loads pretrained weights from Imagenette model and fine-tunes on CIFAR10
class TransferNet(pl.LightningModule):
    def __init__(self,RateOfLearn=1e-3,IfPretrained=False,PathToCheckpoint=None):
        super().__init__()
        self.save_hyperparameters()
        self.backbone = models.resnet18(weights=None)  # Do not use torchvision pretrained weights
        FeaturesCount = self.backbone.fc.in_features
        self.backbone.fc = nn.Linear(FeaturesCount, 10)  # Replace classification head for CIFAR10 (10 classes)
        if IfPretrained and PathToCheckpoint:
            state = torch.load(PathToCheckpoint, map_location='cpu')["state_dict"]
            state_cleaned = {k.replace("backbone.", "") if "backbone." in k else k: v for k, v in state.items()}
            self.backbone.load_state_dict(state_cleaned, strict=False)  # Load weights loosely (allow for mismatch)
    def forward(self,Input):
        return self.backbone(Input)
    def training_step(self,batch,batch_idx):
        Input,Output = batch
        Preds = self(Input)
        Loss = F.cross_entropy(Preds, Output)
        self.log("train_loss", Loss)
        return Loss
    def validation_step(self,batch,batch_idx):
        Input,Output = batch
        Preds = self(Input)
        Loss = F.cross_entropy(Preds, Output)
        Accuracy = (Preds.argmax(dim=1) == Output).float().mean()
        self.log("val_loss", Loss, prog_bar=True)
        self.log("val_acc", Accuracy, prog_bar=True)
    def test_step(self,batch,batch_idx):
        Input,Output = batch
        Preds = self(Input)
        Accuracy = (Preds.argmax(dim=1) == Output).float().mean()
        self.log("test_acc", Accuracy)
    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=self.hparams.RateOfLearn)
#CIFAR10 dataloader for training and validation
class LoadCIFAR10(pl.LightningDataModule):
    def __init__(self,SizeOfBatch=64):
        super().__init__()
        self.SizeOfBatch = SizeOfBatch
        self.Trans = transforms.Compose([
            transforms.Resize((224,224)),  # Resize to ResNet input
            transforms.ToTensor()
        ])
    def setup(self,stage=None):
        self.SetTrain = datasets.CIFAR10(root='.', train=True, download=True, transform=self.Trans)
        self.SetOfVal = datasets.CIFAR10(root='.', train=False, download=True, transform=self.Trans)
    def train_dataloader(self):
        return DataLoader(self.SetTrain, batch_size=self.SizeOfBatch, shuffle=True, num_workers=2)
    def val_dataloader(self):
        return DataLoader(self.SetOfVal, batch_size=self.SizeOfBatch, num_workers=2)
    def test_dataloader(self):
        return DataLoader(self.SetOfVal, batch_size=self.SizeOfBatch, num_workers=2)
#Main run block: fine-tune model on CIFAR10
if __name__ == '__main__':
    PathToCheckpoint = get_ckpt()  #Automatically find latest checkpoint
    ModelFineTune = TransferNet(IfPretrained=bool(PathToCheckpoint), PathToCheckpoint=PathToCheckpoint)
    DataModule = LoadCIFAR10()
    trainer = Trainer(
        max_epochs=10,
        callbacks=[EarlyStopping(monitor='val_loss', patience=3)],
        accelerator='gpu',  #Colab GPU
        devices=1)
    trainer.fit(ModelFineTune, datamodule=DataModule)
    trainer.test(ModelFineTune, datamodule=DataModule)