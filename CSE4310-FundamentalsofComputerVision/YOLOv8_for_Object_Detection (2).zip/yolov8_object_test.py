#YOLOv8 Object Detection-Demo/Test Scriptm & the Purpose, Real-time object testing + screenshot saver
#Author:Adalynn Everly, Wilmer Soriano, Thanh Tran
import cv2, time, os
from ultralytics import YOLO #Let's do the settings NOTE: let's do something ULTRA simple for the demo. So most of it it basic logic imo.
MODEL_PATH="yolov8n.pt"   #Change to yolov8s.pt if you want better accuracy
IMGSZ=640
SAVE_EVERY_N_FRAMES=30    #Save a screenshot every N frames
OUTPUT_DIR="test_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)
def run_demo():
    model=YOLO(MODEL_PATH)
    cap=cv2.VideoCapture(0)
    if not cap.isOpened():
        print("[ERROR] Could not open webcam.")
        return
    print("[INFO] Press 'q' to quit or ctrl + C| Now Hold objects up to webcam for detection")
    count,total_fps=0,0
    while True:
        start=time.time()
        ret,frame=cap.read()
        if not ret: break
        results=model(frame, imgsz=IMGSZ)
        annotated=results[0].plot() #FPS overlay
        fps=1/(time.time()-start)
        total_fps+=fps
        count+=1
        cv2.putText(annotated, f"FPS: {fps:.2f}",(10,30),
                    cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2) # Save frame every N frames
        if count%SAVE_EVERY_N_FRAMES==0:
            out_path=f"{OUTPUT_DIR}/object_test_{count}.jpg"
            cv2.imwrite(out_path, annotated)
            print(f"[INFO] Saved: {out_path}")# Now we need to Show window
        cv2.imshow("YOLOv8 Object Test",annotated)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    avg_fps=total_fps/count if count else 0
    print(f"[INFO] Average FPS: {avg_fps:.2f}")
    cap.release()
    cv2.destroyAllWindows()
if __name__=="__main__":
    run_demo()
#-----Sources Cited:-----
#Based on examples and API from Ultralytics YOLOv8 and OpenCV documentation.
#Ultralytics. “YOLOv8 Docs.” *Ultralytics Documentation*, https://docs.ultralytics.com/. Accessed 5 Aug. 2025.
#OpenCV. “cv2.VideoCapture, cv2.imshow, cv2.putText.” *OpenCV-Python Documentation*, https://docs.opencv.org/. Accessed 5 Aug. 2025.
#Python Software Foundation. “os.makedirs, time module.” *Python 3 Standard Library*, https://docs.python.org/3/library/. Accessed 5 Aug. 2025.

#----README OR A SHORT NOTE:----
# To Run the Code: python yolov8_object_test.py  
# so to get the graphs and such from the project I did this in the terminal ,also did it for 640X640. Just replace
# imgz= 320 to imgz=640: 
# python -c "from ultralytics import YOLO; YOLO('yolov8n.pt').val(data='coco128.yaml', imgsz=320)  