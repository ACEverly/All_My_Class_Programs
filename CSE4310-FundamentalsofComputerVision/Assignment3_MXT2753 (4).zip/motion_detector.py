#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the MP4 file: East_texas_reduced_sized.mp 
# Credit:Detect regions part: 
# scikit-image developers  https://scikit-image.org/docs/dev/auto_examples/segmentation/plot_regionprops.html
import numpy as np
from skimage.measure import label, regionprops
#had problem here: VVVV
#from skimage.morphology import dilation,square
#from skimage.morphology import dilation,footprint_rectangle as square
from skimage.morphology import dilation,footprint_rectangle
from kalman_filter import KalmanFilter
class MotionDetector:
    def __init__(self,MaxUnseenFrame=5,MotionThresh=25,MatchDistThresh=50,FrameSkipRate=1,MaxTrackers=10):
        self.MaxUnseenFrame=MaxUnseenFrame #we let a tracker stay alive W/out being matched how long
        self.MotionThresh=MotionThresh #threshold for motion detection
        self.MatchDistThresh=MatchDistThresh  #close a detection has to be to match an existing tracker
        self.FrameSkipRate=FrameSkipRate #(FrameSkipRate=1=process all) nthframe
        self.MaxTrackers=MaxTrackers #lim how many objs we're tracking at once
        self.GrayFrameBuff=[] #stores last 3 grayscale frames,list of active KalmanFilters,keeps track of how many frames we’ve seen
        self.ActivTrackers=[]
        self.CountFrame=0
    def _compute_motion(self,FrameOld,FrameMid,FrameLate):
        DiffCurrentPrev=np.abs(FrameLate.astype(np.float32)-FrameMid.astype(np.float32)) #removes static or slow stuff0-basic 3frame differ
        DiffPrevOld=np.abs(FrameMid.astype(np.float32)-FrameOld.astype(np.float32))
        MaskRawMot=np.minimum(DiffCurrentPrev,DiffPrevOld) #filter weak motion-threshold
        MaskRawMot[MaskRawMot<self.MotionThresh]=0
        MaskRawMot[MaskRawMot>=self.MotionThresh]=255
        return MaskRawMot.astype(np.uint8)
    def _detect_regions(self,MotMask):
        #Dilation to make nearby blobs W/ 1 big region it's suppose to help W noise
        #Had problem hereVVV
        #DilatedMask=dilation(MotMask,square(9)) # Dilate connected
        #DilatedMask=dilation(MotMask,footprint_rectangle(9,9)) #9x9 sqr
        DilatedMask=dilation(MotMask,footprint_rectangle((9,9))) #squr 9x9
        LabeledRegions=label(DilatedMask)
        DetectedProps=regionprops(LabeledRegions)
        MotionBlob=[]
        for Region in DetectedProps:
            if Region.area<100:
                continue
            CentY,CentX=Region.centroid
            bbox=Region.bbox  #Top,L,Bot,R
            MotionBlob.append({"centroid": np.array([CentX,CentY]),"bbox": bbox})
        return MotionBlob
    def update(self,CurrGrayFrame):
        self.CountFrame+=1 #3 frames before we can detect motion
        self.GrayFrameBuff.append(CurrGrayFrame)
        if len(self.GrayFrameBuff)<3:
            return []
        if self.CountFrame%self.FrameSkipRate!=0:
            #Reduce lag FrameSkipRate frames
            return [KalmanObj.State[:2] for KalmanObj in self.ActivTrackers] #Three grayscale frames grabe last
        FrameOld,FrameMid,FrameLate=self.GrayFrameBuff[-3:]
        MaskRawMot=self._compute_motion(FrameOld,FrameMid,FrameLate)
        MotionBlob=self._detect_regions(MaskRawMot)
        predictions=[KalmanObj.predict() for KalmanObj in self.ActivTrackers] #predict where each tracker thinks the object will be
        MatchedSet=set() #keeps track of which Kalman filters were matched, match detections to trackers
        for RegionObj in MotionBlob:
            CenterPos=RegionObj["centroid"]
            BestTracker=None
            #only accept matches W/in this radius
            MinDist=self.MatchDistThresh
            for KalmanObj in self.ActivTrackers:
                dist=np.linalg.norm(KalmanObj.State[:2]-CenterPos)
                if dist<MinDist:
                    MinDist=dist
                    BestTracker=KalmanObj
            if BestTracker:
                BestTracker.update(CenterPos)
                MatchedSet.add(BestTracker)
        #cleanup:rm stale trcks,Keep active filters
        StillActivTrckrs=[]
        for KalmanObj in self.ActivTrackers:
            if KalmanObj in MatchedSet:
                KalmanObj.age=0
                StillActivTrckrs.append(KalmanObj)
            else:
                KalmanObj.age+=1
                if KalmanObj.age<self.MaxUnseenFrame:
                    StillActivTrckrs.append(KalmanObj)
        self.ActivTrackers=StillActivTrckrs #New trackers for unmatched detections
        for RegionObj in MotionBlob:
            CenterPos=RegionObj["centroid"]
            if len(self.ActivTrackers)>=self.MaxTrackers:
                break
            if not any(np.linalg.norm(CenterPos-KalmanObj.State[:2])<self.MatchDistThresh for KalmanObj in self.ActivTrackers):
                FreshTrackr=KalmanFilter(CenterPos)
                self.ActivTrackers.append(FreshTrackr)
        return [KalmanObj.State[:2] for KalmanObj in self.ActivTrackers]