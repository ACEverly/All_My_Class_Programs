#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the MP4 file: East_texas_reduced_sized.mp 
# Credit: https://scikit-image.org/docs/dev/auto_examples/segmentation/plot_regionprops.html
import sys
import cv2
import numpy as np
from PySide6.QtWidgets import(QApplication,QLabel,QPushButton,QSlider,QVBoxLayout,QWidget,QFileDialog,QHBoxLayout)
from PySide6.QtGui import QPixmap, QImage
from PySide6.QtCore import Qt
from motion_detector import MotionDetector
class KalmanTrackerApp(QWidget):
    def __init__(self,VidPath):
        super().__init__()
        self.setWindowTitle("The Kalman Motion Tracker") #Load the video and figure out how many frames it has
        self.VidCap=cv2.VideoCapture(VidPath)
        self.FrameMax=int(self.VidCap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.FrameMemo={} #Store frames so we’re not reloading the same ones constantly, Our motion detector instance
        self.MotionSys=MotionDetector()
        self.CurrFrameIdx=2 #Start @ frame two since motion detection needs three frames tot. now the GUI Stuff,image display, slider,& button
        self.VideoLabel=QLabel(alignment=Qt.AlignCenter)
        self.FrameSlider=QSlider(Qt.Horizontal)
        self.BackBtn=QPushButton("<< 60")
        self.NextBtn=QPushButton("60 >>")
        self.FrameSlider.setRange(2,self.FrameMax-1)
        self.FrameSlider.valueChanged.connect(self.SetFrameIdx)
        self.BackBtn.clicked.connect(lambda: self.ShiftTheFrame(-60))
        self.NextBtn.clicked.connect(lambda: self.ShiftTheFrame(60))
        #Let's do the Layout setup
        ButnRow=QHBoxLayout()
        ButnRow.addWidget(self.BackBtn)
        ButnRow.addWidget(self.NextBtn)
        MainLayout=QVBoxLayout(self)
        MainLayout.addWidget(self.VideoLabel)
        MainLayout.addWidget(self.FrameSlider)
        MainLayout.addLayout(ButnRow)
        self.UpdateTheDisplay() #First frame rend Show the first frame & run motion detect
    def ShiftTheFrame(self,Jumpoffset):
        NextIdx=max(2,min(self.FrameMax-1,self.CurrFrameIdx+Jumpoffset)) #Slider forward/backward,clamped to valid range move it 
        self.FrameSlider.setValue(NextIdx)
    def SetFrameIdx(self,Index):
        self.CurrFrameIdx=Index #slider is moved, update frame index, refresh display
        self.UpdateTheDisplay()
    #Load a frame by index, and cache it so we don’t waste time re-decoding it
    def FetchTheFrame(self,Index):
        if Index in self.FrameMemo:
            return self.FrameMemo[Index]
        self.VidCap.set(cv2.CAP_PROP_POS_FRAMES,Index)
        RetVal,frame=self.VidCap.read()
        if not RetVal:
            return None
        RGBFrame=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        self.FrameMemo[Index]=RGBFrame
        return RGBFrame
    def UpdateTheDisplay(self):
        if self.CurrFrameIdx<2:
            return
        # Read 3 frames for motion detection,grayscale frames to feed into the motion detector
        FrameOld=cv2.cvtColor(self.FetchTheFrame(self.CurrFrameIdx-2),cv2.COLOR_RGB2GRAY)
        FrameMid=cv2.cvtColor(self.FetchTheFrame(self.CurrFrameIdx-1),cv2.COLOR_RGB2GRAY)
        FrameNow=cv2.cvtColor(self.FetchTheFrame(self.CurrFrameIdx), cv2.COLOR_RGB2GRAY)
        self.MotionSys.GrayFrameBuff=[FrameOld,FrameMid] #Reset & update the MotionSys W/ the newest frame
        self.MotionSys.update(FrameNow)
        vis_frame=self.FetchTheFrame(self.CurrFrameIdx).copy()  # GDraw tracksn & predicts, et the original RGB frame so we can draw on top of it
        for TrackerObj in self.MotionSys.ActivTrackers:
            TrailPts=np.array(TrackerObj.PositHist,dtype=np.int32)
            for j in range(1,len(TrailPts)):
                cv2.line(vis_frame,tuple(TrailPts[j-1]),tuple(TrailPts[j]),(0,255,0),2)  # Let's do the green trail
            CurrX,CurrY=map(int,TrackerObj.State[:2]) #CurrX[:2]
            #Current position (red), then the actual dot
            cv2.circle(vis_frame,(CurrX,CurrY),6,(255,0,0),-1)
            NextGuessPos=TrackerObj.predict() #predict the new posit (yellow line, yellow circle)
            PredX,PredY=map(int,NextGuessPos)
            #ywllo circle then arrow
            cv2.circle(vis_frame,(PredX,PredY),6,(255,255,0),2)
            cv2.line(vis_frame,(CurrX,CurrY),(PredX,PredY),(255,255,0),1)
        ImgHeight,ImgWidth,NumChans=vis_frame.shape #Qimage convert
        bytes_per_line=NumChans*ImgWidth
        DisplayQImg=QImage(vis_frame.data,ImgWidth,ImgHeight,bytes_per_line,QImage.Format_RGB888)
        self.VideoLabel.setPixmap(QPixmap.fromImage(DisplayQImg))
if __name__=="__main__":
    app=QApplication(sys.argv)
    TrailPts,_=QFileDialog.getOpenFileName(None,"Select Video File",".","Videos (*.mp4 *.avi)")
    if TrailPts:
        window=KalmanTrackerApp(TrailPts)
        window.resize(960,540)
        window.show()
        sys.exit(app.exec())