#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the MP4 file: East_texas_reduced_sized.mp 
#Credit: https://scikit-image.org/docs/dev/auto_examples/segmentation/plot_regionprops.html
import numpy as np
class KalmanFilter:
    def __init__(self,PositStart,DeltaTime=1.0): 
        self.age = 0
        self.State=np.array([PositStart[0],PositStart[1],0,0],dtype=float) # The State=[x,y,vx,vy](from my notes)-start W/ position & assume init vel is 0.
        self.StateVect=np.array([[1,0,DeltaTime,0],[0,1,0,DeltaTime],[0,0,1,0],[0,0,0,1]]) #State transit max-controls posit & V
        self.MotionState=np.array([[1,0,0,0],[0,1,0,0]]) #Observation matx— we only observe position (x, y)
        #Process noise-how much we "trust" the model's internal physics. covariance 
        ProcessNScale=1.0
        self.ProcessNoiseCov=ProcessNScale*np.array([[DeltaTime**4/4,0,DeltaTime**3/2,0],[0,DeltaTime**4/4,0,DeltaTime**3/2],[DeltaTime**3/2,0,DeltaTime**2,0],[0,DeltaTime**3/2,0,DeltaTime**2]])
        #Measurement noise how much we "trust" the actual observations. Covarience
        MeasNScale=5.0
        self.MeasNoiseCov=MeasNScale*np.eye(2)
        #Init uncertainty in our state est
        self.StateUncert=np.eye(4)*500
        self.PositHist=[PositStart] # History keeps track of the object's path over time- keeping trail of object
        self.InactFrame=0 #How long the obj has been unobserved
    def predict(self):
        self.State=self.StateVect@self.State #Predict the next state based on the model (physics)
        self.StateUncert=self.StateVect@self.StateUncert@self.StateVect.T+self.ProcessNoiseCov #Update our belief about the uncertainty & posit pt retrun
        return self.State[:2]
    def update(self,ObservedPos):
        ObservedPos=np.array(ObservedPos) #New measurement (position)
        #We need to calculate the Kalman Gain measurement vs model
        InnovationCov=self.MotionState@self.StateUncert@self.MotionState.T+self.MeasNoiseCov
        KalmanGain=self.StateUncert@self.MotionState.T@np.linalg.inv(InnovationCov)
        #Update st est W/ new observ
        Resid=ObservedPos-self.MotionState@self.State
        self.State+=KalmanGain@Resid
        #Update uncertanty (covariance)
        IdentMat=np.eye(4)
        self.StateUncert=(IdentMat-KalmanGain@self.MotionState)@self.StateUncert #save & reset
        self.PositHist.append(self.State[:2])
        self.InactFrame=0
        #self.age = 0