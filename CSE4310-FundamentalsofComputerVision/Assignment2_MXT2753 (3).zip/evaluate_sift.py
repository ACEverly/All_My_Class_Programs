#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the png: professor dillhoff said i could use Rainer1.png & rainer2.png for the png for the sift matching. 
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/img
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/assignments/assignment2 
#Credit: https://github.com/ajdillhoff/CSE4310/blob/main/bag_of_visual_words.ipynb
import pickle
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
# Load precomputed SIFT BoVW features
with open("sift_features.pkl","rb") as f:
    data=pickle.load(f)
X_train=data["X_train"]
y_train=data["y_train"]
X_test=data["X_test"]
y_test=data["y_test"]
# Train a simple linear SVM
print("Training SVM on SIFT BoVW features...")
clf=SVC(kernel="linear")
clf.fit(X_train,y_train)
# Predict and evaluate
preds=clf.predict(X_test)
acc=accuracy_score(y_test, preds)
print(f"Test Accuracy (SIFT features): {acc * 100:.2f}%")