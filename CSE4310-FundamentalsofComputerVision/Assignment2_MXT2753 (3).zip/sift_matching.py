#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the png: professor dillhoff said i could use Rainer1.png & rainer2.png for the png for the sift matching. 
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/img
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/assignments/assignment2 
#Credit: https://github.com/ajdillhoff/CSE4310/blob/main/bag_of_visual_words.ipynb
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.feature import match_descriptors
def SiftKeypointAndDescriptCompute(image):
    #Converts image to grayscale and computes SIFT keypoints + descriptors.
    gray=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)
    sift=cv2.SIFT_create()
    keypoints,descriptors=sift.detectAndCompute(gray,None)
    return keypoints,descriptors
def KeypointMatch(DescriptOne,DescriptTwo,ThreshRatio=0.75):
    #Performs keypoint matching using Lowe's ratio test. Returns a list of good matches.
    bf=cv2.BFMatcher()
    matches=bf.knnMatch(DescriptOne,DescriptTwo,k=2)
    good=[]
    for m,n in matches:
        if m.distance<ThreshRatio*n.distance:
            good.append((m.queryIdx,m.trainIdx))
    return good

def MatchVerify(DescriptOne,DescriptTwo):
    #Optional verification using skimage's match_descriptors (cross-checked). Can be used to compare against your own matcher.
    # Optional backup: skimage matcher for comparison
    return match_descriptors(DescriptOne,DescriptTwo,cross_check=True)
def draw_matches(ImageOne,KeypointOne,ImageTwo,KeypointTwo,matches):
    #Combines both images side-by-side and visualizes keypoint matches by drawing lines between matched keypoints.
    # Create a new image showing both images side-by-side
    h1,w1=ImageOne.shape[:2]
    h2,w2=ImageTwo.shape[:2]
    canvas=np.zeros((max(h1,h2),w1+w2,3),dtype=np.uint8)
    canvas[:h1,:w1]=ImageOne
    canvas[:h2,w1:w1+w2]=ImageTwo
    for IndexOne,IndexTwo in matches:
        PointOne=tuple(np.round(KeypointOne[IndexOne].pt).astype(int))
        PointTwo=tuple(np.round(KeypointTwo[IndexTwo].pt).astype(int)+np.array([w1,0]))
        color=tuple(np.random.randint(0,255,size=3).tolist())
        cv2.line(canvas,PointOne,PointTwo,color,1)
        cv2.circle(canvas,PointOne,3,color,-1)
        cv2.circle(canvas,PointTwo,3,color,-1)
    plt.figure(figsize=(12,6))
    plt.imshow(canvas)
    plt.axis('off')
    plt.title("Keypoint Matches")
    plt.show()
if __name__ == "__main__":
    # Example usage, replace with your image loading logic, Load example images for SIFT matching (RGB format)
    ImageOne=cv2.cvtColor(cv2.imread("Rainier1.png"),cv2.COLOR_BGR2RGB)
    ImageTwo=cv2.cvtColor(cv2.imread("Rainier2.png"),cv2.COLOR_BGR2RGB)
    # Extract keypoints and descriptors from both images
    KeypointOne,DescriptOne=SiftKeypointAndDescriptCompute(ImageOne)
    KeypointTwo,DescriptTwo=SiftKeypointAndDescriptCompute(ImageTwo)
    # Match descriptors using ratio test
    matches=KeypointMatch(DescriptOne,DescriptTwo)
    print(f"Found {len(matches)} good matches")
    # Visualize matched keypoints with colored lines
    draw_matches(ImageOne,KeypointOne,ImageTwo,KeypointTwo,matches)
    # Optional sanity check using skimage
    MatchSkim=MatchVerify(DescriptOne,DescriptTwo)
    print(f"Skimage cross-checked matches: {len(MatchSkim)}")
