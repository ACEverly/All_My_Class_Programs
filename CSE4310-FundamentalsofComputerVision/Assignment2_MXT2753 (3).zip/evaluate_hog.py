#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the png: professor dillhoff said i could use Rainer1.png & rainer2.png for the png for the sift matching. 
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/img
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/assignments/assignment2 
#Credit: https://github.com/ajdillhoff/CSE4310/blob/main/bag_of_visual_words.ipynb
import pickle
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
# Load precomputed HOG features, Load feature data extracted using HOG
with open("hog_features.pkl","rb")as f:
    data=pickle.load(f)
X_train=data["X_train"]
y_train=data["y_train"]
X_test=data["X_test"]
y_test=data["y_test"]
# Train a simple linear SVM- Train a linear SVM classifier on the HOG features
print("Training SVM on HOG features...")
Classifier=SVC(kernel="linear")
Classifier.fit(X_train,y_train)
# Predict and evaluate, Predict test labels and calculate accuracy
Predis=Classifier.predict(X_test)
acc=accuracy_score(y_test,Predis)
# Print final classification accuracy
print(f"Test Accuracy (HOG features): {acc * 100:.2f}%")