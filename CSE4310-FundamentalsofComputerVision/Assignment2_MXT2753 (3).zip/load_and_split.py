#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the png: professor dillhoff said i could use Rainer1.png & rainer2.png for the png for the sift matching. 
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/img
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/assignments/assignment2 
#Credit: https://github.com/ajdillhoff/CSE4310/blob/main/bag_of_visual_words.ipynb
import numpy as np
from tensorflow.keras.datasets import cifar10
def Cifar10SplitSave(path="cifar10.npz"):
    #Loads the CIFAR-10 dataset from Keras, flattens the labels, and saves it as a .npz file for use in other scripts.
    # Load training and testing data
    (X_train,y_train),(X_test, y_test)=cifar10.load_data()
    # Make sure labels are flat (not 2D arrays)
    y_train=y_train.flatten()
    y_test=y_test.flatten()
    # Save as numpy archive
    np.savez(path,X_train=X_train,y_train=y_train,X_test=X_test,y_test=y_test)
    print(f"Saved CIFAR-10 dataset to {path}")
if __name__=="__main__":
    # Run the split and save when the script is executed directly
    Cifar10SplitSave()