
# Assignment 2 How to run the code, Summary –Keypoint Matching, Feature Extraction, & Classification
**Name:**  Adalynn Everly
**Course:** CSE 4310-Fundamentals of computer visiion  

# How to Run the Code

Follow these steps to execute each part of the assignment:
## 1. Load and Split the Dataset
Download and prepare the CIFAR-10 dataset:

```
python load_and_split.py
```

## 2. Extract Features and Build Bag of Visual Words
Processes images and saves histogram features (HOG and SIFT) into `.pkl` files:

```
python feature_extraction.py
```

## 3. Train and Evaluate Classifiers
Train SVM classifiers using the saved feature vectors:

```
python evaluate_hog.py
python evaluate_sift.py
```

These scripts will load the BoVW representations and print test accuracy to the terminal.

## 4. Visualize SIFT Keypoint Matching

```
python sift_matching.py
```

This displays a side-by-side visualization with keypoints and match lines.
---

## Summary of Results

1. the number of features extracted using each approach

- **SIFT:** Around 500 keypoints per image on average. Some images had as few as 250, others were closer to 600. It really depended on how much texture or contrast was in the image.
- **HOG:** Fixed-size vector of 324 features per image using 8×8 pixel cells and 2×2 blocks. It’s consistent across all images because it’s a dense descriptor, not keypoint-based.


2. the number of correct matches found

Roughly 300+ matches were made between the two mountain images I tested. Most of the matches visually lined up well with
consistent features across the ridge line and sky, so I’d consider the match quality high. There were a few false matches, but overall it was solid without RANSAC filtering. 

3. the accuracy of the classifiers when evaluated on the test set

- **SIFT + SVM:** 26.39% test accuracy
- **HOG + SVM:** 52.58% test accuracy  
HOG gave significantly better results for CIFAR-10 with no parameter tuning or optimization. SIFT struggled with the tiny 32x32 images, which isn't surprising.

# Questions

1. Describe a process for performing keypoint matching using HOG features. The challenge here is that HOG features are typically generated for the entire image.

HOG isn’t designed around keypoints, so you can’t directly match like you would with SIFT. What you can do is divide the image into patches (say 16x16), extract a HOG descriptor from each patch, and treat those patches like "fake keypoints." Then you compare HOG vectors between the two images using something like Euclidean distance to find matches. It’s a workaround, but it works in a basic way. The downside is that it’s not rotation or scale-aware and can easily break if the image shifts too much.

2. Give your own interpretation of the results. Why do you think one feature set performed better than the other? Consider the efficiency of the feature extraction process and the quality of the features themselves.

SIFT underperformed because CIFAR-10 images are just too small for it to shine. There isn’t enough detail in a 32x32 image to get stable keypoints, and a lot of the descriptors end up noisy or meaningless. HOG, on the other hand, works on a grid and captures edge orientations across the whole image, so it doesn’t care if there are strong corners or not—it just gives you structure. That’s why it handled the dataset better. Also, BoVW with SIFT adds an extra abstraction layer that probably hurt more than helped on something this low-res.