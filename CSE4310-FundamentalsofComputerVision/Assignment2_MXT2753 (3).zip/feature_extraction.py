#Name: Adalynn Everly
#CSE4310- Fundamentalls of computer vision 
#Profesor Dillhoff
#Credit to the png: professor dillhoff said i could use Rainer1.png & rainer2.png for the png for the sift matching. 
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/img
#Credit: https://github.com/ajdillhoff/CSE4310/tree/main/assignments/assignment2 
#Credit: https://github.com/ajdillhoff/CSE4310/blob/main/bag_of_visual_words.ipynb
import numpy as np
import cv2
from skimage.feature import hog
from sklearn.cluster import MiniBatchKMeans
import pickle
import os
# TODO: Create feature processing functions for SIFT and HOG
# sift feature extraction 
#Extracts SIFT descriptors from a list of images. Returns stacked descriptors and a list of descriptors per image.
def SiftFeaturesExtract(images,MaxSiftFeat=500):
    sift=cv2.SIFT_create(nfeatures=MaxSiftFeat)
    AllofDescript=[]
    ImagePerDescript=[]
    for idx,img in enumerate(images):
        gray=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
        keypoints,descriptors=sift.detectAndCompute(gray,None)
        if descriptors is not None:
            AllofDescript.append(descriptors)
            ImagePerDescript.append(descriptors)
        else:
            # No keypoints found, append dummy descriptor
            ImagePerDescript.append(np.zeros((1,128),dtype=np.float32))
    stacked=np.vstack(AllofDescript)
    return stacked,ImagePerDescript
#HOG Feature extraction
# Extracts HOG features from each image and returns a numpy array of descriptors.
def HogFeaturesExtract(images,PerCellPixl=(8,8),PerBlckCell=(2,2),Orient=9):
    FeatOfHog=[]
    for img in images:
        gray=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
        feat=hog(gray,
                   orientations=Orient,
                   pixels_per_cell=PerCellPixl,
                   cells_per_block=PerBlckCell,
                   block_norm='L2-Hys',
                   feature_vector=True)
        FeatOfHog.append(feat)
    return np.array(FeatOfHog)
# BUILD BAG OF VISUAL WORDS MODEL
#Clusters descriptors using MiniBatchKMeans into 'vocab_size' visual words, some of it came from notes 
def BuildVisVocab(descriptors,vocab_size=100):
    print(f"Clustering {len(descriptors)} descriptors into {vocab_size} visual words...")
    kmeans=MiniBatchKMeans(n_clusters=vocab_size,random_state=42,batch_size=vocab_size*3)
    kmeans.fit(descriptors)
    return kmeans
#COMPUTE HISTOGRAMS FOR BoVW
# Computes BoVW histograms per image based on the trained k-means model.
def ExtractBowvFeat(ListDescript, ModeofKMeans):
    histograms=[]
    for desc in ListDescript:
        if desc is None or len(desc.shape) < 2:
            hist=np.zeros(ModeofKMeans.n_clusters)
        else:
            labels=ModeofKMeans.predict(desc)
            hist,_=np.histogram(labels,bins=np.arange(ModeofKMeans.n_clusters+1))
            hist=hist.astype(np.float32)
            hist/=np.sum(hist)+1e-6  # avoid division by zero
        histograms.append(hist)
    return np.array(histograms)
# MAIN SCRIPT EXECUTION
if __name__=="__main__":
    # Load the pre-split data
    data=np.load("cifar10.npz",allow_pickle=True)
    # TODO: Extract features from the training data
    X_train=data["X_train"].astype(np.uint8)
    y_train=data["y_train"]
    X_test=data["X_test"]
    y_test=data["y_test"]
    print(X_train[0])
    # My TODO COMPLETE: SIFT Processing
    # SIFT processing
    # Step 1: Extract SIFT descriptors from training data
    AllDescriptSift,TrainDescriptSift=SiftFeaturesExtract(X_train)
    # Step 2: Build vocabulary using k-means clustering (BoVW model)
    KmeansSift=BuildVisVocab(AllDescriptSift)
    # Step 3: Compute BoVW histograms for training data
    X_train_sift=ExtractBowvFeat(TrainDescriptSift, KmeansSift)
    # Step 4: Extract descriptors from test data
    _, TestDesciptSift=SiftFeaturesExtract(X_test)
    # Step 5: Compute BoVW histograms for test data
    X_test_sift=ExtractBowvFeat(TestDesciptSift,KmeansSift)
    # Step 6: Save all SIFT-based BoVW features to file
    sift_output={
        "X_train":X_train_sift,
        "y_train":y_train,
        "X_test":X_test_sift,
        "y_test":y_test}
    with open("sift_features.pkl","wb")as f:
        pickle.dump(sift_output,f)
    # MY TODO HOG processing
    # Step 1: Extract HOG features from both training and testing data
    X_train_hog=HogFeaturesExtract(X_train)
    X_test_hog=HogFeaturesExtract(X_test)
    # Step 2: Save HOG features to file (raw descriptors, no BoVW here)
    hog_output = {
        "X_train":X_train_hog,
        "y_train":y_train,
        "X_test":X_test_hog,
        "y_test":y_test}
    with open("hog_features.pkl","wb")as f:
        pickle.dump(hog_output,f)
#did the TODO'S  above so just put them in the bottom for that reason. 
# TODO: Extract features from the testing data
# TODO: Save the extracted features to a file
