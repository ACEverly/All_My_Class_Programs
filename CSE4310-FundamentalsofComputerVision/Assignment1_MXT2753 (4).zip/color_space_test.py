#Credit to picture png: https://ifeminist.org/tereshkova.html
#Credit to: https://ajdillhoff.github.io/notes/patch_extraction/, and https://ajdillhoff.github.io/notes/color/
#Name: Adalynn Cadence Everly 
#ID#: 1001852753
#CSE 4310-001 Fundamentals of Computer Vision
import argparse
import numpy as np
import cv2
import sys
from img_transforms import rgb_to_hsv,hsv_to_rgb
def ValidateHSVInput(hue,sat,val):
    if not(0<=hue<=360):
        print("Hue must be in [0, 360]")
        sys.exit(1)
    if not (0<=sat<=1)or not(0<=val<=1):
        print("Val & Saturation has to be in [0, 1].")
        sys.exit(1)
def main():
    parser=argparse.ArgumentParser(description="HSV modifier.")
    parser.add_argument("filename",type=str)
    parser.add_argument("hue",type=float)
    parser.add_argument("saturation",type=float)
    parser.add_argument("value",type=float)
    args=parser.parse_args()
    ValidateHSVInput(args.hue,args.saturation,args.value)
    img=cv2.imread(args.filename)/255.0
    hsv=rgb_to_hsv(img)
    hsv[...,0]=(hsv[...,0]+args.hue)%360
    hsv[...,1]=np.clip(hsv[...,1]*args.saturation,0,1)
    hsv[...,2]=np.clip(hsv[...,2]*args.value,0,1)
    ImgOfRBG =(hsv_to_rgb(hsv)*255).astype(np.uint8)
    PushOutFN=args.filename.replace(".png","_modified.png")
    cv2.imwrite(PushOutFN,ImgOfRBG)
if __name__=='__main__':
    main()
