#Credit to picture png: https://ifeminist.org/tereshkova.html
#Credit to: https://ajdillhoff.github.io/notes/patch_extraction/, and https://ajdillhoff.github.io/notes/color/
#Name: Adalynn Cadence Everly 
#ID#: 1001852753
#CSE 4310-001 Fundamentals of Computer Vision
import numpy as np
from numpy.lib.stride_tricks import as_strided
import random
def RGBTransHSV(img):
    r,g,b=img[..., 0],img[...,1],img[...,2]
    MaxVal=np.max(img,axis=2)
    MinVal=np.min(img,axis=2)
    v=MaxVal
    c=MaxVal-MinVal
    s=np.where(v==0,0,c/v)
    h=np.zeros_like(v)
    TheMask=c!=0
    IsRedMax=(r==MaxVal)&TheMask
    IsGreenMax=(g==MaxVal)&TheMask
    IsBlueMax=(b==MaxVal)&TheMask
    h[IsRedMax]=((g-b)[IsRedMax]/c[IsRedMax])%6
    h[IsGreenMax]=((b-r)[IsGreenMax]/c[IsGreenMax])+2
    h[IsBlueMax]=((r-g)[IsBlueMax]/c[IsBlueMax])+4
    h*=60
    h=np.mod(h,360)
    return np.stack((h,s,v),axis=-1)
def HSVTransRGB(hsv):
    h,s,v=hsv[...,0],hsv[...,1],hsv[...,2]
    c=v*s
    h_=h/60.0
    x=c*(1-np.abs(h_%2-1))
    zeros=np.zeros_like(h)
    rgb=np.zeros(hsv.shape)
    Condition=[(0<=h_)&(h_<1),(1<=h_)&(h_<2),(2<=h_)&(h_<3),
        (3<=h_)&(h_<4),(4<=h_)&(h_<5),(5<=h_)&(h_<6)]
    CasesOfRGB=[(c,x,zeros),(x,c,zeros),(zeros,c,x),
        (zeros,x,c),(x,zeros,c),(c,zeros,x)]
    for cond,(RedColor,GreenColor,BlueColor) in zip(Condition,CasesOfRGB):
        rgb[...,0]=np.where(cond,RedColor,rgb[...,0])
        rgb[...,1]=np.where(cond,GreenColor,rgb[...,1])
        rgb[...,2]=np.where(cond,BlueColor,rgb[...,2])
    m=v-c
    rgb+=m[...,np.newaxis]
    return np.clip(rgb,0,1)
def RandCrop(img,size):
    h,w=img.shape[:2]
    if size<=0 or size>min(h,w):
        raise ValueError("crop size is Invalid...ERROR")
    top=random.randint(0,h-size)
    left=random.randint(0,w-size)
    return img[top:top+size,left:left+size]
def PatchExtract(img,PatchesNum):
    h,w,c=img.shape
    SizeOfPatch=h//PatchesNum
    shape=(PatchesNum,PatchesNum,SizeOfPatch,SizeOfPatch,c)
    strides=(SizeOfPatch*img.strides[0],
        SizeOfPatch*img.strides[1],img.strides[0],
        img.strides[1],img.strides[2])
    patches=as_strided(img,shape=shape,strides=strides)
    return patches.reshape(-1,SizeOfPatch,SizeOfPatch,c)
def ImageResize(img,Factr):
    h,w=img.shape[:2]
    new_h,new_w=int(h*Factr),int(w*Factr)
    IDXofY=(np.arange(new_h)/Factr).astype(int)
    IDXofX=(np.arange(new_w)/Factr).astype(int)
    return img[IDXofY[:,None],IDXofX]
def JITColor(img,JITOfHue,JITOfSatur,JITOfGlow):
    hsv=RGBTransHSV(img/255.0)
    DeltaH=random.uniform(-JITOfHue,JITOfHue)
    DeltaS=random.uniform(-JITOfSatur,JITOfSatur)
    DeltaV=random.uniform(-JITOfGlow,JITOfGlow)
    hsv[...,0]=(hsv[...,0]+DeltaH)%360
    hsv[...,1]=np.clip(hsv[...,1]+DeltaS,0,1)
    hsv[...,2]=np.clip(hsv[...,2]+DeltaV,0,1)
    return (HSVTransRGB(hsv)*255).astype(np.uint8)