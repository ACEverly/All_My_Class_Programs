#Credit to picture png: https://ifeminist.org/tereshkova.html
#Credit to: https://ajdillhoff.github.io/notes/patch_extraction/, and https://ajdillhoff.github.io/notes/color/
#Name: Adalynn Cadence Everly 
#ID#: 1001852753
#CSE 4310-001 Fundamentals of Computer Vision
import cv2
import numpy as np
import random
import matplotlib.pyplot as plt
from img_transforms import JITColor, PatchExtract, RandCrop, ImageResize
def SaveAndShowOutput(title,images,PrefixFileName):
    plt.figure(figsize=(12,3))
    for i,img in enumerate(images):
        plt.subplot(1,len(images),i+1)
        plt.imshow(img)
        plt.axis('off')
        if i==0:
            plt.title("Original Image")
        else:
            plt.title(f"{title} {i}")
    plt.tight_layout()
    plt.savefig(f"{PrefixFileName}.png")
    plt.close()
def main():
    img=cv2.imread("tereshkova1.png")#load image of astronaut
    if img is None:
        print("Image isn't found...ERROR")
        return
    img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB) #now the color jitter 
    ImagesThatAreJit=[img]
    for _ in range(4):
        TheHue=random.uniform(-30,30)
        TheSatur=random.uniform(0,0.5)
        TheValGlow=random.uniform(0,0.5)
        Jittrd=JITColor(img,TheHue,TheSatur,TheValGlow)
        ImagesThatAreJit.append(Jittrd)
    SaveAndShowOutput("Color Jitter",ImagesThatAreJit,"output_color_jitter") #let's do a singular random jitter
    TheHue= random.uniform(-30,30)
    TheSatur=random.uniform(0,0.5)
    TheValGlow=random.uniform(0,0.5)
    SiglJit=JITColor(img,TheHue,TheSatur,TheValGlow)
    SoloJitBGR=cv2.cvtColor(SiglJit,cv2.COLOR_RGB2BGR)
    cv2.imwrite("output_color_jitter_single.png",SoloJitBGR) #now the patch extract
    patches=PatchExtract(img,4)  #let's do 16 patches because that seems easy to do according to the notes. Other ones might cut it up unevenly
    for TheNum,patch in enumerate(patches):
        BGRPatch=cv2.cvtColor(patch,cv2.COLOR_RGB2BGR)
        cv2.imwrite(f"output_patch_{TheNum+1:02d}.png",BGRPatch) #now let's crop randomly
    Crop=RandCrop(img,128)
    CroppingBGR=cv2.cvtColor(Crop,cv2.COLOR_RGB2BGR)
    cv2.imwrite("output_random_crop.png",CroppingBGR) #resize the image demo
    IMGResize=[img]
    for Factr in [0.5,1.5,2.0,3.0,8.0]:
        resized=ImageResize(img,Factr)
        IMGResize.append(resized)
        BGRResize=cv2.cvtColor(resized,cv2.COLOR_RGB2BGR)
        cv2.imwrite(f"output_resized_{Factr}x.png",BGRResize)
    SaveAndShowOutput("Resize",IMGResize,"output_resize_demo")
if __name__=="__main__":
    main()