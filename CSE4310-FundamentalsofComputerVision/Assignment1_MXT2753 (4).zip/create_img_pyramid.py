#Credit to picture png: https://ifeminist.org/tereshkova.html
#Credit to: https://ajdillhoff.github.io/notes/patch_extraction/, and https://ajdillhoff.github.io/notes/color/
#Name: Adalynn Cadence Everly 
#ID#: 1001852753
#CSE 4310-001 Fundamentals of Computer Vision
import os
import sys
import numpy as np
from PIL import Image
def PyramidCreator(ThePathImage,levels):
    img=Image.open(ThePathImage)
    CoreName,ext=os.path.splitext(ThePathImage)
    for i in range(1,levels):
        Factr=2**i
        SizeNew=(img.width // Factr, img.height // Factr)
        ResizingImg=img.resize(SizeNew, Image.NEAREST)
        OutFileName=f"{CoreName}_{Factr}x{ext}"
        ResizingImg.save(OutFileName)
if __name__=='__main__':
    if len(sys.argv)!=3:
        print("Usage: python create_img_pyramid.py <image_file> <levels>")
        sys.exit(1)
    ThePathImage=sys.argv[1]
    levels=int(sys.argv[2])
    PyramidCreator(ThePathImage,levels)
