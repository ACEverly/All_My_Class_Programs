//Mary-Rose Tracy
//LAB_0 
//Dillhoff
//
#include <gputk.h>
#include <cublas.h>
#include "device_query.cuh"
#include "vec_add.cuh"
int main(int argc, char **argv) 
{
    gpuTKArg_t args;
    int inputLength;
    float *hostInput1;
    float *hostInput2;
    float *hostOutput;
    float *deviceInput1;
    float *deviceInput2;
    float *deviceOutput;
    args=gpuTKArg_read(argc,argv);
    // TODO: Query and print the device properties here. This will help you answer the questions in Questions.md
    //NOTES: Query & print the device properties
    //gpuTKLog(TRACE,"Querying GPU information...");
    device_query();
    //CHANGED ^^^^
    gpuTKTime_start(Generic, "Importing data and creating memory on host");
    hostInput1 =
        (float *)gpuTKImport(gpuTKArg_getInputFile(args, 0), &inputLength);
    hostInput2 =
        (float *)gpuTKImport(gpuTKArg_getInputFile(args, 1), &inputLength);
    hostOutput = (float *)malloc(inputLength * sizeof(float));
    gpuTKTime_stop(Generic, "Importing data and creating memory on host");
    gpuTKLog(TRACE, "The input length is ", inputLength);
    gpuTKTime_start(GPU, "Allocating GPU memory.");
    // TODO: Allocate GPU memory here
    //NOTES:Allocate GPU memory
    cudaMalloc((void **)&deviceInput1,inputLength*sizeof(float));
    cudaMalloc((void **)&deviceInput2,inputLength*sizeof(float));
    cudaMalloc((void **)&deviceOutput,inputLength*sizeof(float));
    //CHANGED^^^^
    gpuTKTime_stop(GPU,"Allocating GPU memory.");
    gpuTKTime_start(GPU,"Copying input memory to the GPU.");
    // TODO: Copy memory to the GPU here
    //NOTES:Copy memory to the GPU
    cudaMemcpy(deviceInput1,hostInput1,inputLength* sizeof(float),cudaMemcpyHostToDevice);
    cudaMemcpy(deviceInput2,hostInput2,inputLength* sizeof(float),cudaMemcpyHostToDevice);
    //CHANGED^^^^
    gpuTKTime_stop(GPU, "Copying input memory to the GPU.");
    // TODO: Initialize the grid and block dimensions here
    //NOTES:Initialize the grid and block dimensions
    int blockSize=256;
    //^^^per block= # of threads
    //int gridSize=(inputLength+blockSize-1)/blockSize; 
    int gridSize=32; 
    //^^^blocks=number
    //CHANGED^^^^
    gpuTKTime_start(Compute,"Performing CUDA computation");
    // TODO: Launch the GPU Kernel here
    //NOTES:Launch the GPU Kernel
    vec_add<<<32, 128>>>(deviceInput1,deviceInput2,deviceOutput,inputLength);
    cudaDeviceSynchronize();
    //CHANGED^^^^
    gpuTKTime_stop(Compute,"Performing CUDA computation");
    gpuTKTime_start(Copy,"Copying output memory to the CPU");
    // TODO: Copy the GPU memory back to the CPU here
    //NOTES:Copy the GPU memory back to the CPU
    cudaMemcpy(hostOutput,deviceOutput,inputLength* sizeof(float),cudaMemcpyDeviceToHost);
    //CHANGED^^^^
    gpuTKTime_stop(Copy,"Copying output memory to the CPU");
    gpuTKTime_start(GPU,"Freeing GPU Memory");
    // TODO: Free the GPU memory here
    //NOTES:Free the GPU memory
    cudaFree(deviceInput1);
    cudaFree(deviceInput2);
    cudaFree(deviceOutput);
    //gpuTKLog(TRACE, "Freed allocated GPU memory.");
    //CHANGED^^^^
    gpuTKTime_stop(GPU, "Freeing GPU Memory");
    gpuTKSolution(args, hostOutput, inputLength);
    free(hostInput1);
    free(hostInput2);
    free(hostOutput);
    return 0;
}
