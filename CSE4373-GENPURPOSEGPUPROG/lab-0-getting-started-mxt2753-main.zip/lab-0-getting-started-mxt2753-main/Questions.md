# Device Query Questions

//Mary-Rose Tracy 
//ID#:1001852753
1. How many devices are present on the system?
  There are 4 devices present on the system, as stated in the output: "There are 4 devices supporting CUDA.

2. Does the global memory size listed in the device query match the specification for the model?
  For each device (NVIDIA GeForce GTX 1050 Ti), the maximum global memory size is 4234805248 bytes (~4 GB). This matches the specification of the NVIDIA GeForce GTX 1050 Ti, which typically has 4 GB of global memory.

4. If only using a single dimension, what is the maximum block size?
  The maximum block size for a single dimension is 1024 threads, as shown in the line: "Maximum block dimensions: 1024 x 1024 x 64."

5. If only using a single dimension, what is the maximum grid size?
  The maximum grid size for a single dimension is 2147483647, as stated in the output: "Maximum grid dimensions: 2147483647 x 65535 x 65535."
