# CSE 4373/5373 Lab 0

This lab serves as an introduction of the CUDA toolkit as well as a preview of how labs will be completed and submitted in this course.

## Device Query

The code for the first part of the lab is given in `device_query.cu`. This code will query the device and print out some information about it. You will need to compile and run this code to answer the questions in `Questions.md`.

## Vector Addition

### Generating the data

Throughout this course, we will want to verify that our work is correct. A good way to do this is to first implement a CPU version of the algorithm and then compare that output with your GPU implementation. For this lab, the CPU implementation is already provided. This may not be the case in future labs. To generate the data for this lab, you will need to run the following command:

```
make datagen
./build/datagen LAST_4_DIGITS_OF_ID
```

### Writing the Kernel

The files that you need to complete this part are already included in this repository. You will need to complete the `vector_add` function in `vector_add.cu`. This function should add the two vectors `a` and `b` and store the result in `c`.

### Completing the main function

A starting template has been provided in `main.cu`. This outlines the basic process of allocating memory, copying data, executing the kernel, and reading the result. Once you have completed all the TODOs, you can build the final executable with `make`. The following command will run the executable and compare the result to the expected output:

```
./build/main -e data/0/output.raw -i data/0/input0.raw,data/0/input1.raw -t vector
```

Make sure you test all 10 datasets. You can do this by changing the number in the `data/0` directory to the appropriate number.

If you are running on the lab machines, you will need to schedule your job via SLURM. A sample SLURM script is provided in `run.sh`. You can submit your job with the following command:

```
sbatch run.sh
```

## Lab Questions

Each lab will be accompanied by a list of questions that you will need to answer. These questions will be in the `Questions.md` file. You should edit this file and commit your changes to your repository.

## Submission

To submit your lab, you will need to push your changes to GitHub. If you had any new files to add to the repository, you will need to run `git add` on those files first. Then you can run the following commands to commit and push your changes:

```
git commit -m "Completed Lab 0"
git push
```
