#Name: Adalynn Everly
#ID#:1001852753
#R Homework1  Graph Plotting
#university: University of Texas at Arlington 
#Date: 08/27/2025
# Dataset: mtcars (built-in)
# Goal: copy the GeeksforGeeks base plots but with the tweaks, add tweaks from the instructions, and most importantly how to understand the code Most importantly how to use R Studio.
# I'm going to make all the graphs go here autpmatically instead of hsaving them one by one or exporting them one by 1 on my laptop. All the images/outputs go here (clean and easy to find)
# Credit to:https://www.geeksforgeeks.org/r-language/graph-plotting-in-r-programming/
DirectOutput<-"mtcars_plots"
if(!dir.exists(DirectOutput))dir.create(DirectOutput)
# Load the built-in dataset (straight from base R)
library(datasets)
data(mtcars)
# Making sure the data is getting loaded
#get the top 6 rows, Quick stast for each column
head(mtcars)
summary(mtcars)
#//////1D PLOTTING/////
# let's do the Boxplot:
#tutorial uses mpg; I’m switching to wt & let's make it RED
png(file.path(DirectOutput,"BoxplotWTRed.png"),width=800,height=600)
boxplot(
  mtcars$wt,
  col="red",
  main="Boxplot of Car Weights (wt)",
  ylab="Weight (1000 lbs)")
dev.off()
#Three histograms of wt on one row. First uses default breaks, then 15, then 39.
#All in red. Then I reset back to single-plot layout.
png(file.path(DirectOutput,"HistogramsWTRedAnd3Up.png"),width=1400,height=500)
par(mfrow=c(1,3))
hist(mtcars$wt,
     col="red",
     main="Histogram of wt (default)",
     xlab="Weight (1000 lbs)")
hist(mtcars$wt,
     col="red",
     breaks=15,
     main="Histogram of wt (15 breaks)",
     xlab="Weight (1000 lbs)")
hist(mtcars$wt,
     col="red",
     breaks=39,
     main="Histogram of wt (39 breaks)",
     xlab="Weight (1000 lbs)")
#1 plot per page
par(mfrow=c(1,1))
dev.off()
#Let's do Bar plot:
# Using the gear & not the carb and coloring it blue. Like the instructions say.
png(file.path(DirectOutput,"BarplotGearBlue.png"),width=800,height=600)
barplot(
  table(mtcars$gear),
  col="blue",
  main="Barplot of Gears",
  xlab="Number of Gears",
  ylab="Frequency")
dev.off()
#//////2D PLOTTING/////
#Let's do 2D Boxplot: # mpg grouped by carb; & the color is suppose to be  yellow.
png(file.path(DirectOutput,"BoxplotMPGByCarbYellow.png"),width=800,height=600)
boxplot(
  mpg ~ carb,
  data=mtcars,
  col="yellow",
  main="Boxplot of mpg by carb",
  xlab="Number of Carburetors (carb)",
  ylab="Miles per Gallon (mpg)")
dev.off()
# Scatter plot:
# mpg (x) vs drat (y); orange filled circles & the pch has to equal 16).
png(file.path(DirectOutput,"ScatterMPG-VS-DratOrange.png"),width=800,height=600)
plot(mtcars$mpg,mtcars$drat,
  col="orange",
  pch=16,
  main="Scatterplot of mpg vs drat",
  xlab="Miles per Gallon (mpg)",
  ylab="Rear Axle Ratio (drat)")
dev.off()
#NOTE:Done-all images are now in 'mtcars_plots'. I'm assuming In the Word doc  
#I’m suppose to copy & paste W/ this code in sections then dropping matching PNGs right underneath each section so it’s easy to grade.