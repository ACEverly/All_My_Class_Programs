"""HW 2 Question 6 (from assignment): Refer to Lecture 10 PRNG. Write a program applying OFB Mode to generate a pseudo random number sequence, with bit number > 220. 
Further count the number of 0's and 1's of the sequence, showing their numbers are closely the same.
Note: You can use the DES code for the first homework directly for this problem. Please send me your code and report."""
# Name: Adalynn Everly
# ID#: 1001852753
# Class: CSE 4381-001
from typing import Iterator,Tuple,Dict
from collections import defaultdict
import argparse,math,time
#////SECT 1:DES primitive/////
_DES_OK=True
try:
    from Crypto.Cipher import DES as _DES
except Exception:
    _DES_OK=False
def _require_len(x:bytes,n:int,what:str)->None:
    if len(x)!=n:
        raise ValueError(f"{what} must be {n} bytes (got {len(x)})")
def _next_block(key8:bytes,v8:bytes)->bytes:
    #One OFB step: V_{i+1} = E_k(V_i). Returns the *new* V.
    _require_len(key8,8,"DES key")
    _require_len(v8,8,"OFB state (V)")
    if not _DES_OK:
        raise RuntimeError("PyCryptodome not available. Either pip install pycryptodome "
        "or wire in your HW1 DES block cipher here.") #ECB here is deliberate-OFB utilizes the raw block cipher as a PRF on V.
    return _DES.new(key8,_DES.MODE_ECB).encrypt(v8)
#/////SECT 2:Bit generator-MSB-first inside each byte////
def _bits_from_bytes(b:bytes)->Iterator[int]:
    #Yield bits MSB->LSB for each byte.
    for byte in b:
        for i in range(8):
            yield(byte>>(7-i))& 1
#////SECT 3:OFB keystream- Aka streaming)///
def ofb_bitstream(key8: bytes, iv8: bytes) -> Iterator[int]:
    #Infinite gen of keystream bits using DES-OFB. State update per Lecture 10: V_{i+1}=E_k(V_i), output block=V_{i+1}
    _require_len(key8,8,"DES key")
    _require_len(iv8,8,"IV")
    V=iv8
    while True:
        V=_next_block(key8,V)     #advance feedback regi Emit the whole 64-bit blck as 64 keystream bits
        for bit in _bits_from_bytes(V):
            yield bit
#////SECT 4:Driver that *streams* & counts W/out storing/////
def generate_and_count(key8: bytes, iv8: bytes, n_bits: int) -> Tuple[int,int,Dict[int,int],float]:
    #Stream n_bits from OFB, count ones/zeros, and build a tiny runs histogram. Returns: (ones, zeros, runs_hist, elapsed_seconds)
    if n_bits<=220:
        raise ValueError("n_bits must be > 220 (assignment requirement)")
    ones=zeros=0 #runs_hist[len]=how many runs of that exact length were observed
    runs_hist:Dict[int,int]=defaultdict(int)
    prev=None
    run_len=0
    t0=time.time()
    for i,bit in zip(range(n_bits),ofb_bitstream(key8,iv8)):
        #mono/1 bit count
        if bit:ones+=1
        else:zeros+=1
        #runs accounting-simple version enough for the report
        if prev is None:
            prev=bit;run_len=1
        elif bit==prev:
            run_len+=1
        else:
            runs_hist[run_len]+=1
            prev=bit;run_len=1
    #The last run Close it
    if run_len>0:
        runs_hist[run_len]+=1
    elapsed=time.time()-t0
    return ones,zeros,runs_hist,elapsed
#/////SECT 5:Quick sanity stats for report
def monobit_z(ones:int,n:int)->float:
    #Under H0/rand Ones -Binomial(n,0.5)
    mu=n*0.5
    sigma=math.sqrt(n*0.25)
    return 0.0 if sigma==0 else(ones-mu)/sigma
def summarize_runs(runs_hist: Dict[int,int],max_len:int=10)->str:
    if not runs_hist: return "no runs?"
    total_runs=sum(runs_hist.values())
    parts=[]
    for L in range(1,max_len+1):
        c=runs_hist.get(L,0)
        parts.append(f"L={L}: {c} ({(c/total_runs):.2%})")
    more="" if len(runs_hist)<=max_len else" …"
    return "; ".join(parts) + more
#///SECT 6:Tiny CLI/////
def main():
    p=argparse.ArgumentParser(description="DES-OFB PRNG (Lecture 10) — streamy, with comments")
    p.add_argument("--key", default="0123456789ABCDEF",
                   help="8-byte key as 16 hex chars or 8 raw chars (default hex 0123456789ABCDEF)")
    p.add_argument("--iv",  default="FEDCBA9876543210",
                   help="8-byte IV  as 16 hex chars or 8 raw chars (default hex FEDCBA9876543210)")
    p.add_argument("--bits", type=int, default=4096, help="how many bits to generate (>220)")
    p.add_argument("--raw", action="store_true",
                   help="treat --key/--iv as 8-char raw strings instead of hex")
    args=p.parse_args()
    def parse8(s:str)->bytes:
        s=s.strip()
        if args.raw:
            if len(s)!=8:raise SystemExit("raw key/iv must be exactly 8 chars")
            return s.encode("latin1") #Now do the hex path
        if s.startswith("0x"):s=s[2:]
        if len(s)!=16:raise SystemExit("hex key/iv must be exactly 16 hex chars")
        return bytes.fromhex(s)
    key8=parse8(args.key)
    iv8=parse8(args.iv)
    n=args.bits
    ones,zeros,runs_hist,dt=generate_and_count(key8,iv8,n)
    z=monobit_z(ones,n) # Sect Final: print the needed report + two extra stuff
    print("=== DES-OFB PRNG (Lecture 10) ===")
    print(f"Key (hex): {key8.hex()}  |  IV (hex): {iv8.hex()}")
    print(f"Bits requested: {n}   Time: {dt:.6f} s")
    print(f"1s: {ones} ({ones/n:.6f})   0s: {zeros} ({zeros/n:.6f})")
    print(f"Monobit z-score: {z:.3f}  => {'PASS (|z|<3)' if abs(z)<3 else 'FLAG'}")
    print("Runs (short summary):", summarize_runs(runs_hist, max_len=12))
    print("Note: OFB keystream MUST NOT be reused with the same (key, IV).")
if __name__ == "__main__":
    main()