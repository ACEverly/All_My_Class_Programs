""" HW 2 Question 5 (from assignment): Refer to Lecture 9 Block Cipher Operations. Write a code to conduct 
"Meet-in-the-Middle Attack" to double-DES, following the steps introduced in the slides. Show the cracking time you need to find the two secret keys,
k1 and k2.Note: You can use the DES code for the first homework directly for this problem. Please send me your code and report. """
#Name: Adalynn Everly
#ID#: 1001852753
#Class: CSE 4381-001
from __future__ import annotations
import time
import os
import struct
from typing import Callable,Dict,List,Tuple,Iterable,Optional
""" Double-DES Meet-in-the-Middle attack demo, Follow the exact steps from Lecture 9. 2) needs to Works either with your HW1 DES or with PyCryptodome.
3) Finally needs to use a config reduced keyspace so you can fin in human time """
#/////SECT. 1: DES primit////
_DES_OK=False
try:
    from Crypto.Cipher import DES as _DES
    _DES_OK=True
except Exception:
    _DES_OK=False
def _require_len(b:bytes,n:int,msg:str):
    if len(b)!=n:
        raise ValueError(f"{msg} must be {n} bytes, got {len(b)}")
def des_encrypt_block(key8: bytes, block8: bytes) -> bytes:
    # Need to encrypt 1 64-bit blck W/ DES under an 8byte key. ThenReplace this function with your HW1 DES if you want.
    _require_len(key8,8,"DES key")
    _require_len(block8,8,"DES block")
    if not _DES_OK:
        raise RuntimeError("PyCryptodome not found and no HW1 DES provided. Install with `pip install pycryptodome` or paste your DES here.")
    return _DES.new(key8,_DES.MODE_ECB).encrypt(block8)
def des_decrypt_block(key8:bytes,block8:bytes)->bytes:
    _require_len(key8,8,"DES key")
    _require_len(block8,8,"DES block")
    if not _DES_OK:
        raise RuntimeError("PyCryptodome not found and no HW1 DES provided. Install with `pip install pycryptodome` or paste your DES here.")
    return _DES.new(key8, _DES.MODE_ECB).decrypt(block8)
#////SECT 2: DES API (Double)/////
def double_des_encrypt(k1:bytes,k2:bytes,p:bytes)->bytes:
    #C=E_{k2}( E_{k1}(P))
    return des_encrypt_block(k2,des_encrypt_block(k1,p))
def double_des_decrypt(k1:bytes,k2:bytes,c:bytes)->bytes:
    #P=D_{k1}( D_{k2}(C))
    return des_decrypt_block(k1,des_decrypt_block(k2,c))
#///SECT 3: Keyspace helpers- It's gonna reduce the search for the demo
def pack_demo_key(x:int)->bytes:
    #Let's Map an int x to an 8byte DES key for demo brute force. For real 56-bit search you'd generate all 8-byte keys with valid parity.
    #Here we just replicate x across the 8 bytes deterministically.
    # Now let's Repeat the 2 least-sig bytes of x to fill 8 bytes. For larger spaces, include more bits from x.
    b=struct.pack(">Q",((x & 0xFFFF)*0x01010101)&0xFFFFFFFFFFFFFFFF)
    return b
def key_iter(limit:int)->Iterable[bytes]:
    #Iterate over 'limit' demo keys: k=0..limit-1 mapped via pack_demo_key.
    for x in range(limit):
        yield pack_demo_key(x)
#////SECT. 4: The MITM attack ////////
def mitm_double_des(
    P1:bytes,C1:bytes,P2:bytes,C2:bytes,space_k1:int,space_k2:int)->Tuple[Optional[Tuple[bytes,bytes]],int,int]:
    #Perform MITM,double-DES.Returns:( (k1,k2) or None,num_candidates,num_meets)
    #num_candidates:pairs that also pass the (P2,C2) verification, num_meets: raw hash-table collisions from step 3 before verification
    t0=time.time()
    #1)forward table X=E_{k1}(P1)
    table:Dict[bytes,List[bytes]]={}
    for k1 in key_iter(space_k1):
        x=des_encrypt_block(k1,P1) #mult keys can map to same x in demo spaces -> store the list
        table.setdefault(x,[]).append(k1)
    t1=time.time() #2) & 3) backward sweep X'=D_{k2}(C1);meet with X
    meets=0
    candidates:List[Tuple[bytes,bytes]]=[]
    for k2 in key_iter(space_k2):
        x_prime=des_decrypt_block(k2,C1)
        if x_prime in table:
            meets+=1
            for k1 in table[x_prime]: #4) verify with the second pair
                c2_check=double_des_encrypt(k1,k2,P2)
                if c2_check==C2:
                    candidates.append((k1,k2))
    t2=time.time()
    #If multiple, return the first valid (should be unique in practice)
    keypair = candidates[0] if candidates else None
    print(f"[MITM] Forward-table time: {t1 - t0:.3f}s")
    print(f"[MITM] Backward-sweep time: {t2 - t1:.3f}s")
    print(f"[MITM] Meets (raw): {meets}")
    print(f"[MITM] Verified candidates: {len(candidates)}")
    print(f"[MITM] Total time: {t2 - t0:.3f}s")
    return keypair, len(candidates), meets
#/////SECT 5: Demo slash the timing harness /////
def demo():
    #Known plaintext/ciphertext pairs.For a clean demo we generate them with secret demo keys in the chosen spaces. Replace with your assignment's given pairs if you have them.
    secret_k1_idx=0x1234 # pick something inside your chosen space
    secret_k2_idx=0x00AF
    secret_k1=pack_demo_key(secret_k1_idx)
    secret_k2=pack_demo_key(secret_k2_idx)
    P1=b"\x01\x23\x45\x67\x89\xab\xcd\xef"
    P2=b"\xfe\xdc\xba\x98\x76\x54\x32\x10"
    C1=double_des_encrypt(secret_k1, secret_k2, P1)
    C2=double_des_encrypt(secret_k1, secret_k2, P2) #Choose demo sizes (tune these to what your machine can handle quickly)
    SPACE_K1=1<<16   #ex: 65,536 keys
    SPACE_K2=1<<16
    print(f"Target secrets (indices): k1={hex(secret_k1_idx)}, k2={hex(secret_k2_idx)}")
    print("Running MITM... (demo spaces)")
    found,n_ok,n_meet=mitm_double_des(P1,C1,P2,C2,SPACE_K1,SPACE_K2)
    if found:
        k1,k2=found
        print("Recovered keys!")
        print(f"k1: {k1.hex()}  (index ~ {hex(secret_k1_idx)})")
        print(f"k2: {k2.hex()}  (index ~ {hex(secret_k2_idx)})") #To Double check
        assert double_des_decrypt(k1,k2,C1)==P1
        assert double_des_decrypt(k1,k2,C2)==P2
    else:
        print("No keypair found in the searched spaces (increase ranges or check inputs).")
if __name__=="__main__":
    demo()