import React from "react";
import "./InternshipTemplate.css";

const InternshipTemplate = ({ data }) => {
  // Build contact line
  const contactParts = [data.email, data.phone, data.linkedin, data.github].filter(Boolean);

  return (
    <div className="internship-template">
      {/* Header */}
      <header className="resume-header">
        <h1 className="resume-name">{data.name || "Your Name"}</h1>
        <p className="resume-contact">
          {contactParts.length > 0 ? contactParts.join(" | ") : "email@example.com | (123) 456-7890"}
        </p>
      </header>

      {/* Objective */}
      {data.summary && (
        <section className="resume-section">
          <h2 className="section-title">Objective</h2>
          <p className="section-text">{data.summary}</p>
        </section>
      )}

      {/* Education */}
      {data.education?.some((e) => e.school || e.degree) && (
        <section className="resume-section">
          <h2 className="section-title">Education</h2>
          {data.education.map((edu, i) =>
            edu.school || edu.degree ? (
              <div key={i} className="entry">
                <div className="entry-header">
                  <div className="entry-left">
                    <span className="entry-title">{edu.school}</span>
                    {edu.location && <span className="entry-location">, {edu.location}</span>}
                  </div>
                  <div className="entry-dates">{edu.dates}</div>
                </div>
                <div className="entry-subheader">
                  <span className="entry-subtitle">{edu.degree}</span>
                  {edu.gpa && <span className="entry-gpa">GPA: {edu.gpa}</span>}
                </div>
                {edu.coursework && (
                  <p className="entry-coursework">
                    <strong>Relevant Coursework:</strong> {edu.coursework}
                  </p>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Experience */}
      {data.experience?.some((e) => e.company || e.title) && (
        <section className="resume-section">
          <h2 className="section-title">Experience</h2>
          {data.experience.map((exp, i) =>
            exp.company || exp.title ? (
              <div key={i} className="entry">
                <div className="entry-header">
                  <div className="entry-left">
                    <span className="entry-title">{exp.company}</span>
                    {exp.location && <span className="entry-location">, {exp.location}</span>}
                  </div>
                  <div className="entry-dates">{exp.dates}</div>
                </div>
                <div className="entry-subtitle">{exp.title}</div>
                {exp.bullets?.filter((b) => b).length > 0 && (
                  <ul className="entry-bullets">
                    {exp.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Projects */}
      {data.projects?.some((p) => p.name) && (
        <section className="resume-section">
          <h2 className="section-title">Projects</h2>
          {data.projects.map((proj, i) =>
            proj.name ? (
              <div key={i} className="entry">
                <div className="entry-header">
                  <div className="entry-left">
                    <span className="entry-title">{proj.name}</span>
                    {proj.technologies && (
                      <span className="entry-tech"> | {proj.technologies}</span>
                    )}
                  </div>
                  <div className="entry-dates">{proj.dates}</div>
                </div>
                {proj.bullets?.filter((b) => b).length > 0 && (
                  <ul className="entry-bullets">
                    {proj.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Skills */}
      {data.skills?.some((s) => s.items) && (
        <section className="resume-section">
          <h2 className="section-title">Technical Skills</h2>
          <div className="skills-container">
            {data.skills.map((skill, i) =>
              skill.items ? (
                <p key={i} className="skill-row">
                  <strong>{skill.category}:</strong> {skill.items}
                </p>
              ) : null
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default InternshipTemplate;