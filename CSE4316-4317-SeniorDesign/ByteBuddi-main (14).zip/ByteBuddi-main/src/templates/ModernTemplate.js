import React from "react";
import "./ModernTemplate.css";

const ModernTemplate = ({ data }) => {
  const contactParts = [data.email, data.phone, data.linkedin, data.github].filter(Boolean);

  return (
    <div className="modern-template">
      {/* Header */}
      <header className="modern-header">
        <h1 className="modern-name">{data.name || "Your Name"}</h1>
        <div className="modern-contact">
          {contactParts.map((item, i) => (
            <span key={i} className="modern-contact-item">
              {item}
            </span>
          ))}
        </div>
      </header>

      {/* Summary */}
      {data.summary && (
        <section className="modern-section">
          <h2 className="modern-section-title">
            <span className="modern-section-icon">◆</span>
            Summary
          </h2>
          <p className="modern-text">{data.summary}</p>
        </section>
      )}

      {/* Education */}
      {data.education?.some((e) => e.school || e.degree) && (
        <section className="modern-section">
          <h2 className="modern-section-title">
            <span className="modern-section-icon">◆</span>
            Education
          </h2>
          {data.education.map((edu, i) =>
            edu.school || edu.degree ? (
              <div key={i} className="modern-entry">
                <div className="modern-entry-header">
                  <div className="modern-entry-main">
                    <span className="modern-entry-title">{edu.school}</span>
                    {edu.location && (
                      <span className="modern-entry-location">{edu.location}</span>
                    )}
                  </div>
                  <div className="modern-entry-dates">{edu.dates}</div>
                </div>
                <div className="modern-entry-sub">
                  <span className="modern-entry-subtitle">{edu.degree}</span>
                  {edu.gpa && <span className="modern-gpa">GPA: {edu.gpa}</span>}
                </div>
                {edu.coursework && (
                  <p className="modern-coursework">
                    <span className="modern-label">Coursework:</span> {edu.coursework}
                  </p>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Experience */}
      {data.experience?.some((e) => e.company || e.title) && (
        <section className="modern-section">
          <h2 className="modern-section-title">
            <span className="modern-section-icon">◆</span>
            Experience
          </h2>
          {data.experience.map((exp, i) =>
            exp.company || exp.title ? (
              <div key={i} className="modern-entry">
                <div className="modern-entry-header">
                  <div className="modern-entry-main">
                    <span className="modern-entry-title">{exp.company}</span>
                    {exp.location && (
                      <span className="modern-entry-location">{exp.location}</span>
                    )}
                  </div>
                  <div className="modern-entry-dates">{exp.dates}</div>
                </div>
                <div className="modern-entry-subtitle">{exp.title}</div>
                {exp.bullets?.filter((b) => b).length > 0 && (
                  <ul className="modern-bullets">
                    {exp.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Projects */}
      {data.projects?.some((p) => p.name) && (
        <section className="modern-section">
          <h2 className="modern-section-title">
            <span className="modern-section-icon">◆</span>
            Projects
          </h2>
          {data.projects.map((proj, i) =>
            proj.name ? (
              <div key={i} className="modern-entry">
                <div className="modern-entry-header">
                  <div className="modern-entry-main">
                    <span className="modern-entry-title">{proj.name}</span>
                    {proj.technologies && (
                      <span className="modern-tech">{proj.technologies}</span>
                    )}
                  </div>
                  <div className="modern-entry-dates">{proj.dates}</div>
                </div>
                {proj.bullets?.filter((b) => b).length > 0 && (
                  <ul className="modern-bullets">
                    {proj.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Skills */}
      {data.skills?.some((s) => s.items) && (
        <section className="modern-section">
          <h2 className="modern-section-title">
            <span className="modern-section-icon">◆</span>
            Technical Skills
          </h2>
          <div className="modern-skills">
            {data.skills.map((skill, i) =>
              skill.items ? (
                <div key={i} className="modern-skill-row">
                  <span className="modern-skill-category">{skill.category}:</span>
                  <span className="modern-skill-items">{skill.items}</span>
                </div>
              ) : null
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default ModernTemplate;