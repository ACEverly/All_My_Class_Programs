import React from "react";
import "./ClassicTemplate.css";

const ClassicTemplate = ({ data }) => {
  const contactParts = [data.email, data.phone, data.linkedin, data.github].filter(Boolean);

  return (
    <div className="classic-template">
      {/* Header */}
      <header className="classic-header">
        <h1 className="classic-name">{data.name || "Your Name"}</h1>
        <div className="classic-contact">
          {contactParts.length > 0 ? contactParts.join(" • ") : "email@example.com • (123) 456-7890"}
        </div>
      </header>

      {/* Objective */}
      {data.summary && (
        <section className="classic-section">
          <h2 className="classic-section-title">Professional Summary</h2>
          <p className="classic-text">{data.summary}</p>
        </section>
      )}

      {/* Education */}
      {data.education?.some((e) => e.school || e.degree) && (
        <section className="classic-section">
          <h2 className="classic-section-title">Education</h2>
          {data.education.map((edu, i) =>
            edu.school || edu.degree ? (
              <div key={i} className="classic-entry">
                <div className="classic-entry-header">
                  <div>
                    <span className="classic-entry-title">{edu.school}</span>
                    {edu.location && <span className="classic-entry-location"> — {edu.location}</span>}
                  </div>
                  <div className="classic-entry-dates">{edu.dates}</div>
                </div>
                <div className="classic-entry-sub">
                  <span className="classic-entry-subtitle">{edu.degree}</span>
                  {edu.gpa && <span className="classic-gpa"> | GPA: {edu.gpa}</span>}
                </div>
                {edu.coursework && (
                  <p className="classic-coursework">Coursework: {edu.coursework}</p>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Experience */}
      {data.experience?.some((e) => e.company || e.title) && (
        <section className="classic-section">
          <h2 className="classic-section-title">Professional Experience</h2>
          {data.experience.map((exp, i) =>
            exp.company || exp.title ? (
              <div key={i} className="classic-entry">
                <div className="classic-entry-header">
                  <div>
                    <span className="classic-entry-title">{exp.company}</span>
                    {exp.location && <span className="classic-entry-location"> — {exp.location}</span>}
                  </div>
                  <div className="classic-entry-dates">{exp.dates}</div>
                </div>
                <div className="classic-entry-subtitle">{exp.title}</div>
                {exp.bullets?.filter((b) => b).length > 0 && (
                  <ul className="classic-bullets">
                    {exp.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Projects */}
      {data.projects?.some((p) => p.name) && (
        <section className="classic-section">
          <h2 className="classic-section-title">Projects</h2>
          {data.projects.map((proj, i) =>
            proj.name ? (
              <div key={i} className="classic-entry">
                <div className="classic-entry-header">
                  <div>
                    <span className="classic-entry-title">{proj.name}</span>
                    {proj.technologies && (
                      <span className="classic-tech"> ({proj.technologies})</span>
                    )}
                  </div>
                  <div className="classic-entry-dates">{proj.dates}</div>
                </div>
                {proj.bullets?.filter((b) => b).length > 0 && (
                  <ul className="classic-bullets">
                    {proj.bullets.filter((b) => b).map((bullet, j) => (
                      <li key={j}>{bullet}</li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null
          )}
        </section>
      )}

      {/* Skills */}
      {data.skills?.some((s) => s.items) && (
        <section className="classic-section">
          <h2 className="classic-section-title">Skills</h2>
          <div className="classic-skills">
            {data.skills.map((skill, i) =>
              skill.items ? (
                <p key={i} className="classic-skill-row">
                  <strong>{skill.category}:</strong> {skill.items}
                </p>
              ) : null
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default ClassicTemplate;