// src/services/atsService.js
// Uses Groq free tier — get your free API key at:
// https://console.groq.com
// Add to your .env file: REACT_APP_GROQ_API_KEY=your_key_here

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";

export function extractResumeText(data) {
  const parts = [];
  if (data.name) parts.push(data.name);
  if (data.summary) parts.push(`Objective: ${data.summary}`);
  if (data.education?.length) {
    parts.push("Education:");
    data.education.forEach((e) => {
      if (e.school) parts.push(e.school);
      if (e.degree) parts.push(e.degree);
      if (e.coursework) parts.push(`Coursework: ${e.coursework}`);
    });
  }
  if (data.experience?.length) {
    parts.push("Experience:");
    data.experience.forEach((e) => {
      if (e.title) parts.push(e.title);
      if (e.company) parts.push(e.company);
      if (e.bullets?.length) parts.push(...e.bullets.filter(Boolean));
    });
  }
  if (data.projects?.length) {
    parts.push("Projects:");
    data.projects.forEach((p) => {
      if (p.name) parts.push(p.name);
      if (p.technologies) parts.push(p.technologies);
      if (p.bullets?.length) parts.push(...p.bullets.filter(Boolean));
    });
  }
  if (data.skills?.length) {
    parts.push("Skills:");
    data.skills.forEach((s) => {
      if (s.items) parts.push(`${s.category || ""}: ${s.items}`);
    });
  }
  return parts.join("\n");
}

function buildPrompt(resumeText, jobDescription) {
  const sharedInstructions = `
Keep in mind:
- This person is likely a college student or recent graduate seeking an entry-level role or internship
- LIMITED work experience is completely normal — focus on improving what they HAVE
- Prioritize projects, coursework, part-time jobs, volunteering, and clubs
- Do NOT penalize for lack of years of experience
- Be encouraging — frame every suggestion as an opportunity, not a failure
- Focus on strong action verbs, industry-standard skill keywords, and clear phrasing

IMPORTANT — Quality threshold:
- Only include a suggestion if it is a GENUINE, meaningful improvement
- Do NOT invent suggestions just to fill a quota
- If the resume is already well-optimized, return fewer items or even an empty array []
- A suggestion is only valid if it would make a real, noticeable difference to an ATS scanner
- Do NOT nitpick minor stylistic preferences — only flag actual ATS problems
- If the resume scores above 85/100 in your assessment, return 0 to 2 items max
- If the resume scores between 70-85, return 3 to 4 items max
- If the resume scores below 70, return 5 to 8 items

Respond ONLY with a valid JSON object (no markdown, no explanation, no code fences) in this exact format:
{
  "score": 82,
  "passed": false,
  "summary": "One sentence overall assessment of the resume's ATS readiness.",
  "suggestions": [
    {
      "keyword": "the weak or missing term",
      "status": "weak",
      "current": "the exact phrase from the resume, or null if missing entirely",
      "suggestion": "the stronger replacement or addition",
      "reason": "one short encouraging sentence explaining how this helps get past ATS filters"
    }
  ]
}

Rules:
- "score" is a number 0–100 reflecting genuine ATS readiness
- "passed" is true if score >= 85 (resume is solid, ready to submit)
- "summary" is always present — a short encouraging sentence about the overall state
- "suggestions" can be an empty array [] if the resume is excellent
- Status in each suggestion must be exactly one of: "weak", "missing", or "improve"
- Return ONLY the JSON object, nothing else.`;

  if (jobDescription && jobDescription.trim().length > 20) {
    return `You are a friendly ATS resume coach helping a college student tailor their resume to a specific job posting.

Compare the resume against the job description and identify only GENUINE gaps:
1. Keywords from the job description MISSING from the resume but could realistically be added
2. Skills or tools in the job posting the student may have but phrased differently
3. Weak or passive verbs that should be replaced with stronger ones
4. Terminology in the resume that doesn't match the language used in the job posting
5. Soft skills the job posting emphasizes that are absent from the resume

Job Description:
"""
${jobDescription}
"""

Resume:
"""
${resumeText}
"""
${sharedInstructions}`;
  }

  return `You are a friendly and encouraging ATS resume coach specializing in helping college students land their first job or internship.

Analyze this resume for ATS optimization. Only flag REAL issues — do not invent suggestions. Focus on:
1. Weak or passive verbs (e.g. "helped with" → "engineered", "worked on" → "developed")
2. Missing soft skills ATS systems scan for (e.g. "collaboration", "problem-solving")
3. Tech skills listed informally (e.g. "know Python" → "Python", "used Git" → "Git / Version Control")
4. Vague objective statements that could be more targeted
5. Coursework or projects that could mention specific technologies or methodologies
6. Missing keywords for their apparent field (CS, engineering, business, design, etc.)

Resume:
"""
${resumeText}
"""
${sharedInstructions}`;
}

export async function evaluateATS(data, jobDescription = "") {
  const apiKey = process.env.REACT_APP_GROQ_API_KEY;

  if (!apiKey) {
    throw new Error(
      "Missing Groq API key. Add REACT_APP_GROQ_API_KEY to your .env file.\n" +
        "Get a free key at: https://console.groq.com"
    );
  }
    // Guard: check if resume has meaningful content
  const hasName = !!data?.name?.trim();
  const hasEducation = data?.education?.some(e => e.school || e.degree);
  const hasExperience = data?.experience?.some(e => e.company || e.title);
  const hasProjects = data?.projects?.some(p => p.name);
  const hasSkills = data?.skills?.some(s => s.items);
  const hasSummary = !!data?.summary?.trim();

  const hasAnyContent = hasName || hasEducation || hasExperience || hasProjects || hasSkills || hasSummary;

  if (!hasAnyContent) {
    throw new Error(
      "Your resume appears to be empty. Please fill in at least your name, education, or experience before running the ATS check."
    );
  }
  const resumeText = extractResumeText(data);
  const prompt = buildPrompt(resumeText, jobDescription);

  const response = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1024,
    }),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err?.error?.message || `Groq API request failed (${response.status})`);
  }

  const result = await response.json();
  const text = result.choices?.[0]?.message?.content || "";
  const clean = text.replace(/```json|```/gi, "").trim();

  try {
    const parsed = JSON.parse(clean);
    // Normalize: support both old array format and new object format
    if (Array.isArray(parsed)) {
      return { score: 60, passed: false, summary: null, suggestions: parsed };
    }
    return parsed;
  } catch {
    throw new Error("Could not parse the AI response. Please try again.");
  }
}