// src/components/ATSModal.js
import React, { useState, useEffect } from "react";
import "./ATSModal.css";

const STATUS_CONFIG = {
  weak: { label: "Weak Phrasing", icon: "⚠️", color: "ats-tag--weak" },
  missing: { label: "Missing Keyword", icon: "❌", color: "ats-tag--missing" },
  improve: { label: "Can Improve", icon: "💡", color: "ats-tag--improve" },
};

export default function ATSModal({ isOpen, onClose, results, isLoading, error, hasJobDescription, responseTime }) {
  console.log("ATSModal props:", { responseTime }); 
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (isOpen) setExpanded(null);
  }, [isOpen]);

  if (!isOpen) return null;

  // Support both new object format { score, passed, summary, suggestions }
  // and old array format for backwards compatibility
  const suggestions = results?.suggestions ?? (Array.isArray(results) ? results : []);
  const score       = results?.score ?? (results ? Math.max(0, Math.min(100, Math.round(100 - suggestions.length * 8))) : null);
  const passed      = results?.passed ?? (score !== null && score >= 85);
  const summary     = results?.summary ?? null;

  const scoreColor = score >= 85 ? "#22c55e" : score >= 70 ? "#f59e0b" : "#ef4444";

  return (
    <div className="ats-overlay" onClick={onClose}>
      <div className="ats-modal" onClick={(e) => e.stopPropagation()}>

        {/* Header */}
        <div className="ats-modal__header">
          <div className="ats-modal__title-group">
            <span className="ats-modal__icon">🤖</span>
            <div>
              <h2 className="ats-modal__title">ATS Keyword Analysis</h2>
              <p className="ats-modal__subtitle">
                {hasJobDescription ? "Matched against your job posting" : "General entry-level analysis"}
              </p>
            </div>
          </div>
          <button className="ats-modal__close" onClick={onClose} aria-label="Close">✕</button>
        </div>

        {/* Body */}
        <div className="ats-modal__body">

          {/* Loading */}
          {isLoading && (
            <div className="ats-state ats-state--loading">
              <div className="ats-spinner" />
              <p>Analyzing your resume for ATS compatibility…</p>
            </div>
          )}

          {/* Error */}
          {error && !isLoading && (
            <div className="ats-state ats-state--error">
              <span className="ats-state__icon">⚠️</span>
              <p className="ats-state__title">Analysis failed</p>
              <p className="ats-state__message">{error}</p>
              {error.includes("REACT_APP_GROQ_API_KEY") && (
                <a href="https://console.groq.com" target="_blank" rel="noreferrer" className="ats-link">
                  Get your free Groq API key →
                </a>
              )}
            </div>
          )}

          {/* Results */}
          {results && !isLoading && (
            <>
              {/* Score row */}
              <div className="ats-score-row">
                <div className="ats-score-ring" style={{ "--score-color": scoreColor }}>
                  <svg viewBox="0 0 80 80" className="ats-ring-svg">
                    <circle cx="40" cy="40" r="32" className="ats-ring-bg" />
                    <circle
                      cx="40" cy="40" r="32"
                      className="ats-ring-fill"
                      style={{
                        strokeDasharray: `${2 * Math.PI * 32}`,
                        strokeDashoffset: `${2 * Math.PI * 32 * (1 - score / 100)}`,
                        stroke: scoreColor,
                      }}
                    />
                  </svg>
                  <span className="ats-score-value" style={{ color: scoreColor }}>{score}</span>
                </div>
                <div className="ats-score-info">
                  <p className="ats-score-label">ATS Score</p>
                  {/* Summary from AI or fallback */}
                  <p className="ats-score-desc">
                    {summary || (
                      passed
                        ? "Great job! Your resume is well-optimized and ready to submit."
                        : score >= 70
                        ? "Looking good — a few tweaks below will make it even stronger."
                        : "Needs some work. Address the suggestions below before applying."
                    )}
                  </p>

                  {/* Passed badge */}
                  {passed && (
                    <div className="ats-passed-badge">
                      ✅ ATS Ready — no critical issues found!
                    </div>
                  )}

                  {/* Legend only if there are suggestions */}
                  {suggestions.length > 0 && (
                    <div className="ats-legend">
                      {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
                        const count = suggestions.filter((r) => r.status === key).length;
                        return count > 0 ? (
                          <span key={key} className={`ats-tag ${cfg.color}`}>
                            {cfg.icon} {cfg.label}: {count}
                          </span>
                        ) : null;
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* No suggestions — perfect state */}
              {suggestions.length === 0 && (
                <div className="ats-state ats-state--perfect">
                  <span className="ats-state__icon">🎉</span>
                  <p className="ats-state__title">Nothing left to improve!</p>
                  <p className="ats-state__message">
                    Your resume looks great for ATS. You're ready to apply with confidence.
                  </p>
                </div>
              )}

              {/* Suggestions list */}
              {suggestions.length > 0 && (
                <ul className="ats-results">
                  {suggestions.map((item, i) => {
                    const cfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.improve;
                    const isExpanded = expanded === i;
                    return (
                      <li
                        key={i}
                        className={`ats-result-item ${isExpanded ? "ats-result-item--open" : ""}`}
                        onClick={() => setExpanded(isExpanded ? null : i)}
                      >
                        <div className="ats-result-item__top">
                          <span className={`ats-tag ${cfg.color}`}>{cfg.icon} {cfg.label}</span>
                          <span className="ats-result-item__keyword">
                            {item.current ? (
                              <>
                                <s className="ats-old">{item.current}</s>
                                <span className="ats-arrow"> → </span>
                                <strong className="ats-new">{item.suggestion}</strong>
                              </>
                            ) : (
                              <strong className="ats-new">+ {item.suggestion}</strong>
                            )}
                          </span>
                          <span className="ats-result-item__chevron">{isExpanded ? "▲" : "▼"}</span>
                        </div>
                        {isExpanded && (
                          <div className="ats-result-item__detail">
                            <p>{item.reason}</p>
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        {results && !isLoading && (
          <div className="ats-modal__footer">
            <p className="ats-footer-note">
              {suggestions.length > 0
                ? "💡 Click any suggestion to see why it helps your ATS score."
                : "✅ Your resume passed ATS review — go get that internship!"
              }
            </p>
              {/* Response Timer */}
              {responseTime !== null &&(
                <p className="ats-footer-note">
                  Analysis completed in: {(responseTime)} seconds
                </p>
              )}

            <button className="ats-btn-close" onClick={onClose}>Got it, close</button>
          </div>
        )}
      </div>
    </div>
  );
}
/* append to ATSModal.css */