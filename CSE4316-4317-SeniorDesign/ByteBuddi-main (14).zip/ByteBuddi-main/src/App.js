import { useState } from "react";
import './App.css';
import Home from './pages/Home';
import About from './pages/About';
import Gallery from './pages/Gallery';
import Login from './pages/Login';
import Builder from './pages/Builder';
import Templates from './pages/Templates';
// import ATS from './pages/ATS';
import { BrowserRouter, Routes, Route, Link, Navigate } from 'react-router-dom';
import byteBuddiLogo from './assets/offical_logo_bytebuddi.png';
import Interviewer from "./pages/Interviewer";
import { AuthProvider, useAuth } from './context/AuthContext';
import TwoFactorSetup from './pages/TwoFactorSetup';
import Help from './pages/Help';
import AdminPage from './pages/AdminPage';


// Protected Route Component
function ProtectedRoute({ children }) {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
}

function AdminRoute({ children }) {
  const { currentUser, userProfile, loading } = useAuth();

  if (loading) {
    return <div style={{ padding: 20 }}>Loading...</div>;
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (!userProfile?.isAdmin) {
    return <Navigate to="/" replace />;
  }

  return children;
}

function AppContent() {
  const { currentUser, userProfile, logout } = useAuth();
  const [resumeData, setResumeData] = useState({});
  const [selectedTemplate, setSelectedTemplate] = useState('internship');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="App-header">
        <div className="App-navbar">
          <img src={byteBuddiLogo} className="App-logo" alt="ByteBuddi Logo" />
          
          {/* Desktop Navigation - Always visible on desktop */}
          <nav className="App-nav-desktop">
            {!currentUser ? (
              <>
                <Link to="/">Home</Link>
                <Link to="/gallery">Gallery</Link>
                <Link to="/login">Login</Link>
                <Link to="/about">About</Link>
                <Link to="/help">Help</Link>
              </>
            ) : (
              <>
                <Link to="/">Home</Link>
                <Link to="/gallery">Gallery</Link>
                <Link to="/builder">Builder</Link>
                <Link to="/interviewer">Interviewer</Link>
                <Link to="/help">Help</Link>
              </>
            )}
          </nav>

          {/* Hamburger Menu Button - Shows on mobile OR when logged in on desktop */}
          <button 
            className={`hamburger ${mobileMenuOpen ? 'active' : ''} ${currentUser ? 'show-when-logged-in' : ''}`}
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            <span></span>
            <span></span>
            <span></span>
          </button>

          {/* Mobile/Dropdown Menu */}
          <nav className={`App-nav-mobile ${mobileMenuOpen ? 'mobile-open' : ''}`}>
            {!currentUser ? (
              // Not logged in - show all links on mobile
              <>
                <Link to="/" onClick={closeMobileMenu}>Home</Link>
                <Link to="/gallery" onClick={closeMobileMenu}>Gallery</Link>
                <Link to="/login" onClick={closeMobileMenu}>Login</Link>
                <Link to="/about" onClick={closeMobileMenu}>About</Link>
                <Link to="/help" onClick={closeMobileMenu}>Help</Link>
              </>
            ) : (
              // Logged in - show only additional links
              <>
                {/* On mobile, show all links */}
                <Link to="/" onClick={closeMobileMenu} className="mobile-only">Home</Link>
                <Link to="/gallery" onClick={closeMobileMenu} className="mobile-only">Gallery</Link>
                <Link to="/builder" onClick={closeMobileMenu} className="mobile-only">Builder</Link>
                <Link to="/interviewer" onClick={closeMobileMenu}className="mobile-only">Interviewer</Link>
                <Link to="/help" onClick={closeMobileMenu} className="mobile-only">Help</Link>
                
                {/* These show on both mobile and desktop dropdown */}
                <Link to="/templates" onClick={closeMobileMenu}>ATS Checker</Link>
                {/* <Link to="/ATS" onClock={closeMobileMenu}>ATS Checker</Link> */}
                <Link to="/about" onClick={closeMobileMenu}>About</Link>
                <Link to="/2fa-setup" onClick={closeMobileMenu}>2FA Settings</Link>
                {userProfile?.isAdmin && (
                  <Link to="/admin" onClick={closeMobileMenu}>Admin</Link>
                )}
                <button 
                  onClick={async () => {
                    try {
                      await logout();
                      closeMobileMenu();
                    } catch (e) {
                      console.error(e);
                    }
                  }}
                  className="logout-button"
                >
                  Logout
                </button>
              </>
            )}
          </nav>
        </div>
      </header>

      {/* Overlay for mobile menu */}
      {mobileMenuOpen && (
        <div className="mobile-overlay" onClick={closeMobileMenu}></div>
      )}

      <div className="App-content">
        <Routes>
          {/* Public routes - anyone can access */}
          <Route path="/" element={<Home />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/login" element={<Login />} /> 
          <Route path="/about" element={<About />} />
          <Route path="/help" element={<Help />} />
          <Route path="/admin" element={<AdminRoute><AdminPage /></AdminRoute>} />
          
          {/* Protected routes - require login */}
          <Route path="/builder" element={
            <ProtectedRoute>
              <Builder 
                onDataChange={setResumeData} 
                selectedTemplate={selectedTemplate}
                onTemplateChange={setSelectedTemplate}
              />
            </ProtectedRoute>
          } />
          <Route path="/templates" element={
            <ProtectedRoute>
              <Templates 
                data={resumeData} 
                selectedTemplate={selectedTemplate} 
                onTemplateChange={setSelectedTemplate}
              />
            </ProtectedRoute>
          } />
          {/* <Route path="/ATS" element={
            <ProtectedRoute>
              <ATS data={resumeData} />
            </ProtectedRoute>
          } /> */}
          <Route path="/interviewer" element={
            <ProtectedRoute>
              <Interviewer />
            </ProtectedRoute>
          } />
          <Route path="/2fa-setup" element={
            <ProtectedRoute>
              <TwoFactorSetup />
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;