import { useState } from "react";
import { auth, db } from "../lib/firebase";
import { logEvent } from "../lib/analytics";
import {createUserWithEmailAndPassword,signInWithEmailAndPassword,sendPasswordResetEmail,} from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";

export default function Login()
{
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");

  async function handleSignUp()
  {
    setMsg("");
    try
    {
      const userCredential = await createUserWithEmailAndPassword(auth, email, pw);
      const user = userCredential.user;

      //Create user document in Firestore
      await setDoc(doc(db, "users", user.uid),{
        email: user.email,
        createdAt: new Date(),
        twoFactorEnabled: false,
        twoFactorSecret: null,
      });

      await logEvent(db, "user_signup", user.uid, {email: user.email,});


      setMsg("Account created and signed in.");
    }
    catch (err)
    {
      setMsg("Error: " + err.message);
    }
  }

  async function handleSignIn()
  {
    setMsg("");
    try
    {
      const userCredential = await signInWithEmailAndPassword(auth, email, pw);
      const user = userCredential.user;
      await logEvent(db, "user_login", user.uid, {email: user.email,});


      //Check if user document exists in Firestore
      const userDocRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userDocRef);

      //If user document doesn't exist, create it
      if (!userDoc.exists())
      {
        console.log("User document not found, creating one...");
        await setDoc(userDocRef, {
          email: user.email,
          createdAt: new Date(),
          twoFactorEnabled: false,
          twoFactorSecret: null,
        });
        setMsg("Signed in. User profile created.");
      }
      else
      {
        setMsg("Signed in.");
      }
    }
    catch (err)
    {
      setMsg(" Error: " + err.message);
    }
  }
  /*
  async function handleSignOut()
  {
    setMsg("");
    try {
      await signOut(auth);
      setMsg("👋 Signed out.");
    } catch (err) {
      setMsg("❌ Error: " + err.message);
    }
  }
  */
  async function handleResetPassword() {
    setMsg("");
    if (!email) {
      setMsg("⚠️ Please enter your email first.");
      return;
    }
    try {
      await sendPasswordResetEmail(auth, email);
      setMsg("📧 Password reset email sent. Check your inbox.");
    } catch (err) {
      setMsg("❌ Error: " + err.message);
    }
  }

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 'calc(100vh - 120px)',
    background: '#e1e5f2',
    padding: '20px'
  };

  const cardStyle = {
    background: 'white',
    padding: '30px 40px',
    borderRadius: '12px',
    boxShadow: '0 6px 20px rgba(0,0,0,0.15)',
    maxWidth: '400px',
    width: '100%',
    textAlign: 'center'
  };

  const titleStyle = {
    marginBottom: '20px',
    fontSize: '24px',
    color: '#2a2a2a',
    fontWeight: 'bold'
  };

  const formStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
    textAlign: 'left'
  };

  const labelStyle = {
    fontSize: '14px',
    fontWeight: '500',
    color: '#444'
  };

  const inputStyle = {
    padding: '10px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    fontSize: '14px',
    width: '100%',
    boxSizing: 'border-box'
  };

  const buttonContainerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '8px',
    marginTop: '10px'
  };

  const buttonStyle = {
    flex: 1,
    padding: '10px',
    background: '#0077cc',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    cursor: 'pointer',
    transition: 'background 0.3s ease'
  };

  const resetButtonStyle = {
    width: '100%',
    padding: '10px',
    background: '#666',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    cursor: 'pointer',
    marginTop: '10px',
    transition: 'background 0.3s ease'
  };

  const messageStyle = {
    marginTop: '15px',
    padding: '10px',
    borderRadius: '6px',
    fontSize: '14px',
    fontWeight: '500',
    backgroundColor: msg.includes('✅') ? '#d4edda' : msg.includes('❌') ? '#f8d7da' : '#fff3cd',
    color: msg.includes('✅') ? '#155724' : msg.includes('❌') ? '#721c24' : '#856404'
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h1 style={titleStyle}>ByteBuddi Login</h1>

        <div style={formStyle}>
          <label style={labelStyle}>Email</label>
          <input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={inputStyle}
          />

          <label style={labelStyle}>Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            style={inputStyle}
          />

          <div style={buttonContainerStyle}>
            <button onClick={handleSignUp} style={buttonStyle}>
              Sign Up
            </button>
            <button onClick={handleSignIn} style={buttonStyle}>
              Sign In
            </button>
          </div>

          <button onClick={handleResetPassword} style={resetButtonStyle}>
            Forgot Password?
          </button>
        </div>

        {msg && <p style={messageStyle}>{msg}</p>}
      </div>
    </div>
  );
}