import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ExportPDF = () => {
  const handleDownload = async () => {
    const resume = document.getElementById('resume-preview');
    if (!resume) {
      alert('Resume preview not found!');
      return;
    }

    const button = document.querySelector('.export-section button');
    const originalText = button?.textContent;
    if (button) button.textContent = 'Generating PDF...';

    try {
      const RENDER_WIDTH = 816;

      // Save & lock styles
      const originalStyles = {
        width: resume.style.width,
        minWidth: resume.style.minWidth,
        maxWidth: resume.style.maxWidth,
        transform: resume.style.transform,
        position: resume.style.position,
        boxSizing: resume.style.boxSizing,
      };

      resume.style.width = `${RENDER_WIDTH}px`;
      resume.style.minWidth = `${RENDER_WIDTH}px`;
      resume.style.maxWidth = `${RENDER_WIDTH}px`;
      resume.style.boxSizing = 'border-box';
      resume.style.position = 'absolute';
      resume.style.transform = 'none';

      await new Promise((r) => setTimeout(r, 150));

      const canvas = await html2canvas(resume, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        width: RENDER_WIDTH,
        windowWidth: RENDER_WIDTH,
      });

      // Restore styles
      Object.assign(resume.style, originalStyles);

      // ── PDF setup ───────────────────────────────────────────────────
      const pdfWidth = 215.9;
      const pdfHeight = 279.4;
      const marginTop = 10;
      const marginBottom = 10;
      const marginLeft = 10;
      const marginRight = 10;
      const contentWidth = pdfWidth - marginLeft - marginRight;
      const contentHeight = pdfHeight - marginTop - marginBottom;

      const imgWidth = canvas.width;   // px (scaled ×2)
      const imgHeight = canvas.height;
      const scale = contentWidth / imgWidth;           // mm per px
      const pageHeightPx = Math.floor(contentHeight / scale); // ideal slice in px

      // ── Smart page-break finder ─────────────────────────────────────
      // Collect the bottom edge (in px relative to the canvas) of every
      // meaningful element inside the resume, then snap each page break
      // to the nearest safe gap ABOVE the hard cut point.
      const resumeRect = resume.getBoundingClientRect();

      // All block-level nodes that can act as break boundaries
      const nodes = resume.querySelectorAll(
        'p, li, h1, h2, h3, h4, h5, h6, div, tr, section, .entry-card'
      );

      // Build a sorted list of safe "bottom edges" in canvas-px coordinates
      const safeBreaks = new Set();
      safeBreaks.add(0);

      nodes.forEach((node) => {
        const rect = node.getBoundingClientRect();
        const bottomPx = (rect.bottom - resumeRect.top) * 2; // ×2 for scale:2
        if (bottomPx > 0 && bottomPx < imgHeight) {
          safeBreaks.add(Math.round(bottomPx));
        }
      });

      const sortedBreaks = Array.from(safeBreaks).sort((a, b) => a - b);

      // For a given hard-cut position, find the largest safe break ≤ it
      const findSafeBreak = (hardCut) => {
        let best = 0;
        for (const b of sortedBreaks) {
          if (b <= hardCut) best = b;
          else break;
        }
        return best;
      };

      // ── Slice & build PDF ───────────────────────────────────────────
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'letter',
      });

      let position = 0;
      let pageNum = 0;

      while (position < imgHeight) {
        const hardCut = position + pageHeightPx;

        // Snap to a safe break unless we're on the last page
        let sliceEnd;
        if (hardCut >= imgHeight) {
          sliceEnd = imgHeight;
        } else {
          const safeBreak = findSafeBreak(hardCut);
          // Fall back to hard cut if no safe break found in this page range
          sliceEnd = safeBreak > position ? safeBreak : hardCut;
        }

        const sliceHeight = sliceEnd - position;

        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = imgWidth;
        pageCanvas.height = sliceHeight;

        const ctx = pageCanvas.getContext('2d');
        // White background so empty space isn't transparent
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, imgWidth, sliceHeight);
        ctx.drawImage(canvas, 0, position, imgWidth, sliceHeight, 0, 0, imgWidth, sliceHeight);

        const pageImgData = pageCanvas.toDataURL('image/png');

        if (pageNum > 0) pdf.addPage();

        const sliceHeightMm = sliceHeight * scale;
        pdf.addImage(pageImgData, 'PNG', marginLeft, marginTop, contentWidth, sliceHeightMm);

        position = sliceEnd;
        pageNum++;
      }

      pdf.save('resume.pdf');
    } catch (error) {
      console.error('PDF generation failed:', error);
      alert('Failed to generate PDF. Please try again.');
    } finally {
      if (button) button.textContent = originalText || 'Download PDF';
    }
  };

  return (
    <button
      onClick={handleDownload}
      style={{
        padding: '10px 20px',
        background: '#0077cc',
        color: 'white',
        border: 'none',
        borderRadius: '8px',
        fontSize: '16px',
        cursor: 'pointer',
        fontWeight: 'bold',
      }}
    >
      Download PDF
    </button>
  );
};

export default ExportPDF;