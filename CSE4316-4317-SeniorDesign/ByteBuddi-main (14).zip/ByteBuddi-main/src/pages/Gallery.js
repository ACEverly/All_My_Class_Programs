import classicImg from '../assets/ClassicResumeExample.png';
import internshipImg from '../assets/InternshipResumeExample.png';
import modernImg from '../assets/ModernResumeExample.png';
import chatbotImg from '../assets/chatbotExample.png';

export default function Gallery() {
    return (
        <div style={{ padding: "40px" }}>
            <h1 style={{ fontSize: "36px", marginBottom: "10px" }}>Gallery Page</h1>

            <p style={{ fontSize: "18px", maxWidth: "900px" }}>
                Explore examples of resumes created using ByteBuddi's various templates
            </p>

            <div
                style={{
                    display: "flex",
                    justifyContent: "space-around",
                    alignItems: "flex-start",
                    flexWrap: "wrap",
                    marginTop: "50px",
                    gap: "40px",
                }}
            >
                {/* Internship */}
                <div style={{ textAlign: "center", width: "350px" }}>
                    <img
                        src={internshipImg}
                        alt="Internship Resume"
                        style={{
                            width: "100%",
                            height: "480px",
                            objectFit: "contain",
                            borderRadius: "12px",
                            background: "white",
                            boxShadow: "0 6px 18px rgba(0,0,0,0.2)",
                        }}
                    />
                    <p style={{ marginTop: "14px", fontSize: "18px" }}>
                        Internship Resume
                    </p>
                </div>

                {/* Classic */}
                <div style={{ textAlign: "center", width: "350px" }}>
                    <img
                        src={classicImg}
                        alt="Classic Resume"
                        style={{
                            width: "100%",
                            height: "480px",
                            objectFit: "contain",
                            borderRadius: "12px",
                            background: "white",
                            boxShadow: "0 6px 18px rgba(0,0,0,0.2)",
                        }}
                    />
                    <p style={{ marginTop: "14px", fontSize: "18px" }}>
                        Classic Resume
                    </p>
                </div>

                {/* Modern */}
                <div style={{ textAlign: "center", width: "350px" }}>
                    <img
                        src={modernImg}
                        alt="Modern Resume"
                        style={{
                            width: "100%",
                            height: "480px",
                            objectFit: "contain",
                            borderRadius: "12px",
                            background: "white",
                            boxShadow: "0 6px 18px rgba(0,0,0,0.2)",
                        }}
                    />
                    <p style={{ marginTop: "14px", fontSize: "18px" }}>
                        Modern Resume
                    </p>
                </div>

                {/* Interviewer Image */}
                <div style={{ textAlign: "center", width: "350px" }}>
                    <img
                        src={chatbotImg}
                        alt="Chatbot Example"
                        style={{
                            width: "100%",
                            height: "480px",
                            objectFit: "contain",
                            borderRadius: "12px",
                            background: "white",
                            boxShadow: "0 6px 18px rgba(0,0,0,0.2)",
                        }}
                    />
                    <p style={{ marginTop: "14px", fontSize: "18px" }}>
                        Interviewer Example
                    </p>
                </div>
            </div>
        </div>
    );
}
