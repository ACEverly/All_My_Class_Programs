import { useEffect, useState, useCallback } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import "./AdminPage.css";

export default function AdminPage()
{
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7); //last 7 days default
    return d.toISOString().split("T")[0];
  });

  const [endDate, setEndDate] = useState(() => new Date().toISOString().split("T")[0]);
  const [stats, setStats] = useState({userSignup: 0,userLogin: 0,resumeCreated: 0,resumeUpdated: 0,});
  const [loading, setLoading] = useState(false);

  const fetchAnalytics = useCallback(async () =>
  {
    setLoading(true);

    try
    {
      //////////////////////////////////////////////////
      const startStr = startDate; 
      const endStr = endDate;    
      const snapshot = await getDocs(collection(db, "analytics_events"));
      console.log("Total analytics docs:", snapshot.size);

      const counts = {userSignup: 0,userLogin: 0,resumeCreated: 0,resumeUpdated: 0,};

      snapshot.forEach((docSnap) =>
      {
        const data = docSnap.data();
        const meta = data.metadata || {};

        //timestamp bug fix
        const ts = data.timestamp || meta.timestamp;
        if (!ts) return;

        const tsDate = ts.toDate ? ts.toDate() : new Date(ts);

        //Build local date string
        const year = tsDate.getFullYear();
        const month = String(tsDate.getMonth() + 1).padStart(2, "0");
        const day = String(tsDate.getDate()).padStart(2, "0");
        const eventDateStr = `${year}-${month}-${day}`;

        if (eventDateStr < startStr || eventDateStr > endStr)
        {
          return;
        }
        ///counter bug fix
        const type = data.type || meta.type;
        if (!type) return;

        switch (type)
        {
          case "user_signup":
            counts.userSignup++;
            break;
          case "user_login":
            counts.userLogin++;
            break;
          case "resume_created":
            counts.resumeCreated++;
            break;
          case "resume_updated":
            counts.resumeUpdated++;
            break;
          default:
            break;
        }
      });

      console.log("Counts after date filter:", counts);
      setStats(counts);
    }
    catch (err)
    {
      console.error("Error fetching analytics:", err);
    }

    setLoading(false);
  }, [startDate, endDate]);


  useEffect(() => {fetchAnalytics();}, [fetchAnalytics]);

 return (
  <div className="admin-page">
    <div className="admin-header">
      <div className="admin-title">
        <h1>Admin Analytics Dashboard</h1>
        <p>Track key activity for the selected date range.</p>
      </div>
    </div>

    <div className="admin-panel">
      <div className="admin-filters">
        <div className="admin-field">
          <label>Start date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        <div className="admin-field">
          <label>End date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        <button className="admin-apply" onClick={fetchAnalytics} disabled={loading}>
          {loading ? "Loading..." : "Apply"}
        </button>
      </div>
    </div>

    <div style={{ marginTop: "16px" }}>
      <h2 style={{ margin: "0 0 10px 0" }}>Summary</h2>

      <div className="admin-grid">
        <div className="admin-card">
          <h3>New users</h3>
          <p>{stats.userSignup}</p>
        </div>

        <div className="admin-card">
          <h3>User logins</h3>
          <p>{stats.userLogin}</p>
        </div>

        <div className="admin-card">
          <h3>Resumes created</h3>
          <p>{stats.resumeCreated}</p>
        </div>

        <div className="admin-card">
          <h3>Resumes updated</h3>
          <p>{stats.resumeUpdated}</p>
        </div>
      </div>
    </div>
  </div>
);
}