import { Link } from "react-router-dom";
import "./Home.css";
import heroStepsImg from "../assets/Home_Image.png";


export default function Home() {
  return (
    <div className="home-page">

      <div className="home-hero-content">
        <h1 className="home-title">Build Resumes & Master Interviews</h1>
        <p className="home-subtitle">Unlock the exact resume formats recruiters look for, and instantly practice your interview skills with our AI chatbot</p>

        <Link to="/login" className="home-btn">
          Get Started
        </Link>
      </div>

      <div className="home-hero-image">
        <img
          src={heroStepsImg}
          alt="Create your perfect resume in 4 easy steps"
          className="home-hero-img"
        />
      </div>

      <div className="home-card-grid">
        <div className="home-card">
          <h2>For Students</h2>
          <p>Templates for internships and entry level jobs</p>
        </div>
        
        <div className="home-card">
          <h2>For Professionals</h2>
          <p>Templates for mid-level and senior jobs</p>
        </div>

        <div className="home-card">
          <h2>For Everyone</h2>
          <p>Easy-to-edit, modern, and ATS-friendly templates</p>
        </div>
      </div>
    </div>
  );
}