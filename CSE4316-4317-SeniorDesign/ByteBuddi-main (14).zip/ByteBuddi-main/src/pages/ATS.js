/* -- ATS Page -- */
import React, { useState } from "react";
import "./ATS.css";
import ATSModal from "../components/ATSModal.js";
import { evaluateATS } from "../services/atsService.js";

export default function ATS({ data }) {
  // ATS state
const [atsOpen, setAtsOpen]       = useState(false);
const [atsLoading, setAtsLoading] = useState(false);
const [atsResults, setAtsResults] = useState(null);
const [atsError, setAtsError]     = useState(null);
const [jobDescription, setJobDescription] = useState(""); // For the job description input
const [isExpanded, setIsExpanded] = useState(false); // For toggling the job description panel
const [responseTime, setResponseTime] = useState(null); // For response time tracking

   const handleCheckATS = async () => {
       setAtsResults(null);
       setAtsError(null);
       setAtsLoading(true);
       setAtsOpen(true);
   
      // Start response timer 
      const start = performance.now()
       try {
         const results = await evaluateATS(data, jobDescription);
         setAtsResults(results);
       } catch (err) {
         setAtsError(err.message || "Something went wrong. Please try again.");
       } finally {
         // End response timer
         const end = performance.now() - start;
         setResponseTime(end)
         setAtsLoading(false);
       }
     };

    return (
        <div className="Ats-container">
          <h1 className="Ats-title">Check your resume against ATS keywords</h1>
    
          {/* Job Description Input */}
          <div className="job-description-panel">
            <button
              className="job-description-toggle"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <span>📋 Paste a Job Description for better ATS results</span>
              <span className="jd-chevron">{isExpanded ? "▲" : "▼"}</span>
            </button>
    
            {isExpanded && (
              <div className="job-description-body">
                <p className="job-description-hint">
                  Paste the full job posting below. The ATS checker will compare your
                  resume directly against the role's required keywords — just like
                  tools like Jobscan do.
                </p>
                <textarea
                  className="job-description-textarea"
                  placeholder="e.g. We are looking for a Software Engineering Intern with experience in React, Python, REST APIs..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  rows={6}
                />
                {jobDescription && (
                  <button
                    className="job-description-clear"
                    onClick={() => setJobDescription("")}
                  >
                    ✕ Clear
                  </button>
                )}
              </div>
            )}

        </div>
           {/* Action buttons */}
              <div className="action-buttons">
                <button className="ats-check-btn" onClick={handleCheckATS}>
                  🤖 Check ATS {jobDescription ? "vs Job Post" : ""}
                </button>
              { /* <button className="download-btn" onClick={handleDownload}>
                  ⬇ Download as PDF
                </button>*/}
              </div>

              {/* Response Timer */}
                  {responseTime !== null && (
                    <p className="job-description-hint">
                    ATS time: {(responseTime/1000).toFixed(2)} seconds
                    </p>
                  )}
        
              <ATSModal
                isOpen={atsOpen}
                onClose={() => setAtsOpen(false)}
                results={atsResults}
                isLoading={atsLoading}
                error={atsError}
                hasJobDescription={!!jobDescription}
                responseTime={responseTime}
              />
            </div>
    );
}
    