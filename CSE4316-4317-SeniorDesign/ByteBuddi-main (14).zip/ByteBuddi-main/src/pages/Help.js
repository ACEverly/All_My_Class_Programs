import './Help.css';
import React from "react";

const Help = () => {
  const helpInfo = [
    {
      title: "Getting Started",
      image: "🚀",
      content: (
        <>
          <p>Use the <strong><a href="/Login">Login</a></strong> button at the top. If you don't have an account, click <strong>Sign Up</strong>.</p>
          <p>After logging in, more pages (Builder, Templates, Interviewer) will unlock.</p>
        </>
      )
    },
    {
      title: "Building a Resume",
      image: "🖊️",
      content: (
        <>
          <p>Navigate to the <strong><a href="/Builder">Builder</a></strong> page.</p>
          <p>Fill out your contact info, education, experience, skills, etc. Your changes save automatically when you submit each section.</p>
        </>
      )
    },
    {
      title: "Choosing a Template",
      image: "🖼️",
      content: (
        <p>Go to the <strong><a href="Templates">Templates</a></strong> page and select a style you want to use.</p>
      )
    },
    {
      title: "Previewing / Downloading",
      image: "⬇️",
      content: (
        <p>Use the preview section to verify formatting. Then click <strong>Download PDF</strong> to export the resume.</p>
      )
    },
    {
      title: "Optional: Two-Factor Authentication",
      image: "🔒",
      content: (
        <p>Go to <strong>2FA Settings</strong> to enable extra account security. Works with Google Authenticator or Authy.</p>
      )
    },
    {
      title: "Troubleshooting",
      image: "⚠️",
      content: (
        <ul className="troubleshooting-list">
          <li>Login not working? Try resetting your password.</li>
          <li>PDF looks zoomed? Shorten your text or pick a different template.</li>
          <li>Builder not loading? Make sure you're logged in first.</li>
        </ul>
      )
    },
  ];

  return (
    <div className="help-page-wrapper">

      <div className="help-header">
        <h1>Welcome to ByteBuddi</h1>
        <h2>
          This guide walks you through the basic features of the site: creating an account,
          building your resume, choosing templates, and downloading your final PDF.
        </h2>
        <h3>
          Send in support tickets to admin <h4>bytebuddi@gmail.com</h4>
        </h3>
      </div>

      <div className="help-grid">
        {helpInfo.map((item, index) => (
          <div className="help-card" key={index}>
            <div className="card-image">{item.image}</div>
            <h3>{item.title}</h3>
            <div className="card-content">
              {item.content}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Help;
