import React, { useState, useRef } from "react";
import { model } from "../lib/firebase";     // import "gemini-2.5-flash"
import "./Interviewer.css";
import buddiAvatar from "../assets/buddiAvatar.png";
import Default_User from "../assets/Default_User.png";




export default function Interviewer()
{
 const [messages, setMessages] = useState([
   { role: "ai", text: "Hey! I'm your interviewer. I'll ask questions here." },
 ]);
 const [input, setInput] = useState("");
 const [file, setFile] = useState(null);
 const [loading, setLoading] = useState (false);
 const formRef = useRef(null);
 const [fileContext, setFileContext] = useState(null);
 const [responseTime, setResponseTime] = useState(null);


 // Give AI model general behbavior instructions
 const SYSTEM_PROMPT =
 // "You are Buddi, a friendly but professional interview assistant to prep users for engineering interviews" +
 // "Ask concise follow-up questions and keep responses clear";
 " Keep responses very brief, clear, and conversational."+
 "You are Buddi, a friendly but professional interview assistant to prep users for engineering interviews that can also analyze uploaded documents." +
 " If a file is uploaded, check if it's a resume if so, ask user if they want general resume feedback or feedback specific to a job postion." +
 "If a file is uploaded, check if it's information about a job position, ask user if they want a summary of it or projects relevant to the position" +
 "If file is not resume nor job position, give very brief and short responses and ask users to give file relevant to you" +
 "Do not use bold, instead use paragraphs and new line not make readability easier to user";


 async function fileToGenerativePart(file) {
   const base64EncodedDataPromise = new Promise((resolve) => {
     const reader = new FileReader();
     reader.onloadend = () => resolve(reader.result.split(",")[1]);
     reader.readAsDataURL(file);
   });
   return {
     inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
   };
 }


 async function handleSend(e) {
   e?.preventDefault?.();
   const userText = input.trim();
   if ((!userText && !file) || loading) return;


   // Show user message in chat
   setMessages((prev) => [
     ...prev,
     { role: "user",
    
     text: file
     ? `${userText ? userText + "\n\n📎 Uploaded file: " + file.name : "📎 Uploaded file: " + file.name}`
     : userText, },
   ]);
   setInput("");
   setLoading(true);


   // Start timer for chat response time
   const start = performance.now()

   try {
     // Prepare messages for the AI model
     const contents = [
       { role: "user", parts: [{ text: SYSTEM_PROMPT}] },
       ...messages.map((m) => ({
         role: m.role === "ai" ? "model" : "user",
         parts: [{ text: m.text}],
       })),
       { role: "user", parts: [{ text: userText}]},
     ];


    //  if (userText) contents.push({ role: "user", parts: [{ text: userText }] });


     // if (file || fileContext) {
     //   const fileToUse = file || fileContext;
     //   const filePart = await fileToGenerativePart(fileToUse);
     //   contents.push({ role: "user", parts: [filePart] });
    
     //   // Save context if it's a new file
     //   if (file) setFileContext(file);
     // }


     if (file) {
       const filePart = await fileToGenerativePart(file);
       contents.push({ role: "user", parts: [filePart] });
       setFileContext(file); // remember the file for next message
     } else if (fileContext) {
       const filePart = await fileToGenerativePart(fileContext);
       contents.push({ role: "user", parts: [filePart] });
     }
      


     const result = await model.generateContent({ contents });
     const text = await result.response.text();


     setMessages((prev) => [...prev, { role: "ai", text }]);
     setFile(null);
   } catch (error) {
     console.error("Gemini API error:", error);
     setMessages((prev) => [
       ...prev,
       { role: "ai", text: "Sorry, I am having trouble responding right now. Try again?"},
     ])
 } finally {
     // Output response time
     const time = (performance.now() - start).toFixed(2);
     setResponseTime(time)
     console.log(time)
     setLoading(false);
     formRef.current?.querySelector("input")?.focus();
 }
 }
 return (
   <div className="pageBox" aria-label="Chat page" aria-live="polite">
    
     <h1 style={{ marginBottom: 8 }}>Buddi Interviewer — Chat</h1>
     <p className="smallText">Alpha Testing</p>


     {/* main chat area*/}
     <div className="chatArea" role="log">
       {messages.map((m,i) =>
         m.role === "ai" ? (
           <div key={i} className="leftRow">
             <img className="avatarImg" src={buddiAvatar} alt="Buddi avatar" />
             <div className="aiBubble">
               <div className="nameTag">Buddi</div>
               <div>{m.text}</div>
             </div>
           </div>
         ) : (
           <div key={i} className="rightRow">
               <div className="userBubble">
                 <div className="nameTag">You</div>
               <div>{m.text}</div>
             </div>
             <img className="avatarImg rightAvatar" src={Default_User} alt="User avatar" />
           </div>
         )
       )}


       {/* typing indicator */}
       {loading && (
       <div className="leftRow" aria-hidden="true">
         <img className="avatarImg" src={buddiAvatar} alt="" />
         <div className="aiBubble">
           <div className="nameTag">Buddi</div>
           <div className="dimText">…typing</div>
         </div>
       </div>
     )}
     </div>


     {/* input row */}
     <form
  ref={formRef}
  className="inputRow"
  aria-label="Type your message"
  onSubmit={handleSend}
>
  <input
    className="fileInput"
    type="file"
    accept=".pdf,.txt"
    onChange={(e) => setFile(e.target.files[0] || null)}
    disabled={loading}
  />

  <input
    className="textBox"
    placeholder={file ? "File ready to send…" : "Type a message..."}
    name="message"
    aria-label="Your message"
    value={input}
    onChange={(e) => setInput(e.target.value)}
    disabled={loading}
  />

  <button
    className="sendBtn"
    type="submit"
    disabled={loading || (!file && input.trim() === "")}
  >
    Send
  </button>
</form>


     <div className="noteText"> 
      Note: messages are not stored. <br />
      Buddi can look at one file at a time — uploading a new one will replace the last.
      {responseTime && <div> Last response: {(responseTime/1000).toFixed(2)} seconds </div>}
      
      </div>

   </div>
 );
}

