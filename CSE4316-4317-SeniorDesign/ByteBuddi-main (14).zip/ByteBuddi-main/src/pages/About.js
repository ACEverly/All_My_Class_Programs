import './About.css';
import byteBuddyLogo from '../assets/offical_logo_bytebuddi.png';
//import defaultUserIcon from '../assets/Default_User.png';

const teamMembers = [
  {
    name: 'Adalynn Everly',
    role: 'Product Owner',
    image: '/team/Adalynn_Everly.jpg',
  },
  {
    name: 'Alan Acevedo',
    role: 'UI/UX Designer',
    image: '/team/Alan_Acevedo.jpg', 
  },
  {
    name: 'Cesar Gallegos',
    role: 'UI/UX Designer',
    image: '/team/Cesar_Gallegos.jpg', 
  },
  {
    name: 'Ryan Davis',
    role: 'Sprint Master',
    image: '/team/Ryan_Davis.jpg',
  },
  {
    name: 'Rene Salazar',
    role: 'UI/UX Designer',
    image: '/team/Rene_Salazar.jpg',
  },
  {
    name: 'Xavior Lopez',
    role: 'UI/UX Designer',
    image: '/team/Xavior_Lopez.jpg',
  },
];

export default function About() {
  return (
    <div className="about-container">
      
      {/* Logo + Heading */}
      <div className="about-header">
        <img
          src={byteBuddyLogo}
          alt="ByteBuddi Logo"
          className="about-logo"
        />
        <h1 className="about-title">About ByteBuddi</h1>
      </div>

      {/* Main Content */}
      <div className="about-content">
        <p>
          ByteBuddi is a student-focused platform designed to make resume building
          simple, professional, and stress-free. We know that crafting the perfect
          resume can feel overwhelming, especially when you’re just starting your career.
          That’s why we built ByteBuddi — your friendly assistant for resume creation.
        </p>

        <p>
          With our intuitive <strong>Resume Builder</strong> and customizable
          <strong> Templates</strong>, students can quickly create resumes tailored
          to their career goals. Whether you’re applying for internships,
          part-time jobs, or your first professional role, ByteBuddi helps you put
          your best foot forward.
        </p>

        <p>
          Our mission is to empower students by giving them the tools and guidance
          to showcase their skills, experiences, and potential — all in a format
          that hiring managers love. With ByteBuddi, you don’t just build a resume;
          you build confidence in your future.
        </p>
      </div>

      {/* Meet the Team */}
      <div className="team-section">
        <h2 className="team-title">Meet the Team</h2>
        <div className="team-cards">
          {teamMembers.map((member) => (
            <div key={member.name} className="team-card">
              <img
                src={member.image}
                alt={member.name}
                className="team-photo"
                onError={(e) => {
                  // if image file doesn't exist yet, use default user icon
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = '/team/Default_User.png';
                }}
              />
              <h3 className="team-name">{member.name}</h3>
              <p className="team-role">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
