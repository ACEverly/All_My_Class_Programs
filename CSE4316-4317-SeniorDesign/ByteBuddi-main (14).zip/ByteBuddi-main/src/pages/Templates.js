// src/pages/Templates.js
import React, { useState } from "react";
import "./Templates.css";
import ClassicTemplate from "../templates/ClassicTemplate.js";
import ModernTemplate from "../templates/ModernTemplate.js";
import InternshipTemplate from "../templates/InternshipTemplate.js";
import ATSModal from "../components/ATSModal.js";
import { evaluateATS } from "../services/atsService.js";
/*import jsPDF from "jspdf";
import html2canvas from "html2canvas";*/

export default function Templates({ data, selectedTemplate, onTemplateChange }) {
  const [localTemplate, setLocalTemplate] = useState(selectedTemplate || "internship");
  const [jobDescription, setJobDescription] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const [responseTime, setResponseTime] = useState(null); // For response time tracking

  // ATS state
  const [atsOpen, setAtsOpen]       = useState(false);
  const [atsLoading, setAtsLoading] = useState(false);
  const [atsResults, setAtsResults] = useState(null);
  const [atsError, setAtsError]     = useState(null);

  const handleTemplateChange = (e) => {
    const value = e.target.value;
    setLocalTemplate(value);
    if (onTemplateChange) onTemplateChange(value);
  };

  /*const handleDownload = () => {
    const resume = document.getElementById("resume-preview");
    html2canvas(resume).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "pt", "a4");
      pdf.addImage(imgData, "PNG", 20, 20);
      pdf.save("resume.pdf");
    });
  };*/

  const handleCheckATS = async () => {
    setAtsResults(null);
    setAtsError(null);
    setAtsLoading(true);
    setAtsOpen(true);
    setResponseTime(null);

    const start = performance.now()
    try {
      const results = await evaluateATS(data, jobDescription);
      const end = performance.now() - start;
      const seconds = parseFloat((end / 1000)).toFixed(2);

      setAtsResults(results);
      setResponseTime(seconds)
    } catch (err) {
      setAtsError(err.message || "Something went wrong. Please try again.");
    } finally {
      setAtsLoading(false);
    }
  };

  const renderTemplate = () => {
    switch (localTemplate) {
      case "classic":
        return <ClassicTemplate data={data} />;
      case "modern":
        return <ModernTemplate data={data} />;
      case "internship":
      default:
        return <InternshipTemplate data={data} />;
    }
  };

  return (
    <div className="templates-container">
      <h1 className="templates-title">Check your resume against ATS keywords</h1>

      {/* Job Description Input */}
      <div className="job-description-panel">
        <button
          className="job-description-toggle"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <span>📋 Paste a Job Description for better ATS results</span>
          <span className="jd-chevron">{isExpanded ? "▲" : "▼"}</span>
        </button>

        {isExpanded && (
          <div className="job-description-body">
            <p className="job-description-hint">
              Paste the full job posting below. The ATS checker will compare your
              resume directly against the role's required keywords — just like
              tools like Jobscan do.
            </p>
            <textarea
              className="job-description-textarea"
              placeholder="e.g. We are looking for a Software Engineering Intern with experience in React, Python, REST APIs..."
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              rows={6}
            />
            {jobDescription && (
              <button
                className="job-description-clear"
                onClick={() => setJobDescription("")}
              >
                ✕ Clear
              </button>
            )}
          </div>
        )}
      </div>

       {/* Action buttons */}
       <div className="action-buttons">
        <button className="ats-check-btn" onClick={handleCheckATS}>
          🤖 Check ATS {jobDescription ? "vs Job Post" : ""}
        </button>
      { /* <button className="download-btn" onClick={handleDownload}>
          ⬇ Download as PDF
        </button>*/}
      </div>


      <div className="template-selector">
        <label htmlFor="template">Select Template:</label>
        <select id="template" value={localTemplate} onChange={handleTemplateChange}>
          <option value="internship">Internship</option>
          <option value="classic">Classic</option>
          <option value="modern">Modern</option>
        </select>
      </div>

      <div className="resume-preview-container">
        <div id="resume-preview">
          {renderTemplate()}
        </div>
      </div>
      
      <ATSModal
        isOpen={atsOpen}
        onClose={() => setAtsOpen(false)}
        results={atsResults}
        isLoading={atsLoading}
        error={atsError}
        hasJobDescription={!!jobDescription}
        responseTime={responseTime}

      />
    </div>
  );
}