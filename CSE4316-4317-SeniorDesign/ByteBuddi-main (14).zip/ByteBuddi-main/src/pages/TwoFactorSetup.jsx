import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { db } from "../lib/firebase";
import { doc, updateDoc, getDoc, setDoc } from "firebase/firestore";
import QRCode from "qrcode";
import "./TwoFactorSetup.css";

export default function TwoFactorSetup() {
  const { currentUser } = useAuth();
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [secret, setSecret] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
  loadUserSettings();
}, [loadUserSettings]);

  async function loadUserSettings() {
    if (!currentUser) return;
    
    try {
      const userDocRef = doc(db, "users", currentUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      // If user document doesn't exist, create it
      if (!userDoc.exists()) {
        console.log("User document not found, creating one...");
        await setDoc(userDocRef, {
          email: currentUser.email,
          createdAt: new Date(),
          twoFactorEnabled: false,
          twoFactorSecret: null,
        });
        setTwoFactorEnabled(false);
      } else {
        const userData = userDoc.data();
        setTwoFactorEnabled(userData?.twoFactorEnabled || false);
      }
      
      setLoading(false);
    } catch (error) {
      console.error("Error loading settings:", error);
      setMsg("❌ Error loading settings: " + error.message);
      setLoading(false);
    }
  }

  async function generateSecret() {
    // Generate a random 32-character base32 secret
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let newSecret = "";
    for (let i = 0; i < 32; i++) {
      newSecret += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setSecret(newSecret);

    // Generate QR code URL for authenticator apps
    const otpauthUrl = `otpauth://totp/ByteBuddy:${currentUser.email}?secret=${newSecret}&issuer=ByteBuddy`;
    
    try {
      const qrUrl = await QRCode.toDataURL(otpauthUrl);
      setQrCodeUrl(qrUrl);
      setMsg("📱 Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)");
    } catch (error) {
      setMsg("❌ Error generating QR code");
    }
  }

  // Base32 decode function
  function base32Decode(secret) {
    const base32chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let bits = "";
    
    for (let i = 0; i < secret.length; i++) {
      const val = base32chars.indexOf(secret.charAt(i).toUpperCase());
      if (val === -1) continue;
      bits += val.toString(2).padStart(5, '0');
    }
    
    const bytes = [];
    for (let i = 0; i + 8 <= bits.length; i += 8) {
      bytes.push(parseInt(bits.substr(i, 8), 2));
    }
    
    return new Uint8Array(bytes);
  }

  // HMAC-SHA1 implementation using Web Crypto API
  async function hmacSha1(key, message) {
    //const encoder = new TextEncoder();
    const keyData = base32Decode(key);
    
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-1' },
      false,
      ['sign']
    );
    
    const messageData = new Uint8Array(8);
    for (let i = 7; i >= 0; i--) {
      messageData[i] = message & 0xff;
      message = message >> 8;
    }
    
    const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
    return new Uint8Array(signature);
  }

  // Generate TOTP token
  async function generateTOTP(secret) {
    const epoch = Math.floor(Date.now() / 1000);
    const time = Math.floor(epoch / 30);
    
    try {
      const hmac = await hmacSha1(secret, time);
      const offset = hmac[hmac.length - 1] & 0xf;
      const binary = 
        ((hmac[offset] & 0x7f) << 24) |
        ((hmac[offset + 1] & 0xff) << 16) |
        ((hmac[offset + 2] & 0xff) << 8) |
        (hmac[offset + 3] & 0xff);
      
      const otp = binary % 1000000;
      return otp.toString().padStart(6, '0');
    } catch (error) {
      console.error('Error generating TOTP:', error);
      return null;
    }
  }

  async function verifyAndEnable() {
    if (!verificationCode || verificationCode.length !== 6) {
      setMsg("⚠️ Please enter a valid 6-digit code");
      return;
    }

    setMsg("");
    try {
      // Generate expected TOTP
      const expectedToken = await generateTOTP(secret);
      
      // Also check previous and next time windows (to account for clock drift)
      const epoch = Math.floor(Date.now() / 1000);
      const timePrev = Math.floor((epoch - 30) / 30);
      const timeNext = Math.floor((epoch + 30) / 30);
      
      const hmacPrev = await hmacSha1(secret, timePrev);
      const hmacNext = await hmacSha1(secret, timeNext);
      
      const offsetPrev = hmacPrev[hmacPrev.length - 1] & 0xf;
      const offsetNext = hmacNext[hmacNext.length - 1] & 0xf;
      
      const binaryPrev = 
        ((hmacPrev[offsetPrev] & 0x7f) << 24) |
        ((hmacPrev[offsetPrev + 1] & 0xff) << 16) |
        ((hmacPrev[offsetPrev + 2] & 0xff) << 8) |
        (hmacPrev[offsetPrev + 3] & 0xff);
      
      const binaryNext = 
        ((hmacNext[offsetNext] & 0x7f) << 24) |
        ((hmacNext[offsetNext + 1] & 0xff) << 16) |
        ((hmacNext[offsetNext + 2] & 0xff) << 8) |
        (hmacNext[offsetNext + 3] & 0xff);
      
      const otpPrev = (binaryPrev % 1000000).toString().padStart(6, '0');
      const otpNext = (binaryNext % 1000000).toString().padStart(6, '0');
      
      const isValid = 
        verificationCode === expectedToken ||
        verificationCode === otpPrev ||
        verificationCode === otpNext;
      
      if (isValid) {
        // Save secret to Firestore
        await updateDoc(doc(db, "users", currentUser.uid), {
          twoFactorEnabled: true,
          twoFactorSecret: secret,
        });
        
        setTwoFactorEnabled(true);
        setQrCodeUrl("");
        setSecret("");
        setVerificationCode("");
        setMsg("✅ Two-factor authentication enabled successfully!");
      } else {
        setMsg("❌ Invalid code. Please try again.");
      }
    } catch (error) {
      console.error('Verification error:', error);
      setMsg("❌ Error verifying code: " + error.message);
    }
  }

  async function disable2FA() {
    try {
      await updateDoc(doc(db, "users", currentUser.uid), {
        twoFactorEnabled: false,
        twoFactorSecret: null,
      });
      
      setTwoFactorEnabled(false);
      setMsg("⚠️ Two-factor authentication disabled");
    } catch (error) {
      setMsg("❌ Error disabling 2FA: " + error.message);
    }
  }

  if (loading) {
    return <div className="setup-container">Loading...</div>;
  }

  return (
    <div className="setup-container">
      <div className="setup-card">
        <h1>Two-Factor Authentication</h1>
        
        {!twoFactorEnabled ? (
          <div className="setup-content">
            <p className="setup-description">
              Add an extra layer of security to your account by enabling two-factor authentication.
              You'll need an authenticator app like Google Authenticator or Authy.
            </p>

            {!qrCodeUrl ? (
              <button className="setup-btn primary" onClick={generateSecret}>
                Enable 2FA
              </button>
            ) : (
              <div className="setup-steps">
                <div className="qr-section">
                  <img src={qrCodeUrl} alt="QR Code" className="qr-code" />
                  <p className="secret-display">
                    Or enter this code manually: <code>{secret}</code>
                  </p>
                </div>

                <div className="verification-section">
                  <label>Enter the 6-digit code from your app:</label>
                  <input
                    type="text"
                    placeholder="123456"
                    maxLength="6"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                  />
                  <div className="button-group">
                    <button className="setup-btn primary" onClick={verifyAndEnable}>
                      Verify & Enable
                    </button>
                    <button className="setup-btn secondary" onClick={() => {
                      setQrCodeUrl("");
                      setSecret("");
                      setVerificationCode("");
                      setMsg("");
                    }}>
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="setup-content">
            <div className="status-badge enabled">
              ✅ Two-Factor Authentication is ENABLED
            </div>
            <p className="setup-description">
              Your account is protected with two-factor authentication.
            </p>
            <button className="setup-btn danger" onClick={disable2FA}>
              Disable 2FA
            </button>
          </div>
        )}

        {msg && <p className="setup-message">{msg}</p>}
      </div>
    </div>
  );
}