import React, { useState, useEffect } from "react";
import "./Builder.css";
import ClassicTemplate from "../templates/ClassicTemplate";
import ModernTemplate from "../templates/ModernTemplate";
import InternshipTemplate from "../templates/InternshipTemplate";
import ExportPDF from "./ExportPDF";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { saveResume, listResumes, loadResume, deleteResume } from "../lib/resumes";

// Empty entry templates
const emptyEducation = { school: "", degree: "", location: "", dates: "", gpa: "", coursework: "" };
const emptyExperience = { company: "", title: "", location: "", dates: "", bullets: [""] };
const emptyProject = { name: "", technologies: "", dates: "", bullets: [""] };
const emptySkillCategory = { category: "", items: "" };

// Default form data structure
const defaultFormData = {
  name: "",
  email: "",
  phone: "",
  linkedin: "",
  github: "",
  summary: "",
  education: [{ ...emptyEducation }],
  experience: [{ ...emptyExperience }],
  projects: [{ ...emptyProject }],
  skills: [
    { category: "Languages", items: "" },
    { category: "Frameworks", items: "" },
    { category: "Developer Tools", items: "" },
    { category: "Libraries", items: "" },
  ],
};

// sessionStorage keys
const TEMP_STORAGE_KEY = 'resume_builder_temp_data';
const TEMP_TEMPLATE_KEY = 'resume_builder_temp_template';
const TEMP_RESUME_ID_KEY = 'resume_builder_temp_id';
const TEMP_RESUME_TITLE_KEY = 'resume_builder_temp_title';

// Helper functions for sessionStorage
const loadTempData = () => {
  try {
    const saved = sessionStorage.getItem(TEMP_STORAGE_KEY);
    const savedTemplate = sessionStorage.getItem(TEMP_TEMPLATE_KEY);
    const savedResumeId = sessionStorage.getItem(TEMP_RESUME_ID_KEY);
    const savedResumeTitle = sessionStorage.getItem(TEMP_RESUME_TITLE_KEY);
    
    return {
      data: saved ? JSON.parse(saved) : defaultFormData,
      template: savedTemplate || 'internship',
      resumeId: savedResumeId || null,
      resumeTitle: savedResumeTitle || ""
    };
  } catch (e) {
    console.error('Failed to load temp data:', e);
    return { 
      data: defaultFormData, 
      template: 'internship',
      resumeId: null,
      resumeTitle: ""
    };
  }
};

const saveTempData = (data, template, resumeId, resumeTitle) => {
  try {
    sessionStorage.setItem(TEMP_STORAGE_KEY, JSON.stringify(data));
    sessionStorage.setItem(TEMP_TEMPLATE_KEY, template);
    if (resumeId) {
      sessionStorage.setItem(TEMP_RESUME_ID_KEY, resumeId);
    } else {
      sessionStorage.removeItem(TEMP_RESUME_ID_KEY);
    }
    if (resumeTitle) {
      sessionStorage.setItem(TEMP_RESUME_TITLE_KEY, resumeTitle);
    } else {
      sessionStorage.removeItem(TEMP_RESUME_TITLE_KEY);
    }
  } catch (e) {
    console.error('Failed to save temp data:', e);
  }
};

const clearTempData = () => {
  try {
    sessionStorage.removeItem(TEMP_STORAGE_KEY);
    sessionStorage.removeItem(TEMP_TEMPLATE_KEY);
    sessionStorage.removeItem(TEMP_RESUME_ID_KEY);
    sessionStorage.removeItem(TEMP_RESUME_TITLE_KEY);
  } catch (e) {
    console.error('Failed to clear temp data:', e);
  }
};

// Collapsible Section Component
function CollapsibleSection({ title, children, defaultOpen = true }) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div className="collapsible-section">
      <button type="button" className="collapsible-header" onClick={() => setIsOpen(!isOpen)}>
        <span>{title}</span>
        <span className="collapsible-icon">{isOpen ? "−" : "+"}</span>
      </button>
      {isOpen && <div className="collapsible-content">{children}</div>}
    </div>
  );
}

// Entry Card Component
function EntryCard({ children, onRemove, canRemove = true }) {
  return (
    <div className="entry-card">
      {canRemove && (
        <button type="button" className="remove-entry-btn" onClick={onRemove}>
          ✕ Remove
        </button>
      )}
      {children}
    </div>
  );
}

// Add Button Component
function AddButton({ onClick, label }) {
  return (
    <button type="button" className="add-entry-btn" onClick={onClick}>
      + {label}
    </button>
  );
}

// Input Field Component
function Field({ label, value, onChange, type = "text", placeholder = "", className = "" }) {
  return (
    <div className={`field-group ${className}`}>
      <label className="field-label">{label}</label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="field-input"
      />
    </div>
  );
}

// Bullet Point Input Component
function BulletInput({ value, onChange, onRemove, placeholder }) {
  return (
    <div className="bullet-input-row">
      <span className="bullet-marker">•</span>
      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="bullet-input"
      />
      <button type="button" className="bullet-remove-btn" onClick={onRemove}>
        ✕
      </button>
    </div>
  );
}

export default function Builder({ onDataChange }) {
  // Initialize with sessionStorage data
  const tempData = loadTempData();
  const [formData, setFormData] = useState(tempData.data);
  const [selectedTemplate, setSelectedTemplate] = useState(tempData.template);
  const [currentResumeId, setCurrentResumeId] = useState(tempData.resumeId);
  const [currentResumeTitle, setCurrentResumeTitle] = useState(tempData.resumeTitle);

  const auth = getAuth();
  const db = getFirestore();

  // Save to sessionStorage whenever data changes
  useEffect(() => {
    saveTempData(formData, selectedTemplate, currentResumeId, currentResumeTitle);
  }, [formData, selectedTemplate, currentResumeId, currentResumeTitle]);

  // Added to prevent data leaking from one user to another between logins
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (!user) { 
        // User logged out/changed CLEAR temp data
        clearTempData();

        // Set default values for all temp data stored
        setFormData(defaultFormData);
        setSelectedTemplate("internship");
        setCurrentResumeId(null);
        setCurrentResumeTitle("")
      }
    });
    return () => unsubscribe(); 
  });

  // Generic field update
  const updateField = (field, value) => {
    const next = { ...formData, [field]: value };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  // Update array field (education, experience, projects, skills)
  const updateArrayField = (section, index, field, value) => {
    const arr = [...formData[section]];
    arr[index] = { ...arr[index], [field]: value };
    const next = { ...formData, [section]: arr };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  // Bullet point management
  const updateBullet = (section, entryIndex, bulletIndex, value) => {
    const arr = [...formData[section]];
    const bullets = [...arr[entryIndex].bullets];
    bullets[bulletIndex] = value;
    arr[entryIndex] = { ...arr[entryIndex], bullets };
    const next = { ...formData, [section]: arr };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  const addBullet = (section, entryIndex) => {
    const arr = [...formData[section]];
    arr[entryIndex] = { ...arr[entryIndex], bullets: [...arr[entryIndex].bullets, ""] };
    const next = { ...formData, [section]: arr };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  const removeBullet = (section, entryIndex, bulletIndex) => {
    const arr = [...formData[section]];
    const bullets = arr[entryIndex].bullets.filter((_, i) => i !== bulletIndex);
    arr[entryIndex] = { ...arr[entryIndex], bullets: bullets.length ? bullets : [""] };
    const next = { ...formData, [section]: arr };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  // Add/Remove entries
  const addEntry = (section, template) => {
    const next = { ...formData, [section]: [...formData[section], { ...template }] };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  const removeEntry = (section, index) => {
    if (formData[section].length <= 1) return;
    const next = { ...formData, [section]: formData[section].filter((_, i) => i !== index) };
    setFormData(next);
    if (typeof onDataChange === "function") onDataChange(next);
  };

  // Cloud functions
  async function handleSaveToCloud() {
    const user = auth.currentUser;
    if (!user) { 
      window.alert("Please log in to save to cloud."); 
      return; 
    }
    
    const titlePromptDefault = currentResumeTitle || "";
    const title = window.prompt("Title for this resume", titlePromptDefault);
    if (!title) return;
    
    try {
      // Passing ID if exists
      const newId = await saveResume(db, user.uid, { 
        id: currentResumeId || undefined,
        title, 
        data: formData, 
        template: selectedTemplate 
      });
      
      setCurrentResumeId(newId);
      setCurrentResumeTitle(title);
      
      window.alert("Saved to cloud successfully!");
      
      // Optional: You can choose to clear temp data after successful save
      // Uncomment the line below if you want to clear sessionStorage after saving
      // clearTempData();
      
    } catch (e) {
      console.error("Save failed:", e);
      window.alert("Save failed. Please try again.");
    }
  }

  async function handleLoadFromCloud() {
    const user = auth.currentUser;
    if (!user) { 
      window.alert("Please log in to load from cloud."); 
      return; 
    }
    
    try {
      const items = await listResumes(db, user.uid);
      if (!items.length) { 
        window.alert("No cloud resumes yet."); 
        return; 
      }
      
      let menu = "";
      for (let i = 0; i < items.length; i++) {
        const title = items[i].title || "(Untitled)";
        menu += (i + 1) + ". " + title;
        if (i < items.length - 1) menu += "\n";
      }
      
      const choice = window.prompt("Pick a resume number:\n\n" + menu);
      if (choice === null) return;
      
      const idx = Number(choice) - 1;
      if (Number.isNaN(idx) || idx < 0 || idx >= items.length) {
        window.alert("Invalid choice.");
        return;
      }
      
      const picked = await loadResume(db, items[idx].id);
      if (!picked) { 
        window.alert("Unable to load that resume."); 
        return; 
      }
      
      setFormData(picked.data || defaultFormData);
      setSelectedTemplate(picked.template || "internship");
      setCurrentResumeId(picked.id);
      setCurrentResumeTitle(picked.title || items[idx].title || "");

      window.alert("Loaded: " + picked.title);
    } catch (e) {
      console.error("Load failed:", e);
      window.alert("Load failed. Please try again.");
    }
  }

  async function handleDeleteFromCloud() {
    const user = auth.currentUser;
    if (!user) { 
      window.alert("Please log in to delete from cloud."); 
      return; 
    }
    
    try {
      const items = await listResumes(db, user.uid);
      if (!items.length) { 
        window.alert("No cloud resumes to delete."); 
        return; 
      }
      
      let menu = "";
      for (let i = 0; i < items.length; i++) {
        const title = items[i].title || "(Untitled)";
        menu += (i + 1) + ". " + title;
        if (i < items.length - 1) menu += "\n";
      }
      
      const choice = window.prompt("Delete which resume number?\n\n" + menu);
      if (choice === null) return;
      
      const idx = Number(choice) - 1;
      if (Number.isNaN(idx) || idx < 0 || idx >= items.length) {
        window.alert("Invalid choice.");
        return;
      }
      
      const { id, title } = items[idx];
      const ok = window.confirm('Delete "' + title + '"?');
      if (!ok) return;
      
      await deleteResume(db, id);
      
      // If the deleted resume is the current one, clear the IDs
      if (id === currentResumeId) {
        setCurrentResumeId(null);
        setCurrentResumeTitle("");
      }
      
      window.alert('Deleted "' + title + '".');
    } catch (e) {
      console.error("Delete failed:", e);
      window.alert("Delete failed. Please try again.");
    }
  }

  // New function: Clear current resume and start fresh
  function handleNewResume() {
    const ok = window.confirm("Start a new resume? This will clear your current work (but won't delete saved resumes).");
    if (!ok) return;
    
    setFormData(defaultFormData);
    setSelectedTemplate("internship");
    setCurrentResumeId(null);
    setCurrentResumeTitle("");
    clearTempData();
    
    window.alert("Started new resume!");
  }

  return (
    <div className="builder-layout">
      {/* Left Panel - Form */}
      <div className="builder-form-panel">
        <h1 className="builder-title">Resume Builder</h1>

        <div className="template-selector">
          <label>Template:</label>
          <select value={selectedTemplate} onChange={(e) => setSelectedTemplate(e.target.value)}>
            <option value="internship">Internship</option>
            <option value="classic">Classic</option>
            <option value="modern">Modern</option>
          </select>
        </div>

        <div className="cloud-buttons">
          <button type="button" onClick={handleNewResume}>New Resume</button>
          <button type="button" onClick={handleSaveToCloud}>Save to Cloud</button>
          <button type="button" onClick={handleLoadFromCloud}>Load from Cloud</button>
          <button type="button" onClick={handleDeleteFromCloud}>Delete from Cloud</button>
        </div>

        {currentResumeTitle && (
          <div style={{ padding: '8px', background: '#f0f0f0', borderRadius: '4px', marginBottom: '16px', fontSize: '14px' }}>
            Currently editing: <strong>{currentResumeTitle}</strong>
          </div>
        )}

        <form className="builder-form">
          {/* Personal Information */}
          <CollapsibleSection title="Personal Information">
            <div className="form-grid">
              <Field label="Full Name" value={formData.name} onChange={(e) => updateField("name", e.target.value)} />
              <Field label="Email" type="email" value={formData.email} onChange={(e) => updateField("email", e.target.value)} />
              <Field label="Phone" value={formData.phone} onChange={(e) => updateField("phone", e.target.value)} />
              <Field label="LinkedIn" value={formData.linkedin} onChange={(e) => updateField("linkedin", e.target.value)} placeholder="linkedin.com/in/yourname" />
              <Field label="GitHub" value={formData.github} onChange={(e) => updateField("github", e.target.value)} placeholder="github.com/yourname" className="full-width" />
            </div>
            <div className="field-group full-width">
              <label className="field-label">Objective / Summary</label>
              <textarea
                value={formData.summary}
                onChange={(e) => updateField("summary", e.target.value)}
                rows="3"
                className="field-textarea"
                placeholder="Brief professional summary or career objective..."
              />
            </div>
          </CollapsibleSection>

          {/* Education */}
          <CollapsibleSection title="Education">
            {formData.education.map((edu, i) => (
              <EntryCard key={i} onRemove={() => removeEntry("education", i)} canRemove={formData.education.length > 1}>
                <div className="form-grid">
                  <Field label="School/University" value={edu.school} onChange={(e) => updateArrayField("education", i, "school", e.target.value)} />
                  <Field label="Location" value={edu.location} onChange={(e) => updateArrayField("education", i, "location", e.target.value)} placeholder="City, State" />
                  <Field label="Degree" value={edu.degree} onChange={(e) => updateArrayField("education", i, "degree", e.target.value)} placeholder="B.S. in Computer Science" />
                  <Field label="Dates" value={edu.dates} onChange={(e) => updateArrayField("education", i, "dates", e.target.value)} placeholder="Aug 2020 - May 2024" />
                  <Field label="GPA (optional)" value={edu.gpa} onChange={(e) => updateArrayField("education", i, "gpa", e.target.value)} placeholder="3.8/4.0" />
                  <Field label="Relevant Coursework" value={edu.coursework} onChange={(e) => updateArrayField("education", i, "coursework", e.target.value)} className="full-width" placeholder="Data Structures, Algorithms, etc." />
                </div>
              </EntryCard>
            ))}
            <AddButton onClick={() => addEntry("education", emptyEducation)} label="Add Education" />
          </CollapsibleSection>

          {/* Experience */}
          <CollapsibleSection title="Experience">
            {formData.experience.map((exp, i) => (
              <EntryCard key={i} onRemove={() => removeEntry("experience", i)} canRemove={formData.experience.length > 1}>
                <div className="form-grid">
                  <Field label="Company" value={exp.company} onChange={(e) => updateArrayField("experience", i, "company", e.target.value)} />
                  <Field label="Location" value={exp.location} onChange={(e) => updateArrayField("experience", i, "location", e.target.value)} placeholder="City, State" />
                  <Field label="Job Title" value={exp.title} onChange={(e) => updateArrayField("experience", i, "title", e.target.value)} />
                  <Field label="Dates" value={exp.dates} onChange={(e) => updateArrayField("experience", i, "dates", e.target.value)} placeholder="Jun 2023 - Aug 2023" />
                </div>
                <div className="bullets-section">
                  <label className="field-label">Achievements / Responsibilities</label>
                  {exp.bullets.map((bullet, j) => (
                    <BulletInput
                      key={j}
                      value={bullet}
                      onChange={(e) => updateBullet("experience", i, j, e.target.value)}
                      onRemove={() => removeBullet("experience", i, j)}
                      placeholder="Describe your achievement or responsibility..."
                    />
                  ))}
                  <button type="button" className="add-bullet-btn" onClick={() => addBullet("experience", i)}>
                    + Add Bullet Point
                  </button>
                </div>
              </EntryCard>
            ))}
            <AddButton onClick={() => addEntry("experience", emptyExperience)} label="Add Experience" />
          </CollapsibleSection>

          {/* Projects */}
          <CollapsibleSection title="Projects">
            {formData.projects.map((proj, i) => (
              <EntryCard key={i} onRemove={() => removeEntry("projects", i)} canRemove={formData.projects.length > 1}>
                <div className="form-grid">
                  <Field label="Project Name" value={proj.name} onChange={(e) => updateArrayField("projects", i, "name", e.target.value)} />
                  <Field label="Dates" value={proj.dates} onChange={(e) => updateArrayField("projects", i, "dates", e.target.value)} placeholder="Jan 2024 - Present" />
                  <Field label="Technologies Used" value={proj.technologies} onChange={(e) => updateArrayField("projects", i, "technologies", e.target.value)} className="full-width" placeholder="React, Node.js, MongoDB, etc." />
                </div>
                <div className="bullets-section">
                  <label className="field-label">Description</label>
                  {proj.bullets.map((bullet, j) => (
                    <BulletInput
                      key={j}
                      value={bullet}
                      onChange={(e) => updateBullet("projects", i, j, e.target.value)}
                      onRemove={() => removeBullet("projects", i, j)}
                      placeholder="Describe what you built or accomplished..."
                    />
                  ))}
                  <button type="button" className="add-bullet-btn" onClick={() => addBullet("projects", i)}>
                    + Add Bullet Point
                  </button>
                </div>
              </EntryCard>
            ))}
            <AddButton onClick={() => addEntry("projects", emptyProject)} label="Add Project" />
          </CollapsibleSection>

          {/* Skills */}
          <CollapsibleSection title="Technical Skills">
            {formData.skills.map((skill, i) => (
              <EntryCard key={i} onRemove={() => removeEntry("skills", i)} canRemove={formData.skills.length > 1}>
                <div className="form-grid skills-grid">
                  <Field label="Category" value={skill.category} onChange={(e) => updateArrayField("skills", i, "category", e.target.value)} placeholder="e.g., Languages" />
                  <Field label="Skills (comma-separated)" value={skill.items} onChange={(e) => updateArrayField("skills", i, "items", e.target.value)} className="skills-items" placeholder="Python, JavaScript, Java, C++" />
                </div>
              </EntryCard>
            ))}
            <AddButton onClick={() => addEntry("skills", emptySkillCategory)} label="Add Skill Category" />
          </CollapsibleSection>
        </form>
      </div>

      {/* Right Panel - Preview */}
      <div className="builder-preview-panel">
        <div className="preview-sticky">
          <h2 className="preview-title">Preview</h2>
          <div className="resume-container">
            <div id="resume-preview">
              {selectedTemplate === "internship" && <InternshipTemplate data={formData} />}
              {selectedTemplate === "classic" && <ClassicTemplate data={formData} />}
              {selectedTemplate === "modern" && <ModernTemplate data={formData} />}
            </div>
          </div>
          <div className="export-section">
            <ExportPDF />
          </div>
        </div>
      </div>
    </div>
  );
}