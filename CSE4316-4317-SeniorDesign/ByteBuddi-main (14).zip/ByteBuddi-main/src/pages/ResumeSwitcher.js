// ResumeSwitcher
import ClassicTemplate from './templates/ClassicTemplate';
import ModernTemplate from './templates/ModernTemplate';

const ResumeSwitcher = ({ data, selectedTemplate }) => {
  switch (selectedTemplate) {
    case 'classic':
      return <ClassicTemplate data={data} />;
    case 'modern':
      return <ModernTemplate data={data} />;
    default:
      return <ClassicTemplate data={data} />;
  }
};
