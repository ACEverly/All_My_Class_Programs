# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

## Step 0 - Make Sure You Have These Installed
```powershell
node --version
npm --version
firebase --version
```
## Step 1 — Install Firebase CLI
```powershell
npm install -g firebase-tools
firebase login
```

---

## Step 2 — Initialize Firebase
```powershell
firebase init hosting
```
| Question | Answer |
|---|---|
| Public directory? | `build` |
| Single-page app? | `Yes` |
| Automatic builds with GitHub? | `No` |
| Overwrite build/index.html? | `No` |

---

## Step 3 — Secure Your API Keys BEFORE Connecting GitHub

**1. Make sure `.gitignore` has these entries:**
```
.env
.env.local
.env.production
env
```

**2. Check no secrets are already tracked:**
```powershell
git ls-files | grep -i env
git ls-files | grep -i key
git ls-files | grep -i secret
```
If any of these return files → remove them immediately:
```powershell
git rm --cached .env
git rm --cached env
```

**3. Scan your entire codebase for hardcoded keys:**
```powershell
grep -r "API_KEY\|SECRET\|PASSWORD\|TOKEN" --include="*.js" --include="*.jsx" src/
```
If anything shows up that's a real key → replace it with an environment variable.

**4. Your `.env` file should look like this (never commit this file):**
```
REACT_APP_GROQ_API_KEY=your_key_here
REACT_APP_FIREBASE_API_KEY=your_key_here
```

---

## Step 4 — Add All Keys to GitHub Secrets

1. Go to **github.com/rxs8957/ByteBuddi → Settings → Secrets and variables → Actions**
2. Click **New repository secret** for each key:

| Secret Name | Value |
|---|---|
| `REACT_APP_GROQ_API_KEY` | your Groq key |
| `REACT_APP_FIREBASE_API_KEY` | your Firebase key |

---

## Step 5 — Connect GitHub
```powershell
firebase init hosting:github
```
| Question | Answer |
|---|---|
| GitHub repo? | `rxs8957/ByteBuddi` |
| Run build script before deploy? | `Yes` |
| Build script? | `npm ci && npm run build` |
| Auto deploy on push to main? | `Yes` |
| Branch? | `main` |
| Set up preview on pull requests? | `Yes` |

---

## Step 6 — Update Your Workflow File

Replace the content of `.github/workflows/firebase-hosting-merge.yml` with this:

```yaml
name: Deploy to Firebase Hosting on merge

on:
  push:
    branches:
      - main

jobs:
  security_check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check for hardcoded secrets
        run: |
          echo "Scanning for hardcoded API keys..."
          if grep -r "GROQ_API_KEY\s*=" --include="*.js" --include="*.jsx" --include="*.ts" --include="*.tsx" src/ | grep -v "process.env"; then
            echo "❌ ERROR: Hardcoded API key found in source code!"
            exit 1
          fi
          if grep -r "sk-\|gsk_\|Bearer " --include="*.js" --include="*.jsx" --include="*.ts" --include="*.tsx" src/; then
            echo "❌ ERROR: Possible hardcoded token found in source code!"
            exit 1
          fi
          echo "✅ No hardcoded secrets found"

      - name: Check .env is not tracked
        run: |
          if git ls-files | grep -q "^\.env$\|^env$"; then
            echo "❌ ERROR: .env file is being tracked by git!"
            exit 1
          fi
          echo "✅ .env file is not tracked"

  build_and_deploy:
    runs-on: ubuntu-latest
    needs: security_check
    steps:
      - uses: actions/checkout@v4
        with:
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '24'

      - name: Install and Build
        run: npm ci && npm run build
        env:
          CI: false
          REACT_APP_GROQ_API_KEY: ${{ secrets.REACT_APP_GROQ_API_KEY }}
          REACT_APP_FIREBASE_API_KEY: ${{ secrets.REACT_APP_FIREBASE_API_KEY }}

      - name: Deploy to Firebase
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: ${{ secrets.GITHUB_TOKEN }}
          firebaseServiceAccount: ${{ secrets.FIREBASE_SERVICE_ACCOUNT_BYTEBUDDI_93A7D }}
          channelId: live
          projectId: bytebuddi-93a7d
```

---

## Step 7 — Push Everything
```powershell
git add .
git commit -m "setup secure firebase deployment with github actions"
git push origin main
```

---

## How It Works Now

Every push to `main` will:
1. 🔍 **Security check** — scans for hardcoded keys, blocks deploy if found
2. 🔨 **Build** — installs dependencies and builds React app using secrets
3. 🚀 **Deploy** — pushes to Firebase automatically

If a secret is ever accidentally hardcoded, the pipeline **fails before deploying** and protects you. 🔒
