# Printtokens Testing Project

Our testing files are included in a ZIP in this deliverable folder as instructed, they are also in the src folder of the repo
The package main.printtokens contains:

- Fault corrected program (`Printtokens.java`)
- Unit tests (`PrinttokensTest.java`)
- End to end tests (`e2e_tests.java`)



## How to Review in Eclipse

1. **Clone the Repository**
   - You may use GitHub Desktop, Eclipse EGit, or command line:
     ```bash
     git clone https://github.com/your-org-or-classroom-name/your-repo-name.git
     ```

2. **Import Project into Eclipse**
   - Open Eclipse
   - Go to `File > Open Projects from File System...`
   - Select the cloned project directory
   - Click “Finish”

3. **Set Up Build Path**
   - Right-click the project > `Properties > Java Build Path`
   - Ensure the following are added:
     - **JRE System Library** (e.g., Java 16 or compatible)
     - **JUnit 5** (`Add Library > JUnit > JUnit 5`)


4. **Run the Tests**
   - Open `PrinttokensTest.java`
   - Right-click in the editor > `Run As` (or `Coverage As` to see coverage with Jacoco) > `JUnit Test`


5. **Review Output**
   - View pass/fail status in the JUnit panel.
   - Test cases correspond to specific control paths and expected outputs as documented in `/docs/test_cases.pdf`.

## Notes

- All user-defined functions are tested with meaningful inputs and documented paths.
- Catch blocks are excluded from the control flow graphs per assignment instructions.
- We targeted reaching Coverage above 95% for each individual method with our unit tests and a collective >95% total on the whole program as specified in the rubric


## Contact

If you have any issues during the review, please feel free to contact us on UTA teams network or by email or through canvas mtb9515@mavs.uta.edu or adalynn.everly@mavs.uta.edu.
